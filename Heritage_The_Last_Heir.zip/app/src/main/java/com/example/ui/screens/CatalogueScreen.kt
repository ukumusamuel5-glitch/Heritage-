package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.Adventure
import com.example.model.AdventureCatalog
import com.example.model.CharacterArchetype
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment

@Composable
fun CatalogueScreen(
    language: AppLanguage,
    adventures: List<Adventure>,
    onLaunchSolo: (adventureId: String, adventureTitle: String, character: CharacterArchetype) -> Unit,
    onCreateMultiplayerFor: (Adventure) -> Unit
) {
    val strings = AppStrings.get(language)
    var filter by remember { mutableStateOf("ALL") }
    var pickerTarget by remember { mutableStateOf<Adventure?>(null) }

    val filtered = remember(adventures, filter) {
        when (filter) {
            "PLAYABLE" -> adventures.filter { it.playable }
            "UPCOMING" -> adventures.filter { !it.playable }
            else -> adventures
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = if (language == AppLanguage.EN) "Adventure Catalogue" else "Catalogue des Aventures",
                style = MaterialTheme.typography.headlineLarge,
                color = ChampagneGold
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to if (language == AppLanguage.EN) "All (${adventures.size})" else "Toutes (${adventures.size})",
                    "PLAYABLE" to strings.playableNow,
                    "UPCOMING" to strings.comingSoon
                ).forEach { (key, label) ->
                    val selected = filter == key
                    Surface(
                        shape = CircleShape,
                        color = if (selected) MetallicGold else VelvetSurface,
                        border = BorderStroke(1.dp, HairlineGold),
                        modifier = Modifier.clickable { filter = key }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (selected) ObsidianBlack else IvoryWhite,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            filtered.forEach { adv ->
                val title = AdventureCatalog.localizedTitle(adv, language)
                GoldSurfaceCard(contentPadding = 0.dp) {
                    ArtworkBanner(
                        artworkKey = adv.coverKey,
                        title = title,
                        subtitle = adv.subtitle,
                        badge = if (adv.playable) strings.playableNow.uppercase() else strings.comingSoon.uppercase(),
                        height = 160.dp
                    )
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            LuxuryPillTag(
                                text = "${adv.durationMinutes} min",
                                containerColor = DeepBurgundy
                            )
                            LuxuryPillTag(
                                text = "${adv.minPlayers}-${adv.maxPlayers} joueurs",
                                containerColor = VelvetSurface
                            )
                            LuxuryPillTag(
                                text = if (adv.priceUsd == 0.0) "GRATUIT" else "$${adv.priceUsd}",
                                containerColor = if (adv.playable) EmeraldTrust.copy(alpha = 0.35f) else VelvetSurface
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = adv.synopsis,
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmParchment
                        )
                        Spacer(Modifier.height(14.dp))

                        if (adv.playable) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GoldPrimaryButton(
                                    text = strings.soloMode,
                                    icon = Icons.Default.PlayArrow,
                                    testTag = "catalog_solo_${adv.id}",
                                    onClick = { pickerTarget = adv },
                                    modifier = Modifier.weight(1f)
                                )
                                if (adv.maxPlayers > 1) {
                                    LuxuryOutlineButton(
                                        text = "Salon",
                                        icon = Icons.Default.Groups,
                                        testTag = "catalog_multi_${adv.id}",
                                        onClick = { onCreateMultiplayerFor(adv) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LockClock, contentDescription = null, tint = MetallicGold)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (language == AppLanguage.EN) {
                                        "In production — included automatically in VIP Season Pass upon release."
                                    } else {
                                        "En cours de production — inclus dès la sortie dans l'abonnement VIP."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = ChampagneGold
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    pickerTarget?.let { adv ->
        val title = AdventureCatalog.localizedTitle(adv, language)
        CharacterPickerDialog(
            language = language,
            adventureTitle = title,
            onSelect = { character ->
                pickerTarget = null
                onLaunchSolo(adv.id, title, character)
            },
            onDismiss = { pickerTarget = null }
        )
    }
}
