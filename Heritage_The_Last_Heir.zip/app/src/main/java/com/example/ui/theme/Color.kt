package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Noir, Metallic Gold, Ivory & Deep Burgundy Palette
val ObsidianBlack = Color(0xFF07070A)
val MidnightCharcoal = Color(0xFF101016)
val VelvetSurface = Color(0xFF181720)
val ElevatedSlate = Color(0xFF22202B)

val MetallicGold = Color(0xFFD4AF37)
val ChampagneGold = Color(0xFFF3DC86)
val BurnishedBronze = Color(0xFF9C7A22)

val IvoryWhite = Color(0xFFF6F1E7)
val WarmParchment = Color(0xFFD9D0C1)
val MutedSmoke = Color(0xFF9B9489)

val DeepBurgundy = Color(0xFF6B1426)
val CrimsonVelvet = Color(0xFF9E223A)
val RoseAmber = Color(0xFFE07A8B)

val EmeraldTrust = Color(0xFF2E8B57)
val AlertCrimson = Color(0xFFCF455C)
val HairlineGold = Color(0x3DD4AF37)
