package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppLanguage
import com.example.core.PreferencesManager
import com.example.data.HeritageRepository
import com.example.model.Adventure
import com.example.model.AdventureCatalog
import com.example.model.GameRoom
import com.example.model.LeaderboardEntry
import com.example.model.PromoCode
import com.example.model.PurchaseOrder
import com.example.model.RoomMessage
import com.example.model.RoomPlayer
import com.example.model.RoomSecret
import com.example.model.RoomVote
import com.example.model.SoloSave
import com.example.model.SupportReport
import com.example.model.UserProfile
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

private fun <T> Flow<T>.toUiState(tag: String): Flow<UiState<T>> =
    map<T, UiState<T>> { UiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(tag, "Stream error", rootError)
            emit(UiState.Error(rootError.localizedMessage ?: "Erreur de synchronisation"))
        }

@OptIn(ExperimentalCoroutinesApi::class)
class HeritageViewModel(
    private val repository: HeritageRepository,
    private val prefs: PreferencesManager,
    val currentUserId: String,
    val userEmail: String?,
    val isEmailVerified: Boolean
) : ViewModel() {

    val isAdmin: Boolean = AdventureCatalog.isAdminEmail(userEmail) && isEmailVerified

    val language: StateFlow<AppLanguage> = prefs.languageFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AppLanguage.FR)

    val audioEnabled: StateFlow<Boolean> = prefs.audioEnabledFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    val voiceEnabled: StateFlow<Boolean> = prefs.voiceEnabledFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), true)

    val userProfile: StateFlow<UiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .toUiState("ProfileVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val soloSaves: StateFlow<UiState<List<SoloSave>>> = repository.observeSoloSaves(currentUserId)
        .toUiState("SavesVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val adventures: StateFlow<List<Adventure>> = repository.observeRemoteAdventures()
        .map { remote ->
            val byId = remote.associateBy { it.id }
            val merged = AdventureCatalog.defaultAdventures.map { def -> byId[def.id] ?: def }
            val customOnly = remote.filter { r -> AdventureCatalog.defaultAdventures.none { it.id == r.id } }
            merged + customOnly
        }
        .catch { emit(AdventureCatalog.defaultAdventures) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), AdventureCatalog.defaultAdventures)

    val leaderboard: StateFlow<UiState<List<LeaderboardEntry>>> = repository.observeLeaderboard()
        .toUiState("LeaderboardVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val myRooms: StateFlow<UiState<List<GameRoom>>> = repository.observeMyRooms(currentUserId)
        .toUiState("MyRoomsVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val myPurchases: StateFlow<UiState<List<PurchaseOrder>>> = repository.observeMyPurchases(currentUserId)
        .toUiState("PurchasesVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val mySupportReports: StateFlow<UiState<List<SupportReport>>> = repository.observeMySupportReports(currentUserId)
        .toUiState("SupportVM")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    // Active multiplayer room selection
    private val _activeRoomId = MutableStateFlow<String?>(null)
    val activeRoomId: StateFlow<String?> = _activeRoomId.asStateFlow()

    val activeRoom: StateFlow<GameRoom?> = _activeRoomId.flatMapLatest { rid ->
        if (rid.isNullOrBlank()) flowOf(null)
        else repository.observeRoom(rid).catch { emit(null) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val activeRoomPlayers: StateFlow<List<RoomPlayer>> = _activeRoomId.flatMapLatest { rid ->
        if (rid.isNullOrBlank()) flowOf(emptyList())
        else repository.observeRoomPlayers(rid).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val activeRoomSecret: StateFlow<RoomSecret?> = _activeRoomId.flatMapLatest { rid ->
        if (rid.isNullOrBlank()) flowOf(null)
        else repository.observeMySecret(rid, currentUserId).catch { emit(null) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), null)

    val activeRoomMessages: StateFlow<List<RoomMessage>> = _activeRoomId.flatMapLatest { rid ->
        if (rid.isNullOrBlank()) flowOf(emptyList())
        else repository.observeRoomMessages(rid, currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val activeRoomVotes: StateFlow<List<RoomVote>> = _activeRoomId.flatMapLatest { rid ->
        if (rid.isNullOrBlank()) flowOf(emptyList())
        else repository.observeRoomVotes(rid, currentUserId).catch { emit(emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Admin streams (never instantiated unless isAdmin == true)
    val adminPurchases: StateFlow<List<PurchaseOrder>> =
        if (isAdmin) repository.adminObserveAllPurchases().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        else MutableStateFlow(emptyList())

    val adminReports: StateFlow<List<SupportReport>> =
        if (isAdmin) repository.adminObserveAllReports().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        else MutableStateFlow(emptyList())

    val adminUsers: StateFlow<List<UserProfile>> =
        if (isAdmin) repository.adminObserveAllUsers().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        else MutableStateFlow(emptyList())

    val adminPromoCodes: StateFlow<List<PromoCode>> =
        if (isAdmin) repository.adminObservePromoCodes().catch { emit(emptyList()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())
        else MutableStateFlow(emptyList())

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val _validatedPromo = MutableStateFlow<PromoCode?>(null)
    val validatedPromo: StateFlow<PromoCode?> = _validatedPromo.asStateFlow()

    fun bootstrapUser(user: FirebaseUser) {
        viewModelScope.launch {
            repository.ensureUserProfile(user, language.value.code)
        }
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun setLanguage(lang: AppLanguage) {
        viewModelScope.launch {
            prefs.setLanguage(lang)
            val profile = (userProfile.value as? UiState.Success)?.data
            if (profile != null) {
                repository.updateProfile(profile.alias, lang.code, null)
            }
        }
    }

    fun setAudioEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setAudioEnabled(enabled) }
    }

    fun setVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch { prefs.setVoiceEnabled(enabled) }
    }

    fun updateProfile(alias: String, referredBy: String?) {
        viewModelScope.launch {
            val res = repository.updateProfile(alias, language.value.code, referredBy)
            _feedbackMessage.value = if (res.isSuccess) "Profil mis à jour." else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun selectRoom(roomId: String?) {
        _activeRoomId.value = roomId
    }

    fun createRoom(
        adventureId: String,
        adventureTitle: String,
        mode: String,
        maxPlayers: Int,
        eventOrgName: String?,
        onCreated: (String) -> Unit
    ) {
        viewModelScope.launch {
            val alias = (userProfile.value as? UiState.Success)?.data?.alias ?: "Hôte"
            val res = repository.createRoom(alias, adventureId, adventureTitle, mode, maxPlayers, eventOrgName)
            res.onSuccess { rid ->
                _activeRoomId.value = rid
                onCreated(rid)
            }.onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Impossible de créer le salon."
            }
        }
    }

    fun joinRoomByCode(code: String, onJoined: (String) -> Unit) {
        viewModelScope.launch {
            val alias = (userProfile.value as? UiState.Success)?.data?.alias ?: "Héritier"
            val res = repository.joinRoomByCode(code, alias)
            res.onSuccess { rid ->
                _activeRoomId.value = rid
                onJoined(rid)
            }.onFailure { err ->
                _feedbackMessage.value = err.localizedMessage ?: "Salon introuvable."
            }
        }
    }

    fun selectCharacterInRoom(roomId: String, characterId: String, characterName: String, roleTitle: String) {
        viewModelScope.launch {
            repository.updateMyRoomSeat(roomId, characterId = characterId, characterName = characterName, roleTitle = roleTitle)
        }
    }

    fun toggleReadyInRoom(roomId: String, ready: Boolean) {
        viewModelScope.launch {
            repository.updateMyRoomSeat(roomId, ready = ready)
        }
    }

    fun assignRandomRoles(roomId: String) {
        viewModelScope.launch {
            val res = repository.hostAssignRolesRandomly(roomId, activeRoomPlayers.value)
            if (res.isFailure) _feedbackMessage.value = res.exceptionOrNull()?.localizedMessage
        }
    }

    fun startMultiplayerMatch(roomId: String) {
        viewModelScope.launch {
            repository.hostUpdateRoomProgress(roomId, status = "IN_PROGRESS", chapter = 1L)
        }
    }

    fun advanceMultiplayerChapter(roomId: String, nextChapter: Long, finished: Boolean) {
        viewModelScope.launch {
            repository.hostUpdateRoomProgress(
                roomId = roomId,
                status = if (finished) "FINISHED" else "IN_PROGRESS",
                chapter = nextChapter.coerceIn(1L, 10L)
            )
        }
    }

    fun sendRoomMessage(roomId: String, body: String, recipientUid: String?) {
        viewModelScope.launch {
            val alias = (userProfile.value as? UiState.Success)?.data?.alias ?: "Héritier"
            val members = activeRoom.value?.memberUids ?: listOf(currentUserId)
            val res = repository.sendRoomMessage(roomId, alias, body, recipientUid, members)
            if (res.isFailure) _feedbackMessage.value = res.exceptionOrNull()?.localizedMessage
        }
    }

    fun castRoomVote(roomId: String, chapter: Int, targetId: String, targetName: String) {
        viewModelScope.launch {
            val members = activeRoom.value?.memberUids ?: listOf(currentUserId)
            val res = repository.castRoomVote(roomId, chapter, targetId, targetName, members)
            _feedbackMessage.value = if (res.isSuccess) "Vote confidentiel enregistré." else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun validatePromo(code: String) {
        viewModelScope.launch {
            val res = repository.validatePromoCode(code)
            res.onSuccess { promo ->
                _validatedPromo.value = promo
                _feedbackMessage.value = "Code ${promo.code} appliqué (-${promo.discountPercent}%)"
            }.onFailure { err ->
                _validatedPromo.value = null
                _feedbackMessage.value = err.localizedMessage ?: "Code invalide"
            }
        }
    }

    fun submitOrder(offerId: String, title: String, finalUsd: Double, paymentMethod: String, referenceNote: String?) {
        viewModelScope.launch {
            val res = repository.submitPurchaseOrder(
                offerId = offerId,
                title = title,
                amountUsd = finalUsd,
                paymentMethod = paymentMethod,
                promoCode = _validatedPromo.value?.code,
                referenceNote = referenceNote
            )
            _feedbackMessage.value = if (res.isSuccess) {
                "Commande enregistrée (en attente de vérification serveur)."
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Erreur lors de la commande."
            }
        }
    }

    fun submitSupport(category: String, subject: String, message: String) {
        viewModelScope.launch {
            val res = repository.submitSupportReport(userEmail, category, subject, message)
            _feedbackMessage.value = if (res.isSuccess) {
                "Ticket transmis à l'équipe d'assistance."
            } else {
                res.exceptionOrNull()?.localizedMessage ?: "Envoi impossible."
            }
        }
    }

    // Admin actions
    fun adminPublishAdventure(title: String, subtitle: String, synopsis: String, tier: String, priceUsd: Double, chaptersText: String) {
        viewModelScope.launch {
            val chapters = chaptersText.lines().map { it.trim() }.filter { it.isNotBlank() }.ifEmpty {
                listOf("Chapitre 1 : Ouverture", "Chapitre 2 : Révélation")
            }
            val res = repository.adminPublishAdventure(title, subtitle, synopsis, tier, priceUsd, chapters)
            _feedbackMessage.value = if (res.isSuccess) "Aventure publiée dans le catalogue !" else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminCreatePromo(code: String, discount: Int, maxUses: Int) {
        viewModelScope.launch {
            val res = repository.adminCreatePromoCode(code, discount, maxUses)
            _feedbackMessage.value = if (res.isSuccess) "Code promo $code créé." else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminVerifyOrder(order: PurchaseOrder, approve: Boolean) {
        viewModelScope.launch {
            val res = repository.adminVerifyPurchaseAndUnlock(order, approve)
            _feedbackMessage.value = if (res.isSuccess) {
                if (approve) "Paiement vérifié et offre débloquée." else "Commande refusée."
            } else res.exceptionOrNull()?.localizedMessage
        }
    }

    fun adminResolveReport(reportId: String, reply: String) {
        viewModelScope.launch {
            val res = repository.adminResolveSupportReport(reportId, reply)
            _feedbackMessage.value = if (res.isSuccess) "Signalement résolu." else res.exceptionOrNull()?.localizedMessage
        }
    }
}
