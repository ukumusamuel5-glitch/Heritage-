package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.AdventureCatalog
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.ActiveGameState

@Composable
fun ResultsScreen(
    language: AppLanguage,
    gameState: ActiveGameState,
    onReturnHome: () -> Unit
) {
    BackHandler { onReturnHome() }
    val context = LocalContext.current
    val strings = AppStrings.get(language)
    val ending = gameState.ending ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ArtworkBanner(
                artworkKey = "testament",
                title = if (language == AppLanguage.EN) ending.titleEn else ending.titleFr,
                subtitle = "${gameState.adventureTitle} • ${gameState.character.name}",
                badge = if (language == AppLanguage.EN) ending.badgeEn else ending.badgeFr,
                height = 210.dp
            )

            // Shareable Victory Card
            GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.72f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = MetallicGold)
                    LuxuryPillTag(text = "CARTE DE VICTOIRE HÉRITAGE")
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (language == AppLanguage.EN) ending.summaryEn else ending.summaryFr,
                    style = MaterialTheme.typography.bodyLarge,
                    color = IvoryWhite
                )
                HorizontalDivider(color = HairlineGold, modifier = Modifier.padding(vertical = 12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatColumn("SCORE", "${gameState.score} pts")
                    StatColumn("FORTUNE", "${gameState.virtualWealthM} M$")
                    StatColumn("RÉPUTATION", "${gameState.reputation}/100")
                    StatColumn("INDICES", "${gameState.discoveredClues.size}")
                }
                Spacer(Modifier.height(14.dp))
                GoldPrimaryButton(
                    text = strings.shareVictoryCard,
                    icon = Icons.Default.Share,
                    testTag = "share_victory_card_button",
                    onClick = {
                        val cardText = buildString {
                            append("🏆 HÉRITAGE — THE LAST HEIR\n")
                            append("Verdict : ${if (language == AppLanguage.EN) ending.titleEn else ending.titleFr}\n")
                            append("Héritier : ${gameState.character.name}\n")
                            append("Score : ${gameState.score} pts | Fortune virtuelle : ${gameState.virtualWealthM} M$\n")
                            append("Relevez l'épreuve : Tout le monde a un secret. Un seul héritera de l'empire.")
                        }
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, cardText)
                        }
                        context.startActivity(Intent.createChooser(intent, strings.shareVictoryCard))
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Secrets Revealed
            GoldSurfaceCard {
                Text(
                    text = if (language == AppLanguage.EN) "All Secrets Revealed" else "Révélation des Secrets des Héritiers",
                    style = MaterialTheme.typography.titleLarge,
                    color = ChampagneGold
                )
                Spacer(Modifier.height(10.dp))
                AdventureCatalog.heirs.forEachIndexed { idx, heir ->
                    Text(heir.name, style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Text(
                        text = if (language == AppLanguage.EN) heir.secretObjectiveEn else heir.secretObjectiveFr,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmParchment
                    )
                    if (idx < AdventureCatalog.heirs.lastIndex) {
                        HorizontalDivider(color = HairlineGold, modifier = Modifier.padding(vertical = 8.dp))
                    }
                }
            }

            LuxuryOutlineButton(
                text = strings.navHome,
                icon = Icons.Default.Home,
                testTag = "return_home_button",
                onClick = onReturnHome,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MetallicGold)
        Text(value, style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
    }
}
