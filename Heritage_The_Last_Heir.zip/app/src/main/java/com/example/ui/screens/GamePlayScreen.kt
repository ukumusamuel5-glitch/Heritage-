package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HowToVote
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.core.SoundEffects
import com.example.model.AdventureCatalog
import com.example.model.GameRoom
import com.example.model.RoomMessage
import com.example.model.RoomPlayer
import com.example.model.RoomSecret
import com.example.model.RoomVote
import com.example.model.StoryEngineData
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.BurgundyAccentButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonVelvet
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.ActiveGameState

@Composable
fun GamePlayScreen(
    language: AppLanguage,
    gameState: ActiveGameState,
    currentUserId: String,
    soundEffects: SoundEffects,
    audioEnabled: Boolean,
    voiceEnabled: Boolean,
    activeRoom: GameRoom?,
    roomPlayers: List<RoomPlayer>,
    roomSecret: RoomSecret?,
    roomMessages: List<RoomMessage>,
    roomVotes: List<RoomVote>,
    onMakeChoice: (com.example.model.StoryChoice) -> Unit,
    onUnlockVault: (String) -> Unit,
    onSendAiNegotiation: (com.example.model.CharacterArchetype, String) -> Unit,
    onSendRoomMessage: (String, String?) -> Unit,
    onCastSoloVote: (String) -> Unit,
    onCastRoomVote: (Int, String, String) -> Unit,
    onHostAdvanceChapter: (Long, Boolean) -> Unit,
    onExitGame: () -> Unit
) {
    BackHandler { onExitGame() }

    val strings = AppStrings.get(language)
    val chapter = gameState.chapters.getOrNull(gameState.currentChapterIndex) ?: return
    var selectedTab by remember { mutableIntStateOf(0) }
    var vaultInput by remember { mutableStateOf("") }
    var callAnswered by remember { mutableStateOf(false) }

    // AI / Room Comms state
    val rivals = remember(gameState.character.id) {
        AdventureCatalog.heirs.filter { it.id != gameState.character.id }
    }
    var selectedRival by remember { mutableStateOf(rivals.first()) }
    var chatInput by remember { mutableStateOf("") }
    var whisperTargetUid by remember { mutableStateOf<String?>(null) }

    val mins = gameState.countdownSeconds / 60
    val secs = gameState.countdownSeconds % 60
    val timerFormatted = "%02d:%02d".format(mins, secs)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 620.dp).fillMaxSize()) {
            // Top HUD Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onExitGame) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit", tint = ChampagneGold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(gameState.adventureTitle, style = MaterialTheme.typography.titleMedium, color = ChampagneGold, maxLines = 1)
                    Text(
                        "${gameState.character.name} • ${strings.chaptersLabel} ${chapter.number}/${gameState.chapters.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = WarmParchment
                    )
                }
                LuxuryPillTag(
                    text = timerFormatted,
                    containerColor = if (gameState.countdownSeconds < 30) AlertCrimson else DeepBurgundy
                )
            }

            LinearProgressIndicator(
                progress = { (gameState.currentChapterIndex + 1).toFloat() / gameState.chapters.size.coerceAtLeast(1) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                color = MetallicGold,
                trackColor = VelvetSurface
            )

            // Stats Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                HudPill("${strings.wealthLabel}: ${gameState.virtualWealthM}M$", Modifier.weight(1f))
                HudPill("${strings.reputationLabel}: ${gameState.reputation}", Modifier.weight(1f))
                HudPill("${strings.scoreLabel}: ${gameState.score}", Modifier.weight(1f))
            }

            Spacer(Modifier.height(10.dp))

            // 5 Sub-Tabs
            val tabs = listOf(
                strings.tabStory,
                strings.tabComms,
                strings.tabBoard,
                strings.tabInventory,
                strings.tabVotes
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEachIndexed { idx, label ->
                    val active = selectedTab == idx
                    Surface(
                        shape = CircleShape,
                        color = if (active) MetallicGold else VelvetSurface,
                        border = BorderStroke(1.dp, HairlineGold),
                        modifier = Modifier
                            .clickable { selectedTab = idx }
                            .testTag("game_tab_$idx")
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (active) ObsidianBlack else IvoryWhite,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Active Tab Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (selectedTab) {
                    // TAB 0: STORY, AUDIO ARCHIVE, CALL, VAULT PUZZLE & CHOICES
                    0 -> {
                        if (!gameState.lastConsequence.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = EmeraldTrust.copy(alpha = 0.22f),
                                border = BorderStroke(1.dp, EmeraldTrust)
                            ) {
                                Text(
                                    text = gameState.lastConsequence,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = IvoryWhite,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        ArtworkBanner(
                            artworkKey = chapter.artworkKey,
                            title = StoryEngineData.localizedTitle(chapter, language),
                            badge = if (activeRoom != null) "MULTIJOUEUR SYNCHRONISÉ" else "SOLO INTERACTIF",
                            height = 175.dp
                        )

                        GoldSurfaceCard {
                            Text(
                                text = StoryEngineData.localizedNarrative(chapter, language),
                                style = MaterialTheme.typography.bodyLarge,
                                color = IvoryWhite
                            )
                            Spacer(Modifier.height(12.dp))
                            LuxuryOutlineButton(
                                text = strings.listenAudio,
                                icon = Icons.AutoMirrored.Filled.VolumeUp,
                                testTag = "play_audio_archive_button",
                                onClick = {
                                    val transcript = if (language == AppLanguage.EN) chapter.audioTranscriptEn else chapter.audioTranscriptFr
                                    soundEffects.playRevealCue(audioEnabled)
                                    soundEffects.speakArchive(transcript, language, voiceEnabled)
                                },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Simulated Incoming Encrypted Call
                        if (!chapter.incomingCallFrom.isNullOrBlank()) {
                            GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.75f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Call, contentDescription = null, tint = ChampagneGold)
                                    Spacer(Modifier.width(8.dp))
                                    Text("${strings.incomingCall} • ${chapter.incomingCallFrom}", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                                }
                                Spacer(Modifier.height(8.dp))
                                if (!callAnswered) {
                                    GoldPrimaryButton(
                                        text = "Décrocher l'appel crypté",
                                        icon = Icons.Default.Call,
                                        onClick = {
                                            callAnswered = true
                                            soundEffects.playIncomingCallRing(audioEnabled)
                                            val msg = if (language == AppLanguage.EN) chapter.incomingCallMsgEn.orEmpty() else chapter.incomingCallMsgFr.orEmpty()
                                            soundEffects.speakArchive(msg, language, voiceEnabled)
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else {
                                    Text(
                                        text = if (language == AppLanguage.EN) chapter.incomingCallMsgEn.orEmpty() else chapter.incomingCallMsgFr.orEmpty(),
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = IvoryWhite
                                    )
                                }
                            }
                        }

                        // Virtual Safe / Logic Enigma Puzzle
                        chapter.puzzle?.let { puzzle ->
                            val unlocked = gameState.unlockedVaults.contains(puzzle.id)
                            GoldSurfaceCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LockOpen, contentDescription = null, tint = MetallicGold)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        if (language == AppLanguage.EN) puzzle.titleEn else puzzle.titleFr,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = ChampagneGold
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    if (language == AppLanguage.EN) puzzle.hintEn else puzzle.hintFr,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WarmParchment
                                )
                                Spacer(Modifier.height(10.dp))
                                if (unlocked) {
                                    LuxuryPillTag(text = "COFFRE OUVERT (+${puzzle.wealthBonusM}M$)", containerColor = EmeraldTrust.copy(alpha = 0.35f))
                                } else {
                                    OutlinedTextField(
                                        value = vaultInput,
                                        onValueChange = { vaultInput = it },
                                        label = { Text("Combinaison") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("vault_code_input"),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MetallicGold,
                                            unfocusedBorderColor = HairlineGold,
                                            focusedTextColor = IvoryWhite,
                                            unfocusedTextColor = IvoryWhite
                                        )
                                    )
                                    if (!gameState.vaultFeedback.isNullOrBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(gameState.vaultFeedback, style = MaterialTheme.typography.bodyMedium, color = ChampagneGold)
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    BurgundyAccentButton(
                                        text = strings.openVault,
                                        icon = Icons.Default.Key,
                                        testTag = "unlock_vault_button",
                                        onClick = {
                                            soundEffects.playVaultUnlockCue(audioEnabled)
                                            onUnlockVault(vaultInput)
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        // Strategic Choices
                        GoldSurfaceCard {
                            Text(
                                text = if (language == AppLanguage.EN) "Your Strategic Decision" else "Votre Décision Stratégique",
                                style = MaterialTheme.typography.titleLarge,
                                color = ChampagneGold
                            )
                            Spacer(Modifier.height(10.dp))
                            chapter.choices.forEach { choice ->
                                GoldPrimaryButton(
                                    text = if (language == AppLanguage.EN) choice.labelEn else choice.labelFr,
                                    testTag = "choice_${choice.id}",
                                    onClick = {
                                        callAnswered = false
                                        vaultInput = ""
                                        soundEffects.playRevealCue(audioEnabled)
                                        onMakeChoice(choice)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // TAB 1: COMMS & LIVE GEMINI AI NEGOTIATION / MULTIPLAYER CHAT
                    1 -> {
                        if (activeRoom == null) {
                            GoldSurfaceCard {
                                Text(strings.negotiateAi, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rivals.forEach { rival ->
                                        val selected = rival.id == selectedRival.id
                                        Surface(
                                            shape = CircleShape,
                                            color = if (selected) MetallicGold else MidnightCharcoal,
                                            border = BorderStroke(1.dp, HairlineGold),
                                            modifier = Modifier.clickable { selectedRival = rival }
                                        ) {
                                            Text(
                                                text = rival.name,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = if (selected) ObsidianBlack else IvoryWhite,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    text = if (language == AppLanguage.EN) selectedRival.backgroundEn else selectedRival.backgroundFr,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WarmParchment
                                )
                                HorizontalDivider(color = HairlineGold, modifier = Modifier.padding(vertical = 10.dp))

                                val thread = gameState.aiChats[selectedRival.id].orEmpty()
                                if (thread.isEmpty()) {
                                    Text(
                                        text = "Proposez une alliance, négociez un échange d'indices ou bluffez ${selectedRival.name}.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = ChampagneGold
                                    )
                                } else {
                                    thread.forEach { msg ->
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (msg.isPlayer) DeepBurgundy.copy(alpha = 0.7f) else MidnightCharcoal,
                                            border = BorderStroke(1.dp, HairlineGold),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(10.dp)) {
                                                Text(msg.sender, style = MaterialTheme.typography.labelSmall, color = MetallicGold)
                                                Text(msg.text, style = MaterialTheme.typography.bodyMedium, color = IvoryWhite)
                                                if (!msg.badge.isNullOrBlank()) {
                                                    Spacer(Modifier.height(4.dp))
                                                    LuxuryPillTag(text = msg.badge)
                                                }
                                            }
                                        }
                                    }
                                }

                                if (gameState.isAiThinking) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 8.dp)) {
                                        CircularProgressIndicator(color = MetallicGold, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                        Spacer(Modifier.width(8.dp))
                                        Text("${selectedRival.name} réfléchit...", style = MaterialTheme.typography.bodyMedium, color = ChampagneGold)
                                    }
                                }
                                if (!gameState.aiError.isNullOrBlank()) {
                                    Text(gameState.aiError, style = MaterialTheme.typography.bodyMedium, color = AlertCrimson)
                                }

                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = chatInput,
                                        onValueChange = { chatInput = it },
                                        label = { Text("Votre message stratégique") },
                                        modifier = Modifier.weight(1f),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MetallicGold,
                                            unfocusedBorderColor = HairlineGold,
                                            focusedTextColor = IvoryWhite,
                                            unfocusedTextColor = IvoryWhite
                                        )
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    IconButton(
                                        enabled = !gameState.isAiThinking && chatInput.isNotBlank(),
                                        onClick = {
                                            val text = chatInput
                                            chatInput = ""
                                            onSendAiNegotiation(selectedRival, text)
                                        }
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.sendMessage, tint = MetallicGold)
                                    }
                                }
                            }
                        } else {
                            // Multiplayer Public & Private Whisper Chat
                            GoldSurfaceCard {
                                Text("Messagerie du Salon (${activeRoom.roomCode})", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (whisperTargetUid == null) MetallicGold else MidnightCharcoal,
                                        border = BorderStroke(1.dp, HairlineGold),
                                        modifier = Modifier.clickable { whisperTargetUid = null }
                                    ) {
                                        Text(
                                            strings.publicChat,
                                            color = if (whisperTargetUid == null) ObsidianBlack else IvoryWhite,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                    roomPlayers.filter { it.uid != currentUserId }.forEach { other ->
                                        val selected = whisperTargetUid == other.uid
                                        Surface(
                                            shape = CircleShape,
                                            color = if (selected) CrimsonVelvet else MidnightCharcoal,
                                            border = BorderStroke(1.dp, HairlineGold),
                                            modifier = Modifier.clickable { whisperTargetUid = other.uid }
                                        ) {
                                            Text(
                                                "${strings.privateWhisper}: ${other.displayName}",
                                                color = IvoryWhite,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(10.dp))
                                roomMessages.forEach { msg ->
                                    val isPrivate = !msg.recipientUid.isNullOrBlank()
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (isPrivate) DeepBurgundy.copy(alpha = 0.7f) else MidnightCharcoal,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = if (isPrivate) "${msg.senderName} [Confidentiel]" else msg.senderName,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ChampagneGold
                                            )
                                            Text(msg.body, style = MaterialTheme.typography.bodyMedium, color = IvoryWhite)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = chatInput,
                                        onValueChange = { chatInput = it },
                                        label = { Text(if (whisperTargetUid == null) "Message public" else "Message confidentiel") },
                                        modifier = Modifier.weight(1f),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = MetallicGold,
                                            unfocusedBorderColor = HairlineGold,
                                            focusedTextColor = IvoryWhite,
                                            unfocusedTextColor = IvoryWhite
                                        )
                                    )
                                    IconButton(
                                        enabled = chatInput.isNotBlank(),
                                        onClick = {
                                            val body = chatInput
                                            chatInput = ""
                                            onSendRoomMessage(body, whisperTargetUid)
                                        }
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = strings.sendMessage, tint = MetallicGold)
                                    }
                                }
                            }
                        }
                    }

                    // TAB 2: INVESTIGATION BOARD & CLUES
                    2 -> {
                        GoldSurfaceCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = MetallicGold)
                                Spacer(Modifier.width(8.dp))
                                Text("Tableau d'Enquête (${gameState.discoveredClues.size})", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            }
                            Spacer(Modifier.height(10.dp))
                            if (gameState.discoveredClues.isEmpty()) {
                                Text(
                                    "Aucun indice classé pour l'instant. Inspectez les preuves et forcez les coffres.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = WarmParchment
                                )
                            } else {
                                gameState.discoveredClues.mapNotNull { StoryEngineData.cluesLibrary[it] }.forEach { clue ->
                                    ArtworkBanner(
                                        artworkKey = clue.artworkKey,
                                        title = if (language == AppLanguage.EN) clue.titleEn else clue.titleFr,
                                        subtitle = if (language == AppLanguage.EN) clue.categoryEn else clue.categoryFr,
                                        height = 125.dp
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        if (language == AppLanguage.EN) clue.bodyEn else clue.bodyFr,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = IvoryWhite
                                    )
                                    HorizontalDivider(color = HairlineGold, modifier = Modifier.padding(vertical = 10.dp))
                                }
                            }
                        }
                    }

                    // TAB 3: SECRET MISSIONS & INVENTORY
                    3 -> {
                        GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.65f)) {
                            Text("Objectif Secret Personnel", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = roomSecret?.secretObjective
                                    ?: if (language == AppLanguage.EN) gameState.character.secretObjectiveEn else gameState.character.secretObjectiveFr,
                                style = MaterialTheme.typography.bodyLarge,
                                color = IvoryWhite
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Indice de départ : ${roomSecret?.secretClue ?: if (language == AppLanguage.EN) gameState.character.secretClueEn else gameState.character.secretClueFr}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmParchment
                            )
                        }

                        GoldSurfaceCard {
                            Text("Missions & Inventaire", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            Spacer(Modifier.height(8.dp))
                            StoryEngineData.missionsList.forEach { mission ->
                                val done = gameState.completedMissions.contains(mission.id)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = if (done) EmeraldTrust else WarmParchment.copy(alpha = 0.35f)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            if (language == AppLanguage.EN) mission.titleEn else mission.titleFr,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (done) ChampagneGold else IvoryWhite
                                        )
                                    }
                                    LuxuryPillTag(text = "+${mission.points} pts")
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Alliés actifs : ${if (gameState.allies.isEmpty()) "Aucun pour l'instant" else gameState.allies.joinToString(", ")}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = ChampagneGold
                            )
                        }
                    }

                    // TAB 4: COLLECTIVE & CONFIDENTIAL COUNCIL VOTES
                    4 -> {
                        GoldSurfaceCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HowToVote, contentDescription = null, tint = MetallicGold)
                                Spacer(Modifier.width(8.dp))
                                Text("Conseil & Votes Confidentiels", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            }
                            Spacer(Modifier.height(8.dp))

                            if (activeRoom == null) {
                                Text("Votez pour l'héritier le plus crédible ou désignez votre allié prioritaire :", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                Spacer(Modifier.height(8.dp))
                                AdventureCatalog.heirs.forEach { heir ->
                                    val voted = gameState.soloVoteWinner == heir.name
                                    LuxuryOutlineButton(
                                        text = if (voted) "Voté : ${heir.name}" else "Voter pour ${heir.name}",
                                        onClick = { onCastSoloVote(heir.name) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                    )
                                }
                            } else {
                                Text("Votes synchronisés dans le salon (${roomVotes.size} enregistrés) :", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                Spacer(Modifier.height(8.dp))
                                roomPlayers.forEach { player ->
                                    val voteCount = roomVotes.count { it.chapter.toInt() == chapter.number && it.targetId == player.uid }
                                    LuxuryOutlineButton(
                                        text = "${player.displayName} (${player.characterName}) • $voteCount voix",
                                        onClick = { onCastRoomVote(chapter.number, player.uid, player.displayName) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                    )
                                }
                                if (activeRoom.hostUid == currentUserId) {
                                    Spacer(Modifier.height(12.dp))
                                    val isLast = chapter.number >= gameState.chapters.size
                                    GoldPrimaryButton(
                                        text = if (isLast) "Clôturer le conseil & Révéler le verdict" else "Hôte : Passer au chapitre ${chapter.number + 1}",
                                        onClick = { onHostAdvanceChapter((chapter.number + 1).toLong(), isLast) },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun HudPill(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = VelvetSurface,
        border = BorderStroke(1.dp, HairlineGold)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = ChampagneGold,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            maxLines = 1
        )
    }
}
