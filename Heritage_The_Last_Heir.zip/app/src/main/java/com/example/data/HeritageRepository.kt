package com.example.data

import android.content.Context
import com.example.R
import com.example.model.Adventure
import com.example.model.AdventureCatalog
import com.example.model.GameRoom
import com.example.model.LeaderboardEntry
import com.example.model.PromoCode
import com.example.model.PurchaseOrder
import com.example.model.RoomMessage
import com.example.model.RoomPlayer
import com.example.model.RoomSecret
import com.example.model.RoomVote
import com.example.model.SoloSave
import com.example.model.SupportReport
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class HeritageRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String =
        auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")

    private fun <T> Flow<T>.guardFirestoreErrors(
        uid: String,
        operationType: OperationType,
        path: String
    ): Flow<T> = catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, operationType, path)
        }
        throw error
    }

    // --- USER PROFILE & LEADERBOARD ---

    suspend fun ensureUserProfile(user: FirebaseUser, preferredLanguage: String): Result<Unit> {
        val path = "users/${user.uid}"
        return try {
            val uid = requireUserId()
            check(uid == user.uid)
            val docRef = db.collection("users").document(uid)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                val defaultAlias = (user.displayName?.takeIf { it.length >= 2 } ?: "Héritier_${uid.take(5)}").take(40)
                val referralCode = "HER${uid.take(6).uppercase()}"
                val payload = mapOf(
                    "userId" to uid,
                    "alias" to defaultAlias,
                    "email" to (user.email ?: "").take(120),
                    "language" to preferredLanguage,
                    "reputation" to 50L,
                    "totalWealthM" to 100L,
                    "gamesPlayed" to 0L,
                    "gamesWon" to 0L,
                    "trophies" to emptyList<String>(),
                    "activePlan" to "FREE",
                    "referralCode" to referralCode,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()

                val lbPayload = mapOf(
                    "userId" to uid,
                    "alias" to defaultAlias,
                    "reputation" to 50L,
                    "totalWealthM" to 100L,
                    "gamesWon" to 0L,
                    "trophiesCount" to 0L,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                db.collection("leaderboard").document(uid).set(lbPayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        val path = "users/$userId"
        emitAll(
            db.collection("users").document(userId)
                .snapshots()
                .map { snap -> snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.GET, path)
        )
    }

    suspend fun updateProfile(alias: String, language: String, referredBy: String?): Result<Unit> {
        val uid = auth.currentUser?.uid ?: "unauthenticated"
        val path = "users/$uid"
        return try {
            val activeUid = requireUserId()
            val cleanAlias = alias.trim().take(40)
            require(cleanAlias.length >= 2) { "Alias must be at least 2 characters" }
            val updates = mutableMapOf<String, Any>(
                "alias" to cleanAlias,
                "language" to language,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!referredBy.isNullOrBlank()) {
                updates["referredBy"] = referredBy.trim().take(20)
            }
            db.collection("users").document(activeUid).update(updates).await()
            db.collection("leaderboard").document(activeUid).update(
                mapOf(
                    "alias" to cleanAlias,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    fun observeLeaderboard(): Flow<List<LeaderboardEntry>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("leaderboard")
                .orderBy("totalWealthM", Query.Direction.DESCENDING)
                .limit(30)
                .snapshots()
                .map { it.toObjects(LeaderboardEntry::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "leaderboard")
        )
    }

    // --- SOLO SAVES ---

    fun observeSoloSaves(userId: String): Flow<List<SoloSave>> = flow {
        val uid = requireUserId()
        val path = "users/$userId/solo_saves"
        emitAll(
            db.collection("users").document(userId).collection("solo_saves")
                .snapshots()
                .map { it.toObjects(SoloSave::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, path)
        )
    }

    suspend fun upsertSoloSave(save: SoloSave): Result<String> {
        val uid = auth.currentUser?.uid ?: "unauthenticated"
        val saveId = save.id.ifBlank { "save_${UUID.randomUUID().toString().replace("-", "").take(12)}" }
        val path = "users/$uid/solo_saves/$saveId"
        return try {
            val activeUid = requireUserId()
            val docRef = db.collection("users").document(activeUid).collection("solo_saves").document(saveId)
            val existing = docRef.get().await()
            if (!existing.exists()) {
                val payload = mapOf(
                    "userId" to activeUid,
                    "adventureId" to save.adventureId.take(64),
                    "adventureTitle" to save.adventureTitle.take(100),
                    "characterId" to save.characterId.take(64),
                    "characterName" to save.characterName.take(60),
                    "currentChapter" to save.currentChapter.coerceIn(1L, 20L),
                    "score" to save.score.coerceAtLeast(0L),
                    "virtualWealthM" to save.virtualWealthM.coerceIn(0L, 1000L),
                    "reputation" to save.reputation.coerceIn(0L, 100L),
                    "discoveredClues" to save.discoveredClues.take(50),
                    "completedMissions" to save.completedMissions.take(30),
                    "unlockedVaults" to save.unlockedVaults.take(20),
                    "allies" to save.allies.take(20),
                    "decisionsLog" to save.decisionsLog.take(50),
                    "endingId" to save.endingId?.take(64),
                    "status" to save.status,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }
                docRef.set(payload).await()
            } else {
                val updates = mutableMapOf<String, Any>(
                    "currentChapter" to save.currentChapter.coerceIn(1L, 20L),
                    "score" to save.score.coerceAtLeast(0L),
                    "virtualWealthM" to save.virtualWealthM.coerceIn(0L, 1000L),
                    "reputation" to save.reputation.coerceIn(0L, 100L),
                    "discoveredClues" to save.discoveredClues.take(50),
                    "completedMissions" to save.completedMissions.take(30),
                    "unlockedVaults" to save.unlockedVaults.take(20),
                    "allies" to save.allies.take(20),
                    "decisionsLog" to save.decisionsLog.take(50),
                    "status" to save.status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                save.endingId?.take(64)?.let { updates["endingId"] = it }
                docRef.update(updates).await()
            }

            if (save.status == "COMPLETED") {
                recordGameCompletion(activeUid, save.virtualWealthM, save.reputation, save.endingId)
            }
            Result.success(saveId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    private suspend fun recordGameCompletion(
        uid: String,
        wealthEarnedM: Long,
        reputation: Long,
        endingId: String?
    ) {
        val userRef = db.collection("users").document(uid)
        val snap = userRef.get().await()
        val currentPlayed = snap.getLong("gamesPlayed") ?: 0L
        val currentWon = snap.getLong("gamesWon") ?: 0L
        val currentWealth = snap.getLong("totalWealthM") ?: 100L
        val currentTrophies = (snap.get("trophies") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
        val newTrophy = when (endingId) {
            "sole_heir" -> "Couronne d'Or Vance"
            "iron_mogul" -> "Souverain des Coffres"
            "truth_guardian" -> "Sceau d'Intégrité"
            else -> "Survivant du Manoir"
        }
        val mergedTrophies = (currentTrophies + newTrophy).distinct().take(30)
        val wonIncrement = if (endingId == "sole_heir" || endingId == "iron_mogul") 1L else 0L
        val updatedWealth = (currentWealth + wealthEarnedM).coerceAtMost(1000000L)
        val updatedGamesWon = currentWon + wonIncrement

        userRef.update(
            mapOf(
                "gamesPlayed" to currentPlayed + 1L,
                "gamesWon" to updatedGamesWon,
                "totalWealthM" to updatedWealth,
                "reputation" to reputation.coerceIn(0L, 100L),
                "trophies" to mergedTrophies,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()

        db.collection("leaderboard").document(uid).update(
            mapOf(
                "totalWealthM" to updatedWealth,
                "reputation" to reputation.coerceIn(0L, 100L),
                "gamesWon" to updatedGamesWon,
                "trophiesCount" to mergedTrophies.size.toLong(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    // --- ADVENTURES CATALOGUE ---

    fun observeRemoteAdventures(): Flow<List<Adventure>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("adventures")
                .snapshots()
                .map { it.toObjects(Adventure::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "adventures")
        )
    }

    // --- MULTIPLAYER & EVENT ROOMS ---

    fun observeMyRooms(userId: String): Flow<List<GameRoom>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { it.toObjects(GameRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "rooms")
        )
    }

    fun observeRoom(roomId: String): Flow<GameRoom?> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms").document(roomId)
                .snapshots()
                .map { it.toObject(GameRoom::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.GET, "rooms/$roomId")
        )
    }

    fun observeRoomPlayers(roomId: String): Flow<List<RoomPlayer>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms").document(roomId).collection("players")
                .snapshots()
                .map { it.toObjects(RoomPlayer::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "rooms/$roomId/players")
        )
    }

    fun observeMySecret(roomId: String, userId: String): Flow<RoomSecret?> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms").document(roomId).collection("secrets").document(userId)
                .snapshots()
                .map { it.toObject(RoomSecret::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.GET, "rooms/$roomId/secrets/$userId")
        )
    }

    fun observeRoomMessages(roomId: String, userId: String): Flow<List<RoomMessage>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms").document(roomId).collection("messages")
                .whereArrayContains("visibleToUids", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(RoomMessage::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedBy { it.createdAt?.seconds ?: Long.MAX_VALUE }
                }
                .guardFirestoreErrors(uid, OperationType.LIST, "rooms/$roomId/messages")
        )
    }

    fun observeRoomVotes(roomId: String, userId: String): Flow<List<RoomVote>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("rooms").document(roomId).collection("votes")
                .whereArrayContains("memberUids", userId)
                .snapshots()
                .map { it.toObjects(RoomVote::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "rooms/$roomId/votes")
        )
    }

    suspend fun createRoom(
        hostName: String,
        adventureId: String,
        adventureTitle: String,
        mode: String,
        maxPlayers: Int,
        eventOrgName: String?
    ): Result<String> {
        val roomId = "room_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val path = "rooms/$roomId"
        return try {
            val uid = requireUserId()
            val code = "HER" + (100..999).random()
            val cleanHost = hostName.trim().ifBlank { "Hôte" }.take(50)
            val payload = mapOf(
                "roomCode" to code,
                "hostUid" to uid,
                "hostName" to cleanHost,
                "adventureId" to adventureId.take(64),
                "adventureTitle" to adventureTitle.take(100),
                "mode" to mode,
                "status" to "LOBBY",
                "currentChapter" to 1L,
                "maxPlayers" to maxPlayers.coerceIn(4, 20).toLong(),
                "memberUids" to listOf(uid),
                "eventOrgName" to eventOrgName?.trim()?.takeIf { it.isNotBlank() }?.take(80),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("rooms").document(roomId).set(payload).await()

            val firstChar = AdventureCatalog.heirs.first()
            registerPlayerSeat(roomId, uid, cleanHost, firstChar.id, firstChar.name, firstChar.titleFr, firstChar.startingWealthM.toLong(), firstChar.secretObjectiveFr, firstChar.secretClueFr)
            Result.success(roomId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun joinRoomByCode(code: String, playerName: String): Result<String> {
        val cleanCode = code.trim().uppercase()
        return try {
            val uid = requireUserId()
            val snap = db.collection("rooms")
                .whereEqualTo("status", "LOBBY")
                .whereEqualTo("roomCode", cleanCode)
                .limit(1)
                .get()
                .await()
            val doc = snap.documents.firstOrNull()
                ?: return Result.failure(IllegalArgumentException("Salon introuvable ou déjà démarré ($cleanCode)."))
            val roomId = doc.id
            val members = (doc.get("memberUids") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
            val maxPlayers = (doc.getLong("maxPlayers") ?: 10L).toInt()
            if (!members.contains(uid)) {
                if (members.size >= maxPlayers) {
                    return Result.failure(IllegalStateException("Ce salon est complet ($maxPlayers/$maxPlayers)."))
                }
                db.collection("rooms").document(roomId).update(
                    mapOf(
                        "memberUids" to members + uid,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            val assigned = AdventureCatalog.heirs[members.size % AdventureCatalog.heirs.size]
            registerPlayerSeat(
                roomId = roomId,
                uid = uid,
                displayName = playerName.trim().ifBlank { "Héritier" }.take(50),
                characterId = assigned.id,
                characterName = assigned.name,
                roleTitle = assigned.titleFr,
                wealthM = assigned.startingWealthM.toLong(),
                secretObjective = assigned.secretObjectiveFr,
                secretClue = assigned.secretClueFr
            )
            Result.success(roomId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "rooms")
            Result.failure(e)
        }
    }

    private suspend fun registerPlayerSeat(
        roomId: String,
        uid: String,
        displayName: String,
        characterId: String,
        characterName: String,
        roleTitle: String,
        wealthM: Long,
        secretObjective: String,
        secretClue: String
    ) {
        val playerRef = db.collection("rooms").document(roomId).collection("players").document(uid)
        val snap = playerRef.get().await()
        if (!snap.exists()) {
            playerRef.set(
                mapOf(
                    "uid" to uid,
                    "displayName" to displayName.take(50),
                    "characterId" to characterId,
                    "characterName" to characterName,
                    "roleTitle" to roleTitle,
                    "score" to 0L,
                    "virtualWealthM" to wealthM,
                    "reputation" to 50L,
                    "ready" to false,
                    "connected" to true,
                    "joinedAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            playerRef.update(
                mapOf(
                    "connected" to true,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }

        db.collection("rooms").document(roomId).collection("secrets").document(uid).set(
            mapOf(
                "uid" to uid,
                "secretObjective" to secretObjective.take(400),
                "secretClue" to secretClue.take(400),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
    }

    suspend fun updateMyRoomSeat(
        roomId: String,
        characterId: String? = null,
        characterName: String? = null,
        roleTitle: String? = null,
        ready: Boolean? = null,
        score: Long? = null,
        wealthM: Long? = null,
        reputation: Long? = null
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: "unauthenticated"
        val path = "rooms/$roomId/players/$uid"
        return try {
            val activeUid = requireUserId()
            val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            characterId?.let { updates["characterId"] = it }
            characterName?.let { updates["characterName"] = it }
            roleTitle?.let { updates["roleTitle"] = it }
            ready?.let { updates["ready"] = it }
            score?.let { updates["score"] = it }
            wealthM?.let { updates["virtualWealthM"] = it }
            reputation?.let { updates["reputation"] = it }
            db.collection("rooms").document(roomId).collection("players").document(activeUid)
                .update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun hostUpdateRoomProgress(
        roomId: String,
        status: String? = null,
        chapter: Long? = null,
        votePrompt: String? = null
    ): Result<Unit> {
        return try {
            requireUserId()
            val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            status?.let { updates["status"] = it }
            chapter?.let { updates["currentChapter"] = it.coerceIn(1L, 10L) }
            votePrompt?.let { updates["activeVotePrompt"] = it.take(200) }
            db.collection("rooms").document(roomId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "rooms/$roomId")
            Result.failure(e)
        }
    }

    suspend fun hostAssignRolesRandomly(roomId: String, players: List<RoomPlayer>): Result<Unit> {
        return try {
            requireUserId()
            val shuffled = AdventureCatalog.heirs.shuffled()
            val batch = db.batch()
            players.forEachIndexed { idx, player ->
                val archetype = shuffled[idx % shuffled.size]
                val ref = db.collection("rooms").document(roomId).collection("players").document(player.uid)
                batch.update(
                    ref,
                    mapOf(
                        "characterId" to archetype.id,
                        "characterName" to archetype.name,
                        "roleTitle" to archetype.titleFr,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "rooms/$roomId/players")
            Result.failure(e)
        }
    }

    suspend fun sendRoomMessage(
        roomId: String,
        senderName: String,
        body: String,
        recipientUid: String?,
        allMemberUids: List<String>
    ): Result<Unit> {
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val path = "rooms/$roomId/messages/$msgId"
        return try {
            val uid = requireUserId()
            val cleanBody = body.trim().take(500)
            require(cleanBody.isNotBlank()) { "Message cannot be empty" }
            val visibleTo = if (recipientUid.isNullOrBlank()) {
                (allMemberUids + uid).distinct().take(21)
            } else {
                listOf(uid, recipientUid).distinct()
            }
            val payload = mapOf(
                "senderUid" to uid,
                "senderName" to senderName.take(50),
                "recipientUid" to recipientUid,
                "body" to cleanBody,
                "visibleToUids" to visibleTo,
                "createdAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("rooms").document(roomId).collection("messages").document(msgId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun castRoomVote(
        roomId: String,
        chapter: Int,
        targetId: String,
        targetName: String,
        memberUids: List<String>
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: "unauthenticated"
        val voteId = "vote_c${chapter}_${uid.take(24)}"
        val path = "rooms/$roomId/votes/$voteId"
        return try {
            val activeUid = requireUserId()
            val payload = mapOf(
                "voterUid" to activeUid,
                "chapter" to chapter.toLong(),
                "targetId" to targetId,
                "targetName" to targetName.take(60),
                "memberUids" to (memberUids + activeUid).distinct().take(20),
                "createdAt" to FieldValue.serverTimestamp()
            )
            db.collection("rooms").document(roomId).collection("votes").document(voteId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    // --- MONETIZATION, PROMO CODES & SUPPORT ---

    suspend fun validatePromoCode(rawCode: String): Result<PromoCode> {
        val code = rawCode.trim().uppercase()
        return try {
            requireUserId()
            require(code.length in 3..24) { "Code promo invalide." }
            val snap = db.collection("promo_codes").document(code).get().await()
            val promo = snap.toObject(PromoCode::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?: return Result.failure(IllegalArgumentException("Code introuvable : $code"))
            if (!promo.active || promo.usageCount >= promo.maxUses) {
                return Result.failure(IllegalStateException("Ce code promotionnel a expiré."))
            }
            Result.success(promo)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "promo_codes/$code")
            Result.failure(e)
        }
    }

    suspend fun submitPurchaseOrder(
        offerId: String,
        title: String,
        amountUsd: Double,
        paymentMethod: String,
        promoCode: String?,
        referenceNote: String?
    ): Result<Unit> {
        val orderId = "ord_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "userId" to uid,
                "offerId" to offerId,
                "title" to title.take(100),
                "amountUsd" to amountUsd.coerceAtLeast(0.0),
                "paymentMethod" to paymentMethod.take(60),
                "promoCode" to promoCode?.trim()?.takeIf { it.isNotBlank() }?.take(24),
                "referenceNote" to referenceNote?.trim()?.takeIf { it.isNotBlank() }?.take(200),
                "status" to "PENDING_VERIFICATION",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("purchases").document(orderId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "purchases/$orderId")
            Result.failure(e)
        }
    }

    fun observeMyPurchases(userId: String): Flow<List<PurchaseOrder>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("purchases")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(PurchaseOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .guardFirestoreErrors(uid, OperationType.LIST, "purchases")
        )
    }

    suspend fun submitSupportReport(
        userEmail: String?,
        category: String,
        subject: String,
        message: String
    ): Result<Unit> {
        val reportId = "rep_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        return try {
            val uid = requireUserId()
            require(subject.trim().length >= 3) { "Sujet trop court." }
            require(message.trim().length >= 5) { "Message trop court." }
            val payload = mapOf(
                "userId" to uid,
                "userEmail" to userEmail?.take(120),
                "category" to category.take(40),
                "subject" to subject.trim().take(120),
                "message" to message.trim().take(1500),
                "status" to "OPEN",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }
            db.collection("support_reports").document(reportId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "support_reports/$reportId")
            Result.failure(e)
        }
    }

    fun observeMySupportReports(userId: String): Flow<List<SupportReport>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("support_reports")
                .whereEqualTo("userId", userId)
                .snapshots()
                .map { snap ->
                    snap.toObjects(SupportReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .guardFirestoreErrors(uid, OperationType.LIST, "support_reports")
        )
    }

    // --- ADMIN OPERATIONS (Enforced server-side by firestore.rules isAdmin()) ---

    fun adminObserveAllPurchases(): Flow<List<PurchaseOrder>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("purchases")
                .snapshots()
                .map { snap ->
                    snap.toObjects(PurchaseOrder::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .guardFirestoreErrors(uid, OperationType.LIST, "purchases")
        )
    }

    fun adminObserveAllReports(): Flow<List<SupportReport>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("support_reports")
                .snapshots()
                .map { snap ->
                    snap.toObjects(SupportReport::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        .sortedByDescending { it.createdAt?.seconds ?: 0L }
                }
                .guardFirestoreErrors(uid, OperationType.LIST, "support_reports")
        )
    }

    fun adminObserveAllUsers(): Flow<List<UserProfile>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users")
                .snapshots()
                .map { it.toObjects(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "users")
        )
    }

    fun adminObservePromoCodes(): Flow<List<PromoCode>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("promo_codes")
                .snapshots()
                .map { it.toObjects(PromoCode::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
                .guardFirestoreErrors(uid, OperationType.LIST, "promo_codes")
        )
    }

    suspend fun adminPublishAdventure(
        title: String,
        subtitle: String,
        synopsis: String,
        tier: String,
        priceUsd: Double,
        chapters: List<String>
    ): Result<Unit> {
        val advId = "adv_${UUID.randomUUID().toString().replace("-", "").take(10)}"
        return try {
            val uid = requireUserId()
            val payload = mapOf(
                "title" to title.trim().take(100),
                "subtitle" to subtitle.trim().take(160),
                "synopsis" to synopsis.trim().take(1500),
                "tier" to tier,
                "priceUsd" to priceUsd.coerceIn(0.0, 1000.0),
                "durationMinutes" to 75L,
                "minPlayers" to 1L,
                "maxPlayers" to 20L,
                "published" to true,
                "playable" to true,
                "chaptersCount" to chapters.size.coerceIn(1, 15).toLong(),
                "coverKey" to "mansion",
                "customChapters" to chapters.take(15),
                "createdByUid" to uid,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            db.collection("adventures").document(advId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "adventures/$advId")
            Result.failure(e)
        }
    }

    suspend fun adminCreatePromoCode(code: String, discountPercent: Int, maxUses: Int): Result<Unit> {
        val cleanCode = code.trim().uppercase().take(24)
        return try {
            requireUserId()
            require(cleanCode.matches(Regex("^[A-Z0-9_\\-]+$")) && cleanCode.length >= 3) {
                "Code invalide (lettres/chiffres uniquement)."
            }
            db.collection("promo_codes").document(cleanCode).set(
                mapOf(
                    "code" to cleanCode,
                    "discountPercent" to discountPercent.coerceIn(1, 90).toLong(),
                    "active" to true,
                    "usageCount" to 0L,
                    "maxUses" to maxUses.coerceIn(1, 10000).toLong(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "promo_codes/$cleanCode")
            Result.failure(e)
        }
    }

    suspend fun adminVerifyPurchaseAndUnlock(purchase: PurchaseOrder, approve: Boolean): Result<Unit> {
        return try {
            requireUserId()
            val newStatus = if (approve) "VERIFIED" else "REJECTED"
            db.collection("purchases").document(purchase.id).update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            if (approve) {
                val planCode = when (purchase.offerId) {
                    "solo_premium" -> "SOLO_PREMIUM"
                    "multi_classic" -> "MULTI_CLASSIC"
                    "multi_premium" -> "MULTI_PREMIUM"
                    "enterprise" -> "ENTERPRISE"
                    "vip_monthly" -> "VIP"
                    else -> "SOLO_PREMIUM"
                }
                db.collection("users").document(purchase.userId).update(
                    mapOf(
                        "activePlan" to planCode,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "purchases/${purchase.id}")
            Result.failure(e)
        }
    }

    suspend fun adminResolveSupportReport(reportId: String, reply: String): Result<Unit> {
        return try {
            requireUserId()
            db.collection("support_reports").document(reportId).update(
                mapOf(
                    "status" to "RESOLVED",
                    "adminReply" to reply.trim().take(1000),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "support_reports/$reportId")
            Result.failure(e)
        }
    }
}
