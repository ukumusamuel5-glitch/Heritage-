package com.example.core

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class SoundEffects(context: Context) {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val toneGenerator: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 65)
    } catch (e: Exception) {
        Log.w("SoundEffects", "ToneGenerator unavailable", e)
        null
    }

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
    }

    fun playRevealCue(enabled: Boolean) {
        if (!enabled) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 180)
        } catch (_: Exception) {}
    }

    fun playVaultUnlockCue(enabled: Boolean) {
        if (!enabled) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 260)
        } catch (_: Exception) {}
    }

    fun playIncomingCallRing(enabled: Boolean) {
        if (!enabled) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 420)
        } catch (_: Exception) {}
    }

    fun speakArchive(text: String, language: AppLanguage, enabled: Boolean) {
        if (!enabled || !ttsReady) return
        val locale = when (language) {
            AppLanguage.FR, AppLanguage.LN -> Locale.FRENCH
            AppLanguage.EN -> Locale.US
            AppLanguage.ES -> Locale.forLanguageTag("es-ES")
            AppLanguage.PT -> Locale.forLanguageTag("pt-PT")
        }
        tts?.language = locale
        tts?.setSpeechRate(0.92f)
        tts?.setPitch(0.86f)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "heritage_archive")
    }

    fun stopSpeech() {
        tts?.stop()
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        toneGenerator?.release()
    }
}
