package com.example.model

import com.example.core.AppLanguage

data class StoryChoice(
    val id: String,
    val labelFr: String,
    val labelEn: String,
    val consequenceFr: String,
    val consequenceEn: String,
    val scoreDelta: Int,
    val wealthDeltaM: Int,
    val reputationDelta: Int,
    val unlockedClueId: String? = null,
    val completedMissionId: String? = null,
    val allyName: String? = null
)

data class VaultPuzzle(
    val id: String,
    val titleFr: String,
    val titleEn: String,
    val hintFr: String,
    val hintEn: String,
    val validCodes: List<String>,
    val rewardClueId: String,
    val wealthBonusM: Int,
    val scoreBonus: Int
)

data class StoryChapter(
    val number: Int,
    val titleFr: String,
    val titleEn: String,
    val artworkKey: String,
    val narrativeFr: String,
    val narrativeEn: String,
    val audioTranscriptFr: String,
    val audioTranscriptEn: String,
    val incomingCallFrom: String? = null,
    val incomingCallMsgFr: String? = null,
    val incomingCallMsgEn: String? = null,
    val countdownSeconds: Int = 180,
    val puzzle: VaultPuzzle? = null,
    val choices: List<StoryChoice>
)

data class ClueDocument(
    val id: String,
    val titleFr: String,
    val titleEn: String,
    val categoryFr: String,
    val categoryEn: String,
    val bodyFr: String,
    val bodyEn: String,
    val artworkKey: String
)

data class SecretMission(
    val id: String,
    val titleFr: String,
    val titleEn: String,
    val points: Int
)

data class StoryEnding(
    val id: String,
    val titleFr: String,
    val titleEn: String,
    val summaryFr: String,
    val summaryEn: String,
    val badgeFr: String,
    val badgeEn: String
)

object StoryEngineData {

    val cluesLibrary: Map<String, ClueDocument> = mapOf(
        "clue_seal" to ClueDocument(
            id = "clue_seal",
            titleFr = "Enveloppe scellée à la cire bordeaux",
            titleEn = "Burgundy Wax-Sealed Envelope",
            categoryFr = "Document confidentiel",
            categoryEn = "Confidential Document",
            bodyFr = "Un sceau officiel daté de 22h40. La cire présente une empreinte de bague chevalière absente du doigt d'Alexandre Vance.",
            bodyEn = "An official seal timestamped 10:40 PM. The wax carries the imprint of a signet ring missing from Alexander Vance's hand.",
            artworkKey = "testament"
        ),
        "clue_ledger" to ClueDocument(
            id = "clue_ledger",
            titleFr = "Extrait du registre offshore #409",
            titleEn = "Offshore Ledger Extract #409",
            categoryFr = "Preuve financière",
            categoryEn = "Financial Evidence",
            bodyFr = "Virement urgent de 12 millions $ vers Zurich initié trois heures avant le dîner familial. Double signature requise.",
            bodyEn = "Urgent $12M wire transfer to Zurich initiated three hours before the family dinner. Dual authorization required.",
            artworkKey = "vault"
        ),
        "clue_cameras" to ClueDocument(
            id = "clue_cameras",
            titleFr = "Journal de coupure vidéo — Aile Est",
            titleEn = "CCTV Blackout Log — East Wing",
            categoryFr = "Archive technique",
            categoryEn = "Technical Archive",
            bodyFr = "Les caméras du bureau blindé ont été désactivées entre 22h10 et 22h28 depuis un badge d'administrateur interne.",
            bodyEn = "Vault study cameras were disabled between 10:10 PM and 10:28 PM using an internal administrator badge.",
            artworkKey = "mansion"
        ),
        "clue_codicil" to ClueDocument(
            id = "clue_codicil",
            titleFr = "Codicille manuscrit d'Alexandre Vance",
            titleEn = "Alexander Vance's Handwritten Codicil",
            categoryFr = "Testament secret",
            categoryEn = "Secret Will",
            bodyFr = "« L'empire ne reviendra pas au plus riche, mais à celui qui saura préserver la vérité sans briser la maison Vance. »",
            bodyEn = "\"The empire shall not belong to the wealthiest, but to the one who preserves the truth without shattering House Vance.\"",
            artworkKey = "testament"
        ),
        "clue_vault_gold" to ClueDocument(
            id = "clue_vault_gold",
            titleFr = "Titres au porteur du Coffre B",
            titleEn = "Vault B Bearer Bonds",
            categoryFr = "Coffre-fort",
            categoryEn = "Private Vault",
            bodyFr = "25 millions $ d'actifs liquides immédiatement mobilisables par le porteur légitime lors du vote final.",
            bodyEn = "$25M in liquid bearer assets immediately actionable by the rightful holder during the final council vote.",
            artworkKey = "vault"
        ),
        "clue_tape" to ClueDocument(
            id = "clue_tape",
            titleFr = "Enregistrement du dernier entretien",
            titleEn = "Final Meeting Voice Recording",
            categoryFr = "Archive audio",
            categoryEn = "Audio Archive",
            bodyFr = "Alexandre y affirme avoir piégé le testament pour observer qui parmi ses héritiers choisirait la trahison.",
            bodyEn = "Alexander states he rigged the will as a live crucible to watch which heir would succumb to betrayal.",
            artworkKey = "boardroom"
        )
    )

    val missionsList: List<SecretMission> = listOf(
        SecretMission("m_seal", "Examiner le sceau du testament avant les rivaux", "Inspect the will's seal before rival heirs", 150),
        SecretMission("m_vault", "Déverrouiller le coffre-fort privé du bureau", "Unlock the study's private steel vault", 250),
        SecretMission("m_alliance", "Sceller une alliance stratégique secrète", "Forge a secret strategic alliance", 200),
        SecretMission("m_enigma", "Résoudre l'énigme de l'horloge du conseil", "Solve the council clock logic puzzle", 250),
        SecretMission("m_verdict", "Survive à la confrontation finale et revendiquer l'empire", "Prevail in the final confrontation and claim the empire", 350)
    )

    fun chaptersFor(adventureId: String, variantSeed: Int = 0): List<StoryChapter> {
        if (adventureId == "discovery_free") return discoveryChapters
        return lastTestamentChapters(variantSeed)
    }

    private val discoveryChapters: List<StoryChapter> = listOf(
        StoryChapter(
            number = 1,
            titleFr = "Chapitre 1 • L'orage sur le Manoir Vance",
            titleEn = "Chapter 1 • Storm Over Vance Manor",
            artworkKey = "mansion",
            narrativeFr = "22h45. Une pluie battante frappe les vitraux du manoir Saint-Valéry. Maître Thorne vous remet une enveloppe scellée à la cire bordeaux : Alexandre Vance vient de disparaître en laissant un empire de 100 millions $.",
            narrativeEn = "10:45 PM. Torrential rain lashes the stained glass of Saint-Valéry Manor. Notary Thorne hands you a burgundy wax-sealed envelope: Alexander Vance has vanished, leaving a $100M empire behind.",
            audioTranscriptFr = "Message du notaire Thorne : Bienvenue au manoir Vance. Vous avez quinze minutes pour prouver que vous méritez d'entrer dans le cercle des héritiers.",
            audioTranscriptEn = "Message from Notary Thorne: Welcome to Vance Manor. You have fifteen minutes to prove you belong in the inner circle of heirs.",
            countdownSeconds = 180,
            choices = listOf(
                StoryChoice(
                    id = "disc_1_a",
                    labelFr = "Inspecter le sceau de cire à la loupe",
                    labelEn = "Inspect the wax seal closely",
                    consequenceFr = "Vous repérez l'empreinte d'une chevalière manquante : premier indice décisif sécurisé.",
                    consequenceEn = "You spot the imprint of a missing signet ring: first decisive clue secured.",
                    scoreDelta = 160,
                    wealthDeltaM = 5,
                    reputationDelta = 8,
                    unlockedClueId = "clue_seal",
                    completedMissionId = "m_seal"
                ),
                StoryChoice(
                    id = "disc_1_b",
                    labelFr = "Interroger immédiatement Victoria dans le salon",
                    labelEn = "Question Victoria immediately in the parlor",
                    consequenceFr = "Victoria esquive vos questions mais laisse échapper une allusion à un coffre au sous-sol.",
                    consequenceEn = "Victoria dodges your questions but slips up about a basement vault.",
                    scoreDelta = 120,
                    wealthDeltaM = 10,
                    reputationDelta = -3,
                    unlockedClueId = "clue_cameras"
                )
            )
        ),
        StoryChapter(
            number = 2,
            titleFr = "Chapitre 2 • Le Coffre de l'Antichambre",
            titleEn = "Chapter 2 • The Antechamber Vault",
            artworkKey = "vault",
            narrativeFr = "Derrière le portrait du fondateur se cache un coffre numérique. Une note manuscrite indique : « Mon année de naissance inversée à deux chiffres suivie de mes deux héritiers directs : 4826. »",
            narrativeEn = "Behind the founder's portrait hides a digital safe. A handwritten note reads: 'The four-digit succession cipher left in the notary's ledger: 4826.'",
            audioTranscriptFr = "Enregistrement d'Alexandre : Seul un esprit méthodique ouvrira mon premier coffre. Ne faites confiance à personne.",
            audioTranscriptEn = "Alexander's recording: Only a methodical mind will crack my first vault. Trust no one.",
            incomingCallFrom = "Numéro masqué • Bureau de Zurich",
            incomingCallMsgFr = "« Ne dévoilez pas le contenu du coffre B au conseil si vous voulez doubler votre part. »",
            incomingCallMsgEn = "\"Do not reveal Vault B's contents to the council if you want to double your share.\"",
            countdownSeconds = 180,
            puzzle = VaultPuzzle(
                id = "vault_disc",
                titleFr = "Coffre de l'Antichambre (4 chiffres)",
                titleEn = "Antechamber Vault (4 digits)",
                hintFr = "Indice : consultez le code de la note manuscrite (4826).",
                hintEn = "Hint: check the cipher in the handwritten note (4826).",
                validCodes = listOf("4826"),
                rewardClueId = "clue_vault_gold",
                wealthBonusM = 20,
                scoreBonus = 250
            ),
            choices = listOf(
                StoryChoice(
                    id = "disc_2_a",
                    labelFr = "Conserver les preuves pour le conseil final",
                    labelEn = "Hold the evidence for the final council",
                    consequenceFr = "Votre discrétion impressionne le notaire et renforce votre crédit stratégique.",
                    consequenceEn = "Your discretion impresses the notary and elevates your strategic standing.",
                    scoreDelta = 180,
                    wealthDeltaM = 10,
                    reputationDelta = 10,
                    unlockedClueId = "clue_codicil"
                ),
                StoryChoice(
                    id = "disc_2_b",
                    labelFr = "Monnayer l'information auprès de Julian",
                    labelEn = "Trade the intel with Julian",
                    consequenceFr = "Julian vous verse 15M$ d'actifs virtuels contre votre silence.",
                    consequenceEn = "Julian transfers $15M in virtual assets for your silence.",
                    scoreDelta = 140,
                    wealthDeltaM = 15,
                    reputationDelta = -5,
                    allyName = "Julian Mercer",
                    completedMissionId = "m_alliance"
                )
            )
        ),
        StoryChapter(
            number = 3,
            titleFr = "Chapitre 3 • Le Verdict de l'Antichambre",
            titleEn = "Chapter 3 • The Antechamber Verdict",
            artworkKey = "boardroom",
            narrativeFr = "Les portes de la grande salle s'ouvrent. Votre nom vient d'être inscrit sur la liste des héritiers qualifiés pour l'épreuve complète de Le dernier testament.",
            narrativeEn = "The grand hall doors swing open. Your name has just been inscribed among the qualified heirs for the full trial of The Last Will.",
            audioTranscriptFr = "Maître Thorne : Félicitations. Le véritable jeu de succession commence maintenant.",
            audioTranscriptEn = "Notary Thorne: Congratulations. The true succession trial begins now.",
            countdownSeconds = 120,
            choices = listOf(
                StoryChoice(
                    id = "disc_3_a",
                    labelFr = "Revendiquer l'ouverture officielle du testament",
                    labelEn = "Claim the official opening of the will",
                    consequenceFr = "Vous terminez l'initiation en tête et débloquez votre blason d'Héritier Qualifié.",
                    consequenceEn = "You finish the trial in the lead and unlock the Qualified Heir crest.",
                    scoreDelta = 300,
                    wealthDeltaM = 25,
                    reputationDelta = 12,
                    completedMissionId = "m_verdict"
                )
            )
        )
    )

    private fun lastTestamentChapters(variantSeed: Int): List<StoryChapter> {
        val vaultCode = if (variantSeed % 2 == 0) "4826" else "2468"
        val logicAnswer = if (variantSeed % 2 == 0) "19" else "22"

        return listOf(
            StoryChapter(
                number = 1,
                titleFr = "1. Introduction cinématographique",
                titleEn = "1. Cinematic Introduction",
                artworkKey = "mansion",
                narrativeFr = "Minuit sonne au Manoir Saint-Valéry. Alexandre Vance, bâtisseur d'un empire de 100 millions $, a laissé une dernière vidéo programmée avant son décès mystérieux. Six héritiers se jaugent sous les lustres d'or.",
                narrativeEn = "Midnight strikes at Saint-Valéry Manor. Alexander Vance, architect of a $100M empire, left one final scheduled broadcast before his mysterious death. Six heirs size each other up beneath golden chandeliers.",
                audioTranscriptFr = "Alexandre Vance : Si vous écoutez ceci, mon empire n'a plus de maître. Tout le monde dans cette pièce cache une faute. Un seul d'entre vous héritera.",
                audioTranscriptEn = "Alexander Vance: If you are hearing this, my empire has no master. Everyone in this room hides a sin. Only one of you will inherit.",
                countdownSeconds = 180,
                choices = listOf(
                    StoryChoice(
                        id = "lt_1_a",
                        labelFr = "Observer en silence les réactions des autres héritiers",
                        labelEn = "Silently observe the rival heirs' reactions",
                        consequenceFr = "Vous notez que Julian regarde nerveusement sa montre et Victoria serre son dossier.",
                        consequenceEn = "You notice Julian nervously checking his watch while Victoria grips her folder.",
                        scoreDelta = 120,
                        wealthDeltaM = 0,
                        reputationDelta = 8
                    ),
                    StoryChoice(
                        id = "lt_1_b",
                        labelFr = "Prendre la parole et réclamer la transparence totale",
                        labelEn = "Speak up and demand full transparency",
                        consequenceFr = "Votre audace rallie Amara, mais vous place dans le viseur de Victoria.",
                        consequenceEn = "Your boldness wins Amara's respect, though Victoria marks you as a threat.",
                        scoreDelta = 130,
                        wealthDeltaM = 5,
                        reputationDelta = 5,
                        allyName = "Amara Diallo"
                    )
                )
            ),
            StoryChapter(
                number = 2,
                titleFr = "2. Présentation des personnages",
                titleEn = "2. Character Introductions",
                artworkKey = "boardroom",
                narrativeFr = "Chacun dévoile sa position officielle autour de la table d'acajou : Victoria (Stratégie), Julian (Finance), Éléna (Médecine), Kévin (Notaire), Amara (Opérations) et Lucas (Cybersécurité).",
                narrativeEn = "Each heir reveals their official standing around the mahogany table: Victoria (Strategy), Julian (Finance), Elena (Medicine), Kevin (Notary), Amara (Operations), and Lucas (Cybersecurity).",
                audioTranscriptFr = "Synthèse du dossier : 100 millions $ répartis en actions majoritaires, liquidités suisses et brevets industriels.",
                audioTranscriptEn = "Dossier brief: $100M split across controlling shares, Swiss liquidity, and industrial patents.",
                countdownSeconds = 180,
                choices = listOf(
                    StoryChoice(
                        id = "lt_2_a",
                        labelFr = "Consulter en priorité les actifs bancaires avec Julian",
                        labelEn = "Review the banking assets with Julian first",
                        consequenceFr = "Julian vous confie l'existence d'un virement suspect #409.",
                        consequenceEn = "Julian tips you off about a suspicious wire #409.",
                        scoreDelta = 140,
                        wealthDeltaM = 8,
                        reputationDelta = 4,
                        unlockedClueId = "clue_ledger"
                    ),
                    StoryChoice(
                        id = "lt_2_b",
                        labelFr = "Vérifier le journal de sécurité avec Lucas",
                        labelEn = "Audit the security logs with Lucas",
                        consequenceFr = "Lucas vous transmet la preuve d'une coupure caméra à 22h10.",
                        consequenceEn = "Lucas shares proof of a CCTV blackout at 10:10 PM.",
                        scoreDelta = 150,
                        wealthDeltaM = 4,
                        reputationDelta = 6,
                        unlockedClueId = "clue_cameras"
                    )
                )
            ),
            StoryChapter(
                number = 3,
                titleFr = "3. Lecture du testament",
                titleEn = "3. Reading of the Will",
                artworkKey = "testament",
                narrativeFr = "Maître Thorne brise le cachet de cire bordeaux. Le testament stipule que la fortune ira à l'héritier cumulant le plus haut score d'intégrité, d'actifs et de preuves à l'issue des dix actes.",
                narrativeEn = "Notary Thorne breaks the burgundy wax seal. The will decrees that the empire goes to the heir holding the highest combined integrity, assets, and verified proof by the final act.",
                audioTranscriptFr = "Lecture officielle : Clause 1 à 4 — Aucune violence, aucune fraude, mais toutes les alliances et négociations sont autorisées.",
                audioTranscriptEn = "Official reading: Clauses 1 to 4 — No force, no forgery, yet all alliances and strategic negotiations are permitted.",
                countdownSeconds = 200,
                choices = listOf(
                    StoryChoice(
                        id = "lt_3_a",
                        labelFr = "Examiner la cire du testament et exiger l'enregistrement horaire",
                        labelEn = "Inspect the will's wax seal and demand the timestamp log",
                        consequenceFr = "L'empreinte de bague révèle que le testament a été scellé après le décès.",
                        consequenceEn = "The ring imprint proves the will was sealed after the time of death.",
                        scoreDelta = 180,
                        wealthDeltaM = 5,
                        reputationDelta = 10,
                        unlockedClueId = "clue_seal",
                        completedMissionId = "m_seal"
                    ),
                    StoryChoice(
                        id = "lt_3_b",
                        labelFr = "Sécuriser immédiatement une option sur les parts majoritaires",
                        labelEn = "Secure an immediate call option on the controlling shares",
                        consequenceFr = "Vous augmentez votre capital virtuel de 12M$, au prix d'une certaine méfiance.",
                        consequenceEn = "You boost your virtual capital by $12M, though rivals grow wary.",
                        scoreDelta = 150,
                        wealthDeltaM = 12,
                        reputationDelta = -4
                    )
                )
            ),
            StoryChapter(
                number = 4,
                titleFr = "4. Premières missions secrètes",
                titleEn = "4. First Secret Missions",
                artworkKey = "vault",
                narrativeFr = "Votre téléphone sécurisé vibre : chaque héritier reçoit une directive confidentielle personnelle. Un appel chiffré vous propose un marché risqué.",
                narrativeEn = "Your encrypted phone vibrates: each heir receives a confidential personal directive. An encrypted call offers you a dangerous bargain.",
                audioTranscriptFr = "Directive secrète : Protégez vos objectifs confidentiels. Utilisez l'onglet Messagerie pour négocier en privé avec les autres héritiers.",
                audioTranscriptEn = "Secret directive: Guard your confidential objectives. Use the Comms tab to negotiate privately with rival heirs.",
                incomingCallFrom = "Correspondant Anonyme • Zurich",
                incomingCallMsgFr = "« J'ai la clé du serveur fantôme. Donnez-moi le nom de votre principal suspect et je vous cède 10M$. »",
                incomingCallMsgEn = "\"I hold the ghost server key. Name your prime suspect and I will wire you $10M.\"",
                countdownSeconds = 200,
                choices = listOf(
                    StoryChoice(
                        id = "lt_4_a",
                        labelFr = "Refuser le chantage et préserver votre indépendance",
                        labelEn = "Refuse the blackmail and preserve your independence",
                        consequenceFr = "Votre intégrité grimpe en flèche et Dr. Éléna commence à vous faire confiance.",
                        consequenceEn = "Your integrity climbs sharply and Dr. Elena begins to trust you.",
                        scoreDelta = 170,
                        wealthDeltaM = 0,
                        reputationDelta = 12,
                        allyName = "Dr. Éléna Rostova"
                    ),
                    StoryChoice(
                        id = "lt_4_b",
                        labelFr = "Accepter l'échange tactique pour financer vos enquêtes",
                        labelEn = "Accept the tactical trade to fund your investigation",
                        consequenceFr = "Vous encaissez 10M$ virtuels, mais quelqu'un a intercepté un fragment de l'appel.",
                        consequenceEn = "You pocket $10M in virtual funds, though someone intercepted part of the call.",
                        scoreDelta = 150,
                        wealthDeltaM = 10,
                        reputationDelta = -6
                    )
                )
            ),
            StoryChapter(
                number = 5,
                titleFr = "5. Recherche d'indices",
                titleEn = "5. Search for Clues",
                artworkKey = "vault",
                narrativeFr = "Le bureau privé d'Alexandre est enfin ouvert aux enquêteurs. Un coffre-fort blindé trône derrière la bibliothèque. Indice gravé sur le laiton : « $vaultCode ».",
                narrativeEn = "Alexander's private study is finally open to investigators. An armored safe sits behind the bookcase. Brass engraving hint: '$vaultCode'.",
                audioTranscriptFr = "Indice sonore : Les engrenages du coffre attendent votre combinaison à quatre chiffres.",
                audioTranscriptEn = "Audio cue: The vault tumblers await your four-digit combination.",
                countdownSeconds = 240,
                puzzle = VaultPuzzle(
                    id = "vault_main",
                    titleFr = "Coffre-Fort Principal Vance",
                    titleEn = "Vance Main Armored Vault",
                    hintFr = "Le code est gravé dans les archives du chapitre : $vaultCode.",
                    hintEn = "The code is engraved in the chapter dossier: $vaultCode.",
                    validCodes = listOf(vaultCode),
                    rewardClueId = "clue_vault_gold",
                    wealthBonusM = 25,
                    scoreBonus = 280
                ),
                choices = listOf(
                    StoryChoice(
                        id = "lt_5_a",
                        labelFr = "Relever les empreintes sur le bureau d'acajou",
                        labelEn = "Dust the mahogany desk for prints",
                        consequenceFr = "Vous découvrez le codicille manuscrit dissimulé sous le sous-main.",
                        consequenceEn = "You uncover the handwritten codicil hidden beneath the blotter.",
                        scoreDelta = 190,
                        wealthDeltaM = 5,
                        reputationDelta = 8,
                        unlockedClueId = "clue_codicil",
                        completedMissionId = "m_vault"
                    ),
                    StoryChoice(
                        id = "lt_5_b",
                        labelFr = "Saisir les titres au porteur avant l'inventaire",
                        labelEn = "Claim the bearer bonds before inventory",
                        consequenceFr = "Votre fortune grimpe de 18M$, mais Maître Thorne note votre précipitation.",
                        consequenceEn = "Your wealth jumps by $18M, though Notary Thorne notes your haste.",
                        scoreDelta = 160,
                        wealthDeltaM = 18,
                        reputationDelta = -7
                    )
                )
            ),
            StoryChapter(
                number = 6,
                titleFr = "6. Négociations et alliances",
                titleEn = "6. Negotiations & Alliances",
                artworkKey = "boardroom",
                narrativeFr = "Les camps se forment dans les couloirs feutrés du manoir. Utilisez l'intelligence artificielle en Solo ou la messagerie privée en Multijoueur pour sceller une alliance décisive.",
                narrativeEn = "Factions form along the manor's velvet corridors. Use live AI negotiations in Solo or private whispers in Multiplayer to forge a decisive alliance.",
                audioTranscriptFr = "Note stratégique : Un héritier isolé survit rarement au vote du chapitre 9.",
                audioTranscriptEn = "Strategic note: An isolated heir rarely survives Chapter 9's council vote.",
                countdownSeconds = 240,
                choices = listOf(
                    StoryChoice(
                        id = "lt_6_a",
                        labelFr = "Former un pacte de transparence avec Éléna & Amara",
                        labelEn = "Form a transparency pact with Elena & Amara",
                        consequenceFr = "Votre coalition gagne en crédibilité et débloque une nouvelle piste audio.",
                        consequenceEn = "Your coalition gains credibility and unlocks a hidden voice archive.",
                        scoreDelta = 210,
                        wealthDeltaM = 6,
                        reputationDelta = 12,
                        unlockedClueId = "clue_tape",
                        completedMissionId = "m_alliance",
                        allyName = "Dr. Éléna Rostova"
                    ),
                    StoryChoice(
                        id = "lt_6_b",
                        labelFr = "Négocier un partage secret de l'empire avec Victoria",
                        labelEn = "Negotiate a secret empire split with Victoria",
                        consequenceFr = "Victoria vous promet ses voix au conseil contre 15% de vos futurs actifs.",
                        consequenceEn = "Victoria pledges her council votes in exchange for 15% of future assets.",
                        scoreDelta = 190,
                        wealthDeltaM = 15,
                        reputationDelta = -5,
                        completedMissionId = "m_alliance",
                        allyName = "Victoria Vance"
                    )
                )
            ),
            StoryChapter(
                number = 7,
                titleFr = "7. Épreuves de logique et d'intelligence",
                titleEn = "7. Trials of Logic & Intellect",
                artworkKey = "testament",
                narrativeFr = "L'horloge du grand salon bloque la dernière clause du testament. Énigme du fondateur : « Additionnez l'heure de la coupure caméra (${logicAnswer}h? Non : si 22h10 - 3h = 19h, quel est le nombre clé : $logicAnswer ?) » Saisissez $logicAnswer.",
                narrativeEn = "The grand parlor clock locks the will's final clause. Founder's riddle: 'Enter the verified security cipher index ($logicAnswer) to release the dossier.'",
                audioTranscriptFr = "Épreuve d'intelligence : Démontrez votre maîtrise logique devant le conseil.",
                audioTranscriptEn = "Intellect trial: Prove your logical mastery before the council.",
                countdownSeconds = 220,
                puzzle = VaultPuzzle(
                    id = "clock_enigma",
                    titleFr = "Mécanisme de l'Horloge Logique",
                    titleEn = "Logic Clock Mechanism",
                    hintFr = "Indice : entrez le nombre clé $logicAnswer.",
                    hintEn = "Hint: enter the key index $logicAnswer.",
                    validCodes = listOf(logicAnswer),
                    rewardClueId = "clue_tape",
                    wealthBonusM = 15,
                    scoreBonus = 260
                ),
                choices = listOf(
                    StoryChoice(
                        id = "lt_7_a",
                        labelFr = "Publier la chronologie reconstituée devant tous",
                        labelEn = "Publish the reconstructed timeline to all heirs",
                        consequenceFr = "Vous prouvez la manipulation horaire et gagnez 240 points d'enquête.",
                        consequenceEn = "You prove the timeline tampering and earn 240 investigation points.",
                        scoreDelta = 240,
                        wealthDeltaM = 5,
                        reputationDelta = 10,
                        completedMissionId = "m_enigma"
                    ),
                    StoryChoice(
                        id = "lt_7_b",
                        labelFr = "Garder l'arme logique pour faire chanter le coupable",
                        labelEn = "Hold the logical proof as leverage over the culprit",
                        consequenceFr = "Vous extorquez 20M$ en promesses de parts, mais votre réputation vacille.",
                        consequenceEn = "You extract $20M in share pledges, though your reputation dips.",
                        scoreDelta = 200,
                        wealthDeltaM = 20,
                        reputationDelta = -9,
                        completedMissionId = "m_enigma"
                    )
                )
            ),
            StoryChapter(
                number = 8,
                titleFr = "8. Révélations inattendues",
                titleEn = "8. Unexpected Revelations",
                artworkKey = "mansion",
                narrativeFr = "Coup de théâtre : les lumières s'éteignent trois secondes. Un message audio posthume d'Alexandre révèle qu'un héritier a tenté de falsifier le registre offshore !",
                narrativeEn = "Plot twist: the chandelier lights flicker out for three seconds. A posthumous recording from Alexander reveals an heir attempted to forge the offshore ledger!",
                audioTranscriptFr = "Alexandre Vance : Je savais que l'un de vous tricherait avant l'aube. Regardez les preuves du registre 409.",
                audioTranscriptEn = "Alexander Vance: I knew one of you would cheat before dawn. Look closely at Ledger 409.",
                incomingCallFrom = "Système Central • Coffre C",
                incomingCallMsgFr = "« Alerte de sécurité : une tentative d'accès non autorisée vient d'être détectée sur le serveur principal. »",
                incomingCallMsgEn = "\"Security alert: an unauthorized access attempt was just logged on the main server.\"",
                countdownSeconds = 180,
                choices = listOf(
                    StoryChoice(
                        id = "lt_8_a",
                        labelFr = "Soutenir publiquement le camp des preuves vérifiées",
                        labelEn = "Publicly back the verified evidence coalition",
                        consequenceFr = "Votre position morale devient inattaquable à l'approche du vote.",
                        consequenceEn = "Your moral standing becomes unassailable ahead of the vote.",
                        scoreDelta = 220,
                        wealthDeltaM = 8,
                        reputationDelta = 14
                    ),
                    StoryChoice(
                        id = "lt_8_b",
                        labelFr = "Racheter à bas prix les parts d'un rival paniqué",
                        labelEn = "Buy out a panicked rival's shares at a discount",
                        consequenceFr = "Coup financier magistral : +22M$ d'actifs nets.",
                        consequenceEn = "Masterstroke acquisition: +$22M in net assets.",
                        scoreDelta = 210,
                        wealthDeltaM = 22,
                        reputationDelta = -6
                    )
                )
            ),
            StoryChapter(
                number = 9,
                titleFr = "9. Dernière confrontation stratégique",
                titleEn = "9. Final Strategic Confrontation",
                artworkKey = "boardroom",
                narrativeFr = "Le Conseil Suprême se réunit. Les portes sont verrouillées. Chaque joueur ou IA rivale vote dans l'onglet Votes pour désigner l'héritier ou accuser le manipulateur.",
                narrativeEn = "The Supreme Council convenes. The doors lock shut. Each player or AI rival casts their decisive vote in the Votes tab to crown the heir or expose the saboteur.",
                audioTranscriptFr = "Maître Thorne : Le moment est venu de voter. Vos alliances tiendront-elles sous la pression ?",
                audioTranscriptEn = "Notary Thorne: The hour of the vote has arrived. Will your alliances hold under pressure?",
                countdownSeconds = 200,
                choices = listOf(
                    StoryChoice(
                        id = "lt_9_a",
                        labelFr = "Présenter votre synthèse complète de preuves et réclamer le trône",
                        labelEn = "Present your full evidence synthesis and claim the throne",
                        consequenceFr = "Le conseil s'incline devant la précision de votre démonstration.",
                        consequenceEn = "The council bows before the precision of your closing argument.",
                        scoreDelta = 280,
                        wealthDeltaM = 15,
                        reputationDelta = 10
                    ),
                    StoryChoice(
                        id = "lt_9_b",
                        labelFr = "Déclencher la clause secrète d'absorption majoritaire",
                        labelEn = "Trigger the secret majority buyout clause",
                        consequenceFr = "Vous forcez la majorité financière et bouleversez l'issue du conseil.",
                        consequenceEn = "You force a financial majority and upend the council outcome.",
                        scoreDelta = 260,
                        wealthDeltaM = 28,
                        reputationDelta = -8
                    )
                )
            ),
            StoryChapter(
                number = 10,
                titleFr = "10. Désignation de l'héritier",
                titleEn = "10. Designation of the Heir",
                artworkKey = "testament",
                narrativeFr = "L'aube perce les rideaux de velours bordeaux. Tous les secrets tombent. Le notaire scelle le verdict définitif de l'empire Vance.",
                narrativeEn = "Dawn breaks through the burgundy velvet drapes. Every secret is laid bare. The notary seals the final verdict of the Vance Empire.",
                audioTranscriptFr = "Verdict final : L'histoire retiendra votre stratégie. Découvrez votre fin et votre carte de victoire.",
                audioTranscriptEn = "Final verdict: History will remember your strategy. Claim your ending and victory card.",
                countdownSeconds = 120,
                choices = listOf(
                    StoryChoice(
                        id = "lt_10_a",
                        labelFr = "Signer l'acte final de succession",
                        labelEn = "Sign the final deed of succession",
                        consequenceFr = "L'empire de 100 millions $ bascule vers son nouveau souverain.",
                        consequenceEn = "The $100M empire passes to its new sovereign.",
                        scoreDelta = 350,
                        wealthDeltaM = 30,
                        reputationDelta = 10,
                        completedMissionId = "m_verdict"
                    )
                )
            )
        )
    }

    fun resolveEnding(
        score: Int,
        wealthM: Int,
        reputation: Int,
        cluesCount: Int
    ): StoryEnding {
        return when {
            score >= 1800 && reputation >= 65 && cluesCount >= 3 -> StoryEnding(
                id = "sole_heir",
                titleFr = "L'Unique Héritier Légitime",
                titleEn = "The Sole Legitimate Heir",
                summaryFr = "Par votre intelligence, vos preuves irréfutables et votre maîtrise politique, le conseil vous remet les clés intégrales de l'empire de 100 millions $.",
                summaryEn = "Through razor-sharp intellect, irrefutable proof, and diplomatic mastery, the council awards you complete command of the $100M empire.",
                badgeFr = "Couronne d'Or Vance",
                badgeEn = "Vance Golden Crown"
            )
            wealthM >= 95 -> StoryEnding(
                id = "iron_mogul",
                titleFr = "Le Magnat de l'Ombre",
                titleEn = "The Shadow Mogul",
                summaryFr = "Vous avez racheté l'empire par la force financière pure. Certains murmurent encore vos secrets, mais personne n'ose s'opposer à votre majorité.",
                summaryEn = "You seized the empire through pure financial dominance. Whispers remain, yet none dare challenge your controlling stake.",
                badgeFr = "Souverain des Coffres",
                badgeEn = "Vault Sovereign"
            )
            reputation >= 60 -> StoryEnding(
                id = "truth_guardian",
                titleFr = "Le Gardien de la Vérité",
                titleEn = "Guardian of the Truth",
                summaryFr = "Vous avez préservé l'honneur de la maison Vance et négocié une co-direction respectée de l'empire.",
                summaryEn = "You preserved the honor of House Vance and secured a respected co-chairmanship of the empire.",
                badgeFr = "Sceau d'Intégrité",
                badgeEn = "Seal of Integrity"
            )
            else -> StoryEnding(
                id = "survivor_heir",
                titleFr = "L'Héritier Survivant",
                titleEn = "The Surviving Heir",
                summaryFr = "Au terme d'une nuit de trahisons, vous conservez votre siège et une part précieuse du patrimoine, prêt pour la prochaine bataille.",
                summaryEn = "After a night of betrayals, you retain your seat and a vital share of the estate, poised for the next battle.",
                badgeFr = "Stratège Résilient",
                badgeEn = "Resilient Strategist"
            )
        }
    }

    fun localizedTitle(chapter: StoryChapter, lang: AppLanguage): String =
        if (lang == AppLanguage.EN) chapter.titleEn else chapter.titleFr

    fun localizedNarrative(chapter: StoryChapter, lang: AppLanguage): String =
        if (lang == AppLanguage.EN) chapter.narrativeEn else chapter.narrativeFr
}
