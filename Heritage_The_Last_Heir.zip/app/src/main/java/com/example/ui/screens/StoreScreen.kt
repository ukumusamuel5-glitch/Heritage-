package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.AdventureCatalog
import com.example.model.PromoCode
import com.example.model.PurchaseOrder
import com.example.model.UserProfile
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.UiState
import kotlin.math.roundToInt

@Composable
fun StoreScreen(
    language: AppLanguage,
    profileState: UiState<UserProfile?>,
    purchasesState: UiState<List<PurchaseOrder>>,
    validatedPromo: PromoCode?,
    onValidatePromo: (String) -> Unit,
    onSubmitOrder: (offerId: String, title: String, finalUsd: Double, paymentMethod: String, referenceNote: String?) -> Unit
) {
    val context = LocalContext.current
    val strings = AppStrings.get(language)
    val profile = (profileState as? UiState.Success)?.data
    val purchases = (purchasesState as? UiState.Success)?.data.orEmpty()

    var promoInput by remember { mutableStateOf("") }
    var selectedMethod by remember { mutableStateOf("Google Play Billing") }
    var referenceNote by remember { mutableStateOf("") }

    val paymentMethods = listOf(
        "Google Play Billing",
        "Carte Bancaire (Stripe)",
        "M-Pesa",
        "Airtel Money",
        "Orange Money"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(strings.storeTitle, style = MaterialTheme.typography.headlineLarge, color = ChampagneGold)

            // Server-Verification Transparency Notice
            GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.6f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = ChampagneGold)
                    Spacer(Modifier.width(8.dp))
                    Text("Paiements sécurisés & vérification serveur", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = if (language == AppLanguage.EN) {
                        "Orders are logged as PENDING_VERIFICATION and require server-side confirmation (Google Play Billing / Stripe / Mobile Money webhook or Admin verification) before unlocking. No fake transactions are simulated."
                    } else {
                        "Chaque commande est enregistrée avec le statut PENDING_VERIFICATION et nécessite une validation côté serveur (Google Play Billing, Stripe, M-Pesa/Airtel/Orange Money ou vérification Admin) avant déblocage."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = IvoryWhite
                )
            }

            // Promo Code & Referral
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalOffer, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.promoHint, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                }
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = promoInput,
                        onValueChange = { promoInput = it.uppercase() },
                        label = { Text("Code (ex: HERITAGE20)") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MetallicGold,
                            unfocusedBorderColor = HairlineGold,
                            focusedTextColor = IvoryWhite,
                            unfocusedTextColor = IvoryWhite
                        )
                    )
                    LuxuryOutlineButton(
                        text = strings.applyPromo,
                        enabled = promoInput.trim().length >= 3,
                        onClick = { onValidatePromo(promoInput) }
                    )
                }
                if (validatedPromo != null) {
                    Spacer(Modifier.height(6.dp))
                    LuxuryPillTag(text = "Actif : ${validatedPromo.code} (-${validatedPromo.discountPercent}%)", containerColor = EmeraldTrust.copy(alpha = 0.4f))
                }

                HorizontalDivider(color = HairlineGold, modifier = Modifier.padding(vertical = 12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("${strings.referralTitle} : ${profile?.referralCode ?: "HER..."}", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                        Text("Invitez vos proches et gagnez des avantages VIP.", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                    }
                    LuxuryOutlineButton(
                        text = "Inviter",
                        icon = Icons.Default.Share,
                        onClick = {
                            val code = profile?.referralCode ?: "HERITAGE"
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, "Rejoins HÉRITAGE — THE LAST HEIR avec mon code de parrainage $code !")
                            }
                            context.startActivity(Intent.createChooser(intent, strings.referralTitle))
                        }
                    )
                }
            }

            // Payment Provider Selector
            GoldSurfaceCard {
                Text(strings.paymentMethodLabel, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    paymentMethods.forEach { method ->
                        val selected = selectedMethod == method
                        Surface(
                            shape = CircleShape,
                            color = if (selected) MetallicGold else MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier.clickable { selectedMethod = method }
                        ) {
                            Text(
                                text = method,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selected) ObsidianBlack else IvoryWhite,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = referenceNote,
                    onValueChange = { referenceNote = it },
                    label = { Text("Référence Mobile Money / Note (optionnel)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite
                    )
                )
            }

            // Offers List
            AdventureCatalog.commercialOffers.forEach { offer ->
                val title = if (language == AppLanguage.EN) offer.titleEn else offer.titleFr
                val discountFactor = 1.0 - ((validatedPromo?.discountPercent ?: 0L).toDouble() / 100.0)
                val finalPrice = ((offer.priceUsd * discountFactor) * 100.0).roundToInt() / 100.0

                GoldSurfaceCard(
                    containerColor = if (offer.highlight) DeepBurgundy.copy(alpha = 0.55f) else VelvetSurface
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            Text(
                                if (language == AppLanguage.EN) offer.periodLabelEn else offer.periodLabelFr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MetallicGold
                            )
                        }
                        if (offer.highlight) {
                            LuxuryPillTag(text = "RECOMMANDÉ")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    (if (language == AppLanguage.EN) offer.featuresEn else offer.featuresFr).forEach { feat ->
                        Text("• $feat", style = MaterialTheme.typography.bodyMedium, color = IvoryWhite)
                    }
                    if (offer.priceUsd > 0.0) {
                        Spacer(Modifier.height(12.dp))
                        GoldPrimaryButton(
                            text = "${strings.submitOrder} ($finalPrice $)",
                            icon = Icons.Default.CardGiftcard,
                            testTag = "order_${offer.id}",
                            onClick = {
                                onSubmitOrder(
                                    offer.id,
                                    title,
                                    finalPrice,
                                    selectedMethod,
                                    referenceNote.takeIf { it.isNotBlank() }
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Purchase History
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.AutoMirrored.Filled.ReceiptLong, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.purchaseHistory, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Spacer(Modifier.height(10.dp))
                if (purchases.isEmpty()) {
                    Text("Aucune commande enregistrée.", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                } else {
                    purchases.forEach { order ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${order.title} (${order.amountUsd} $)", style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                    Text(order.paymentMethod, style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                }
                                LuxuryPillTag(
                                    text = order.status,
                                    containerColor = if (order.status == "VERIFIED") EmeraldTrust.copy(alpha = 0.35f) else DeepBurgundy
                                )
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
