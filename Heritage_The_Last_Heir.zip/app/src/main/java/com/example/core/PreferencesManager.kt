package com.example.core

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "heritage_prefs")

class PreferencesManager(private val context: Context) {
    private val keyLanguage = stringPreferencesKey("language")
    private val keyAudioEnabled = booleanPreferencesKey("audio_enabled")
    private val keyVoiceEnabled = booleanPreferencesKey("voice_enabled")

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { prefs ->
        AppLanguage.fromCode(prefs[keyLanguage] ?: "FR")
    }

    val audioEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[keyAudioEnabled] ?: true
    }

    val voiceEnabledFlow: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[keyVoiceEnabled] ?: true
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[keyLanguage] = language.code }
    }

    suspend fun setAudioEnabled(enabled: Boolean) {
        context.dataStore.edit { it[keyAudioEnabled] = enabled }
    }

    suspend fun setVoiceEnabled(enabled: Boolean) {
        context.dataStore.edit { it[keyVoiceEnabled] = enabled }
    }
}
