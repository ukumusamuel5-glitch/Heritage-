package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.core.RoomInviteMatrix
import com.example.model.AdventureCatalog
import com.example.model.GameRoom
import com.example.model.RoomPlayer
import com.example.model.RoomSecret
import com.example.ui.components.BurgundyAccentButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.WarmParchment

@Composable
fun MultiplayerRoomScreen(
    language: AppLanguage,
    currentUserId: String,
    room: GameRoom?,
    players: List<RoomPlayer>,
    mySecret: RoomSecret?,
    onBack: () -> Unit,
    onSelectCharacter: (characterId: String, characterName: String, roleTitle: String) -> Unit,
    onToggleReady: (Boolean) -> Unit,
    onAssignRandomRoles: () -> Unit,
    onStartMatch: () -> Unit,
    onEnterSyncedGame: (GameRoom, RoomPlayer?) -> Unit
) {
    val context = LocalContext.current
    val strings = AppStrings.get(language)
    val myPlayer = players.firstOrNull { it.uid == currentUserId }
    val isHost = room?.hostUid == currentUserId

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ChampagneGold)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(room?.adventureTitle ?: "Salon privé", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                    Text(
                        text = if (room?.eventOrgName != null) "Événement : ${room.eventOrgName}" else "Code : ${room?.roomCode ?: "..."}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmParchment
                    )
                }
                LuxuryPillTag(text = room?.status ?: "LOBBY")
            }

            if (room != null) {
                // Invite & QR Matrix Card
                GoldSurfaceCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RoomInviteMatrix(roomCode = room.roomCode, size = 122.dp)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("CODE D'INVITATION", style = MaterialTheme.typography.labelSmall, color = MetallicGold)
                            Text(room.roomCode, style = MaterialTheme.typography.headlineLarge, color = ChampagneGold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Les invités rejoignent gratuitement avec ce code ou QR.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmParchment
                            )
                            Spacer(Modifier.height(10.dp))
                            LuxuryOutlineButton(
                                text = strings.shareInvite,
                                icon = Icons.Default.Share,
                                testTag = "share_room_invite_button",
                                onClick = {
                                    val shareText = "Rejoins ma partie HÉRITAGE — THE LAST HEIR (${room.adventureTitle}) ! Code du salon : ${room.roomCode}"
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, shareText)
                                    }
                                    context.startActivity(Intent.createChooser(intent, strings.shareInvite))
                                }
                            )
                        }
                    }
                }

                // Strictly Private Secret Objective Card
                if (mySecret != null) {
                    GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.65f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = ChampagneGold)
                            Spacer(Modifier.width(8.dp))
                            Text("Votre Secret Confidentiel (Isolé)", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(mySecret.secretObjective, style = MaterialTheme.typography.bodyLarge, color = IvoryWhite)
                        Spacer(Modifier.height(4.dp))
                        Text("Indice privé : ${mySecret.secretClue}", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                    }
                }

                // Participants List
                GoldSurfaceCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Participants (${players.size}/${room.maxPlayers})", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        if (isHost && room.status == "LOBBY") {
                            LuxuryOutlineButton(
                                text = "Rôles auto",
                                icon = Icons.Default.Casino,
                                onClick = onAssignRandomRoles
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    players.forEach { p ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MidnightCharcoal,
                            border = BorderStroke(1.dp, if (p.ready) EmeraldTrust else HairlineGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(p.displayName, style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                    Text("${p.characterName} • ${p.roleTitle}", style = MaterialTheme.typography.bodyMedium, color = ChampagneGold)
                                }
                                LuxuryPillTag(
                                    text = if (p.ready) "PRÊT" else "EN ATTENTE",
                                    containerColor = if (p.ready) EmeraldTrust.copy(alpha = 0.35f) else DeepBurgundy
                                )
                            }
                        }
                    }
                }

                // Character Selection in Lobby
                if (room.status == "LOBBY") {
                    GoldSurfaceCard {
                        Text("Sélection de votre personnage", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Spacer(Modifier.height(10.dp))
                        AdventureCatalog.heirs.forEach { heir ->
                            val selected = myPlayer?.characterId == heir.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) DeepBurgundy.copy(alpha = 0.7f) else MidnightCharcoal,
                                border = BorderStroke(1.dp, if (selected) MetallicGold else HairlineGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        onSelectCharacter(
                                            heir.id,
                                            heir.name,
                                            if (language == AppLanguage.EN) heir.titleEn else heir.titleFr
                                        )
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(heir.name, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                                        Text(
                                            if (language == AppLanguage.EN) heir.titleEn else heir.titleFr,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = WarmParchment
                                        )
                                    }
                                    if (selected) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MetallicGold)
                                    }
                                }
                            }
                        }
                    }

                    // Ready & Launch Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val readyNow = myPlayer?.ready == true
                        LuxuryOutlineButton(
                            text = if (readyNow) "Annuler Prêt" else strings.readyToggle,
                            testTag = "toggle_ready_button",
                            onClick = { onToggleReady(!readyNow) },
                            modifier = Modifier.weight(1f)
                        )
                        if (isHost) {
                            GoldPrimaryButton(
                                text = strings.startMatch,
                                icon = Icons.Default.PlayArrow,
                                testTag = "start_multiplayer_button",
                                onClick = onStartMatch,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                } else {
                    BurgundyAccentButton(
                        text = "Entrer dans la partie synchronisée (Acte ${room.currentChapter})",
                        icon = Icons.Default.PlayArrow,
                        testTag = "enter_synced_game_button",
                        onClick = { onEnterSyncedGame(room, myPlayer) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
