package com.example.ui.screens

import android.app.Activity
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.AdventureCatalog
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LegalInfoDialog
import com.example.ui.components.LuxuryBackdrop
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun LandingAuthScreen(
    language: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val strings = AppStrings.get(language)

    var showSplash by remember { mutableStateOf(true) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var legalDialogTitle by remember { mutableStateOf<String?>(null) }

    val splashScale = remember { Animatable(0.82f) }
    val splashAlpha = remember { Animatable(0f) }

    // Animated Splash + Silent Auto Sign-In check
    LaunchedEffect(Unit) {
        launch {
            splashAlpha.animateTo(1f, tween(600))
        }
        launch {
            splashScale.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        }
        attemptAutoSignIn(
            context = context,
            credentialManager = credentialManager,
            onAuthSuccess = onAuthSuccess,
            onUnauthenticated = {},
            scope = this
        )
        delay(1250L)
        showSplash = false
    }

    LuxuryBackdrop {
        if (showSplash) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .scale(splashScale.value)
                        .alpha(splashAlpha.value)
                        .padding(32.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.heritage_icon_fg),
                        contentDescription = strings.appTitle,
                        modifier = Modifier
                            .size(116.dp)
                            .clip(RoundedCornerShape(28.dp))
                    )
                    Spacer(Modifier.height(22.dp))
                    Text(
                        text = strings.appTitle,
                        style = MaterialTheme.typography.displayLarge,
                        color = ChampagneGold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = strings.appSubtitle,
                        style = MaterialTheme.typography.labelLarge,
                        color = MetallicGold,
                        letterSpacing = androidx.compose.ui.unit.TextUnit(4f, androidx.compose.ui.unit.TextUnitType.Sp)
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = strings.slogan,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmParchment,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            AnimatedVisibility(
                visible = true,
                enter = fadeIn(tween(450)),
                exit = fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .windowInsetsPadding(WindowInsets.safeDrawing)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Column(
                        modifier = Modifier.widthIn(max = 600.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        // Top bar with Crest & Language Pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Image(
                                    painter = painterResource(id = R.drawable.heritage_icon_fg),
                                    contentDescription = strings.appTitle,
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = strings.appTitle,
                                        style = MaterialTheme.typography.titleLarge,
                                        color = ChampagneGold
                                    )
                                    Text(
                                        text = strings.appSubtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MetallicGold
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AppLanguage.entries.forEach { lang ->
                                    val selected = lang == language
                                    Surface(
                                        shape = CircleShape,
                                        color = if (selected) MetallicGold else VelvetSurface,
                                        border = BorderStroke(1.dp, HairlineGold),
                                        modifier = Modifier
                                            .clickable { onLanguageSelected(lang) }
                                            .testTag("lang_chip_${lang.code}")
                                    ) {
                                        Text(
                                            text = lang.code,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (selected) ObsidianBlack else WarmParchment,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Cinematic Hero Banner
                        ArtworkBanner(
                            artworkKey = "mansion",
                            title = strings.slogan,
                            subtitle = "100 000 000 $ • Saison 1 : Le dernier testament",
                            badge = "NETFLIX-GRADE THRILLER",
                            height = 230.dp
                        )

                        // Commercial Pitch & Sign In Card
                        GoldSurfaceCard {
                            Text(
                                text = strings.conceptPitch,
                                style = MaterialTheme.typography.bodyLarge,
                                color = IvoryWhite
                            )
                            Spacer(Modifier.height(16.dp))

                            if (!errorMessage.isNullOrBlank()) {
                                Surface(
                                    color = DeepBurgundy,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp)
                                ) {
                                    Text(
                                        text = errorMessage!!,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = IvoryWhite,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    errorMessage = null
                                    isLoading = true
                                    onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            isLoading = false
                                            onAuthSuccess()
                                        },
                                        onAuthError = { msg ->
                                            isLoading = false
                                            errorMessage = msg
                                        },
                                        scope = scope,
                                        onAuthCancelled = {
                                            isLoading = false
                                        }
                                    )
                                },
                                enabled = !isLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                                    .testTag("google_sign_in_button"),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MetallicGold,
                                    contentColor = ObsidianBlack
                                )
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(22.dp),
                                        color = ObsidianBlack,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(strings.signingIn, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text(strings.signInGoogle, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Three Pillars Preview
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PillarMiniCard(
                                icon = Icons.Default.AutoAwesome,
                                title = strings.soloMode,
                                desc = "IA Gemini",
                                modifier = Modifier.weight(1f)
                            )
                            PillarMiniCard(
                                icon = Icons.Default.Groups,
                                title = "4–20",
                                desc = "Temps réel",
                                modifier = Modifier.weight(1f)
                            )
                            PillarMiniCard(
                                icon = Icons.Default.Star,
                                title = "10",
                                desc = "Chapitres",
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Commercial Plans Overview
                        GoldSurfaceCard {
                            Text(
                                text = strings.storeTitle,
                                style = MaterialTheme.typography.titleLarge,
                                color = ChampagneGold
                            )
                            Spacer(Modifier.height(10.dp))
                            AdventureCatalog.commercialOffers.forEachIndexed { idx, offer ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (language == AppLanguage.EN) offer.titleEn else offer.titleFr,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = IvoryWhite
                                        )
                                        Text(
                                            text = if (language == AppLanguage.EN) offer.periodLabelEn else offer.periodLabelFr,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = WarmParchment
                                        )
                                    }
                                    LuxuryPillTag(
                                        text = if (offer.priceUsd == 0.0) "FREE" else "$${offer.priceUsd}"
                                    )
                                }
                                if (idx < AdventureCatalog.commercialOffers.lastIndex) {
                                    HorizontalDivider(color = HairlineGold)
                                }
                            }
                        }

                        // Legal & Security Footer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = MetallicGold, modifier = Modifier.size(16.dp))
                            TextButton(onClick = { legalDialogTitle = strings.termsTitle }) {
                                Text(strings.termsTitle, color = ChampagneGold, style = MaterialTheme.typography.bodyMedium)
                            }
                            Text("•", color = WarmParchment)
                            TextButton(onClick = { legalDialogTitle = strings.privacyTitle }) {
                                Text(strings.privacyTitle, color = ChampagneGold, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    legalDialogTitle?.let { title ->
        LegalInfoDialog(
            title = title,
            isFrench = language != AppLanguage.EN,
            onDismiss = { legalDialogTitle = null }
        )
    }
}

@Composable
private fun PillarMiniCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    modifier: Modifier = Modifier
) {
    GoldSurfaceCard(modifier = modifier, contentPadding = 12.dp) {
        Icon(icon, contentDescription = null, tint = MetallicGold, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, color = IvoryWhite, maxLines = 1)
        Text(desc, style = MaterialTheme.typography.labelSmall, color = ChampagneGold, maxLines = 1)
    }
}

fun attemptAutoSignIn(
    context: android.content.Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onUnauthenticated: () -> Unit,
    scope: CoroutineScope
) {
    if (Firebase.auth.currentUser != null) {
        onAuthSuccess()
        return
    }
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onUnauthenticated()
        return
    }
    val googleIdOption = GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(true)
        .setServerClientId(clientId)
        .setAutoSelectEnabled(true)
        .build()
    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleIdOption)
        .build()
    scope.launch {
        try {
            val cred = credentialManager.getCredential(context, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onUnauthenticated()
            }
        } catch (_: Exception) {
            onUnauthenticated()
        }
    }
}

fun onGoogleSignInClicked(
    context: android.content.Context,
    credentialManager: CredentialManager,
    onAuthSuccess: () -> Unit,
    onAuthError: (String) -> Unit,
    scope: CoroutineScope,
    onAuthCancelled: () -> Unit = {}
) {
    val clientId = try {
        context.getString(R.string.default_web_client_id)
    } catch (_: Exception) {
        onAuthError("Configuration Google Sign-In manquante (default_web_client_id).")
        return
    }
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()
    scope.launch {
        try {
            val activity = context as? Activity
                ?: throw IllegalStateException("Activity context required for Credential Manager")
            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                Firebase.auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                onAuthSuccess()
            } else {
                onAuthError("Type de jeton d'identification inattendu.")
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w("Auth", "Google Sign-In flow cancelled or dismissed: ${e.message}", e)
            onAuthCancelled()
        } catch (e: Exception) {
            Log.e("Auth", "Google Sign-In failed", e)
            onAuthError(e.localizedMessage ?: "Échec de la connexion Google.")
        }
    }
}
