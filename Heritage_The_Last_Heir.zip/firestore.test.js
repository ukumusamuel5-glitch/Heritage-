const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";
const ADMIN_UID = "admin_999";
const ADMIN_EMAIL = "ryanukumu2@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function pastDate(offsetMs = 5000) {
  return new Date(Date.now() - offsetMs);
}

test("Unauthenticated user: cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).get());
  await assertFails(unauthDb.collection("leaderboard").get());
  await assertFails(unauthDb.collection("adventures").get());
  await assertFails(unauthDb.collection("rooms").where("status", "==", "LOBBY").get());
});

test("User profile: owner can create FREE profile & update alias; cannot self-grant VIP or read Bob", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const created = pastDate(10000);

  // Valid create
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).set({
      userId: ALICE_UID,
      alias: "Lady Alice",
      email: "alice@example.com",
      language: "FR",
      reputation: 50,
      totalWealthM: 100,
      gamesPlayed: 0,
      gamesWon: 0,
      trophies: [],
      activePlan: "FREE",
      referralCode: "ALICE99",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Reject self-granting VIP on update
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      activePlan: "VIP",
      updatedAt: pastDate(1000),
    })
  );

  // Valid partial update
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      alias: "Duchess Alice",
      reputation: 65,
      updatedAt: pastDate(1000),
    })
  );

  // Reject reading Bob's PII
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx.firestore().collection("users").doc(BOB_UID).set({
      userId: BOB_UID,
      alias: "Lord Bob",
      email: "bob@example.com",
      language: "EN",
      reputation: 50,
      totalWealthM: 100,
      gamesPlayed: 0,
      gamesWon: 0,
      trophies: [],
      activePlan: "FREE",
      referralCode: "BOB123",
      createdAt: created,
      updatedAt: created,
    });
  });
  await assertFails(aliceDb.collection("users").doc(BOB_UID).get());
});

test("Solo saves: scoped to userId, terminal COMPLETED state locked", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = pastDate(10000);

  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("solo_saves").doc("save_1").set({
      userId: ALICE_UID,
      adventureId: "last_testament",
      adventureTitle: "Le dernier testament",
      characterId: "victoria",
      characterName: "Victoria Vance",
      currentChapter: 1,
      score: 120,
      virtualWealthM: 25,
      reputation: 60,
      discoveredClues: ["clue_seal"],
      completedMissions: [],
      unlockedVaults: [],
      allies: [],
      decisionsLog: ["c1_read_will"],
      status: "IN_PROGRESS",
      createdAt: created,
      updatedAt: created,
    })
  );

  // List works cleanly on empty or populated user subcollection
  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("solo_saves").get());

  // Bob cannot access Alice's save
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("solo_saves").doc("save_1").get());

  // Mark COMPLETED
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("solo_saves").doc("save_1").update({
      currentChapter: 10,
      status: "COMPLETED",
      endingId: "sole_heir",
      updatedAt: pastDate(1000),
    })
  );

  // Terminal state lock rejects further edits
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("solo_saves").doc("save_1").update({
      score: 99999,
      updatedAt: pastDate(500),
    })
  );
});

test("Multiplayer rooms, secrets isolation, and public/private messaging", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = pastDate(10000);

  // Alice creates room
  await assertSucceeds(
    aliceDb.collection("rooms").doc("room_1").set({
      roomCode: "HER777",
      hostUid: ALICE_UID,
      hostName: "Alice",
      adventureId: "last_testament",
      adventureTitle: "Le dernier testament",
      mode: "MULTI_CLASSIC",
      status: "LOBBY",
      currentChapter: 1,
      maxPlayers: 10,
      memberUids: [ALICE_UID],
      createdAt: created,
      updatedAt: created,
    })
  );

  // Bob queries LOBBY by code and joins
  await assertSucceeds(
    bobDb.collection("rooms").where("status", "==", "LOBBY").where("roomCode", "==", "HER777").get()
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc("room_1").update({
      memberUids: [ALICE_UID, BOB_UID],
      updatedAt: pastDate(1000),
    })
  );

  // Bob creates his own player doc and secret doc
  await assertSucceeds(
    bobDb.collection("rooms").doc("room_1").collection("players").doc(BOB_UID).set({
      uid: BOB_UID,
      displayName: "Bob",
      characterId: "julian",
      characterName: "Julian Mercer",
      roleTitle: "Directeur Financier",
      score: 0,
      virtualWealthM: 20,
      reputation: 50,
      ready: true,
      connected: true,
      joinedAt: pastDate(1000),
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    bobDb.collection("rooms").doc("room_1").collection("secrets").doc(BOB_UID).set({
      uid: BOB_UID,
      secretObjective: "Détourner le code du coffre B",
      secretClue: "Le code finit par 84",
      updatedAt: pastDate(1000),
    })
  );

  // Alice CANNOT read Bob's secret doc!
  await assertFails(
    aliceDb.collection("rooms").doc("room_1").collection("secrets").doc(BOB_UID).get()
  );

  // Private whisper from Alice to Bob (not visible to third party)
  await assertSucceeds(
    aliceDb.collection("rooms").doc("room_1").collection("messages").doc("msg_1").set({
      senderUid: ALICE_UID,
      senderName: "Alice",
      recipientUid: BOB_UID,
      body: "Alliance secrète ?",
      visibleToUids: [ALICE_UID, BOB_UID],
      createdAt: pastDate(1000),
    })
  );

  // Bob queries messages with array-contains
  await assertSucceeds(
    bobDb.collection("rooms").doc("room_1").collection("messages").where("visibleToUids", "array-contains", BOB_UID).get()
  );
  // Unfiltered messages query fails
  await assertFails(
    bobDb.collection("rooms").doc("room_1").collection("messages").get()
  );
});

test("Purchases & Admin RBAC: non-admin cannot verify purchase or spoof admin email without verification", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const spoofAdminDb = testEnv.authenticatedContext("spoof", { email: ADMIN_EMAIL, email_verified: false }).firestore();
  const realAdminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();
  const created = pastDate(10000);

  // Alice cannot create an already-VERIFIED purchase
  await assertFails(
    aliceDb.collection("purchases").doc("p_fake").set({
      userId: ALICE_UID,
      offerId: "vip_monthly",
      title: "Abonnement VIP",
      amountUsd: 9.99,
      paymentMethod: "Google Play",
      status: "VERIFIED",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice creates PENDING_VERIFICATION order
  await assertSucceeds(
    aliceDb.collection("purchases").doc("p_1").set({
      userId: ALICE_UID,
      offerId: "vip_monthly",
      title: "Abonnement VIP",
      amountUsd: 9.99,
      paymentMethod: "M-Pesa",
      status: "PENDING_VERIFICATION",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Alice cannot verify her own purchase
  await assertFails(
    aliceDb.collection("purchases").doc("p_1").update({
      status: "VERIFIED",
      updatedAt: pastDate(1000),
    })
  );

  // Unverified email spoof CANNOT verify purchase
  await assertFails(
    spoofAdminDb.collection("purchases").doc("p_1").update({
      status: "VERIFIED",
      updatedAt: pastDate(1000),
    })
  );

  // Verified admin CAN verify purchase & publish adventures
  await assertSucceeds(
    realAdminDb.collection("purchases").doc("p_1").update({
      status: "VERIFIED",
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    realAdminDb.collection("adventures").doc("adv_custom_1").set({
      title: "Le Secret de Genève",
      subtitle: "Banque privée et trahison",
      synopsis: "Une enquête nocturne au bord du lac Léman.",
      tier: "SOLO_PREMIUM",
      priceUsd: 4.99,
      durationMinutes: 75,
      minPlayers: 1,
      maxPlayers: 1,
      published: true,
      playable: true,
      chaptersCount: 10,
      coverKey: "vault",
      customChapters: ["Chapitre 1 : L'ouverture du coffre"],
      createdByUid: ADMIN_UID,
      createdAt: created,
      updatedAt: created,
    })
  );
});
