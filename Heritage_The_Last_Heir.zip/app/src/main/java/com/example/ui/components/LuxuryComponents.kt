package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.BurnishedBronze
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CrimsonVelvet
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment

@DrawableRes
fun artworkResForKey(key: String): Int = when (key) {
    "vault" -> R.drawable.img_vault_chamber
    "testament" -> R.drawable.img_testament_scroll
    "boardroom" -> R.drawable.img_boardroom_council
    else -> R.drawable.img_mansion_hero
}

@Composable
fun LuxuryBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ObsidianBlack,
                        MidnightCharcoal,
                        Color(0xFF140B12),
                        ObsidianBlack
                    )
                )
            )
    ) {
        content()
    }
}

@Composable
fun GoldSurfaceCard(
    modifier: Modifier = Modifier,
    accentBorder: Boolean = true,
    containerColor: Color = VelvetSurface,
    contentPadding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = if (accentBorder) BorderStroke(1.dp, HairlineGold) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.padding(contentPadding)) {
            content()
        }
    }
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "gold_button",
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(52.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MetallicGold,
            contentColor = ObsidianBlack,
            disabledContainerColor = BurnishedBronze.copy(alpha = 0.4f),
            disabledContentColor = WarmParchment.copy(alpha = 0.6f)
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BurgundyAccentButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "burgundy_button",
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(50.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = CrimsonVelvet,
            contentColor = IvoryWhite
        ),
        border = BorderStroke(1.dp, MetallicGold.copy(alpha = 0.35f)),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LuxuryOutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "outline_button",
    icon: ImageVector? = null,
    enabled: Boolean = true
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(48.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MetallicGold.copy(alpha = 0.6f)),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun LuxuryPillTag(
    text: String,
    containerColor: Color = DeepBurgundy,
    contentColor: Color = ChampagneGold,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = CircleShape,
        color = containerColor,
        border = BorderStroke(0.75.dp, MetallicGold.copy(alpha = 0.45f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ArtworkBanner(
    artworkKey: String,
    title: String,
    subtitle: String? = null,
    badge: String? = null,
    height: Dp = 190.dp,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(MaterialTheme.shapes.large)
    ) {
        Image(
            painter = painterResource(id = artworkResForKey(artworkKey)),
            contentDescription = title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.15f),
                            Color.Black.copy(alpha = 0.45f),
                            ObsidianBlack.copy(alpha = 0.94f)
                        )
                    )
                )
        )
        if (!badge.isNullOrBlank()) {
            LuxuryPillTag(
                text = badge,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp)
            )
        }
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = IvoryWhite
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ChampagneGold
                )
            }
        }
    }
}

@Composable
fun LegalInfoDialog(
    title: String,
    isFrench: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MidnightCharcoal,
        titleContentColor = ChampagneGold,
        textContentColor = WarmParchment,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = MetallicGold)
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .height(300.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isFrench) {
                    Text("1. Nature exclusivement fictive des fortunes", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("Toutes les fortunes (100 millions $), actifs, enchères, coffres et récompenses de HÉRITAGE — THE LAST HEIR sont 100 % virtuels. Aucun pari d'argent réel ni retrait financier n'est possible.")
                    HorizontalDivider(color = HairlineGold)
                    Text("2. Protection des données personnelles", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("Votre authentification passe par Google Sign-In. Vos rôles secrets, messages privés et sauvegardes sont isolés par règles de sécurité Firestore et ne sont jamais exposés publiquement.")
                    HorizontalDivider(color = HairlineGold)
                    Text("3. Achats & Vérification serveur", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("Les offres payantes nécessitent une validation côté serveur (Google Play Billing / prestataire agréé) avant activation définitive.")
                } else {
                    Text("1. Strictly Virtual Estates", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("All estates ($100M), assets, vaults, and rewards in HÉRITAGE — THE LAST HEIR are 100% virtual. No real-money gambling, wagering, or cash withdrawals exist.")
                    HorizontalDivider(color = HairlineGold)
                    Text("2. Privacy & Security", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("Authentication is handled via Google Sign-In. Secret objectives, private whispers, and game saves are isolated via Firestore zero-trust security rules.")
                    HorizontalDivider(color = HairlineGold)
                    Text("3. Server-Verified Purchases", fontWeight = FontWeight.Bold, color = IvoryWhite)
                    Text("Paid tiers require server-side payment verification (Google Play Billing / authorized provider) prior to unlocking.")
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("OK", color = MetallicGold)
            }
        }
    )
}
