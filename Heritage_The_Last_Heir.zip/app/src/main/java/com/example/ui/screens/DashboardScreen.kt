package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.AdventureCatalog
import com.example.model.CharacterArchetype
import com.example.model.GameRoom
import com.example.model.SoloSave
import com.example.model.UserProfile
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.BurgundyAccentButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.UiState

@Composable
fun DashboardScreen(
    language: AppLanguage,
    profileState: UiState<UserProfile?>,
    savesState: UiState<List<SoloSave>>,
    roomsState: UiState<List<GameRoom>>,
    isAdmin: Boolean,
    onLaunchSolo: (adventureId: String, adventureTitle: String, character: CharacterArchetype) -> Unit,
    onResumeSave: (SoloSave) -> Unit,
    onOpenRooms: () -> Unit,
    onOpenRoom: (String) -> Unit,
    onOpenStore: () -> Unit,
    onOpenAdmin: () -> Unit
) {
    val strings = AppStrings.get(language)
    var pendingAdventureForPicker by remember { mutableStateOf<Pair<String, String>?>(null) }

    val profile = (profileState as? UiState.Success)?.data
    val saves = (savesState as? UiState.Success)?.data.orEmpty()
    val inProgressSave = saves.firstOrNull { it.status == "IN_PROGRESS" }
    val activeRooms = (roomsState as? UiState.Success)?.data.orEmpty().filter { it.status != "FINISHED" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Player Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = profile?.alias ?: strings.appTitle,
                        style = MaterialTheme.typography.headlineLarge,
                        color = ChampagneGold
                    )
                    Text(
                        text = strings.slogan,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmParchment
                    )
                }
                LuxuryPillTag(text = profile?.activePlan ?: "FREE")
            }

            if (profileState is UiState.Loading) {
                CircularProgressIndicator(color = MetallicGold, modifier = Modifier.size(28.dp))
            }

            // Virtual Empire KPIs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text(strings.wealthLabel, style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                    Spacer(Modifier.height(4.dp))
                    Text("${profile?.totalWealthM ?: 100} M$", style = MaterialTheme.typography.headlineMedium, color = IvoryWhite)
                }
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text(strings.reputationLabel, style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                    Spacer(Modifier.height(4.dp))
                    Text("${profile?.reputation ?: 50} / 100", style = MaterialTheme.typography.headlineMedium, color = IvoryWhite)
                }
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text("Victoires", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                    Spacer(Modifier.height(4.dp))
                    Text("${profile?.gamesWon ?: 0}", style = MaterialTheme.typography.headlineMedium, color = MetallicGold)
                }
            }

            // Internal Notification Banner
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = DeepBurgundy.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, MetallicGold.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = ChampagneGold)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (language == AppLanguage.EN) {
                            "Season 1 Live: The Last Will (10 Chapters) & Free 15-min Discovery are ready."
                        } else {
                            "Saison 1 ouverte : Le dernier testament (10 chapitres) et la mini-aventure gratuite sont disponibles."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryWhite
                    )
                }
            }

            // Resume Cloud Auto-Save if available
            if (inProgressSave != null) {
                GoldSurfaceCard(containerColor = ColorTokens.HighlightSurface) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            LuxuryPillTag(text = "${strings.chaptersLabel} ${inProgressSave.currentChapter}")
                            Spacer(Modifier.height(6.dp))
                            Text(inProgressSave.adventureTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                            Text(
                                "${inProgressSave.characterName} • ${inProgressSave.virtualWealthM}M$ • ${inProgressSave.score} pts",
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmParchment
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    GoldPrimaryButton(
                        text = strings.resumeGame,
                        icon = Icons.Default.Restore,
                        testTag = "resume_save_button",
                        onClick = { onResumeSave(inProgressSave) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Featured Adventure Banner
            ArtworkBanner(
                artworkKey = "mansion",
                title = if (language == AppLanguage.EN) "The Last Will" else "Le dernier testament",
                subtitle = "100 M$ • 10 Chapitres • IA & Multijoueur",
                badge = "SAISON 1",
                height = 195.dp
            )

            // Primary Launch Actions
            GoldSurfaceCard {
                Text(
                    text = if (language == AppLanguage.EN) "Choose Your Entry" else "Entrer dans l'Empire",
                    style = MaterialTheme.typography.titleLarge,
                    color = ChampagneGold
                )
                Spacer(Modifier.height(12.dp))
                GoldPrimaryButton(
                    text = strings.playDiscoveryFree,
                    icon = Icons.Default.PlayArrow,
                    testTag = "play_discovery_button",
                    onClick = {
                        pendingAdventureForPicker = "discovery_free" to if (language == AppLanguage.EN) {
                            "Discovery: The Antechamber"
                        } else {
                            "Découverte : L'Antichambre"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                BurgundyAccentButton(
                    text = strings.playLastTestament,
                    icon = Icons.Default.AutoAwesome,
                    testTag = "play_last_testament_button",
                    onClick = {
                        pendingAdventureForPicker = "last_testament" to if (language == AppLanguage.EN) {
                            "The Last Will"
                        } else {
                            "Le dernier testament"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LuxuryOutlineButton(
                    text = strings.multiplayerMode,
                    icon = Icons.Default.Groups,
                    testTag = "open_multiplayer_button",
                    onClick = onOpenRooms,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Active Multiplayer Rooms for instant reconnect
            if (activeRooms.isNotEmpty()) {
                GoldSurfaceCard {
                    Text(
                        text = if (language == AppLanguage.EN) "Active Lobbies (Reconnect)" else "Salons actifs (Reconnexion)",
                        style = MaterialTheme.typography.titleLarge,
                        color = ChampagneGold
                    )
                    Spacer(Modifier.height(8.dp))
                    activeRooms.forEach { room ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onOpenRoom(room.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${room.adventureTitle} (${room.roomCode})", style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                    Text("${room.memberUids.size}/${room.maxPlayers} joueurs • ${room.status}", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                }
                                LuxuryPillTag(text = "Rejoindre")
                            }
                        }
                    }
                }
            }

            // VIP / Store & Admin quick cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GoldSurfaceCard(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenStore() }
                ) {
                    Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.height(6.dp))
                    Text(strings.storeTitle, style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                    Text("VIP, Événementiel, Mobile Money", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                }

                if (isAdmin) {
                    GoldSurfaceCard(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onOpenAdmin() }
                            .testTag("admin_dashboard_card"),
                        containerColor = DeepBurgundy.copy(alpha = 0.7f)
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = ChampagneGold)
                        Spacer(Modifier.height(6.dp))
                        Text(strings.adminTitle, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                        Text("Scénarios, Ventes & Promo", style = MaterialTheme.typography.bodyMedium, color = IvoryWhite)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    pendingAdventureForPicker?.let { (advId, advTitle) ->
        CharacterPickerDialog(
            language = language,
            adventureTitle = advTitle,
            onSelect = { character ->
                pendingAdventureForPicker = null
                onLaunchSolo(advId, advTitle, character)
            },
            onDismiss = { pendingAdventureForPicker = null }
        )
    }
}

private object ColorTokens {
    val HighlightSurface = androidx.compose.ui.graphics.Color(0xFF1F1922)
}

@Composable
fun CharacterPickerDialog(
    language: AppLanguage,
    adventureTitle: String,
    onSelect: (CharacterArchetype) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MidnightCharcoal,
        titleContentColor = ChampagneGold,
        title = {
            Column {
                Text(
                    text = if (language == AppLanguage.EN) "Select Your Heir" else "Choisissez votre Héritier",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(adventureTitle, style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .height(360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdventureCatalog.heirs.forEach { heir ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = VelvetSurface,
                        border = BorderStroke(1.dp, HairlineGold),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(heir) }
                            .testTag("select_heir_${heir.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(heir.name, style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                                LuxuryPillTag(text = "${heir.startingWealthM} M$")
                            }
                            Text(
                                text = if (language == AppLanguage.EN) heir.titleEn else heir.titleFr,
                                style = MaterialTheme.typography.labelSmall,
                                color = MetallicGold
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = if (language == AppLanguage.EN) heir.backgroundEn else heir.backgroundFr,
                                style = MaterialTheme.typography.bodyMedium,
                                color = WarmParchment
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (language == AppLanguage.EN) "Cancel" else "Annuler", color = MetallicGold)
            }
        }
    )
}
