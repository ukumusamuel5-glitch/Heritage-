package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Login
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.GameRoom
import com.example.ui.components.ArtworkBanner
import com.example.ui.components.BurgundyAccentButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.UiState

@Composable
fun LobbyHubScreen(
    language: AppLanguage,
    roomsState: UiState<List<GameRoom>>,
    defaultAdventureId: String = "last_testament",
    defaultAdventureTitle: String = "Le dernier testament",
    onCreateRoom: (adventureId: String, adventureTitle: String, mode: String, maxPlayers: Int, eventOrgName: String?) -> Unit,
    onJoinRoomByCode: (String) -> Unit,
    onOpenRoom: (String) -> Unit
) {
    val strings = AppStrings.get(language)
    var roomCodeInput by remember { mutableStateOf("") }
    var selectedMode by remember { mutableStateOf("MULTI_CLASSIC") }
    var maxPlayersSlider by remember { mutableFloatStateOf(10f) }
    var eventOrgName by remember { mutableStateOf("") }

    val rooms = (roomsState as? UiState.Success)?.data.orEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ArtworkBanner(
                artworkKey = "boardroom",
                title = strings.multiplayerMode,
                subtitle = "4 à 20 joueurs • Synchronisation temps réel • Reconnexion",
                badge = "SALONS PRIVÉS & ÉVÉNEMENTIEL",
                height = 170.dp
            )

            // Join by Code
            GoldSurfaceCard {
                Text(strings.joinRoom, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = roomCodeInput,
                    onValueChange = { roomCodeInput = it.uppercase() },
                    label = { Text(strings.roomCodeHint) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("join_room_code_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite,
                        focusedLabelColor = ChampagneGold
                    )
                )
                Spacer(Modifier.height(10.dp))
                GoldPrimaryButton(
                    text = strings.joinRoom,
                    icon = Icons.AutoMirrored.Filled.Login,
                    testTag = "join_room_button",
                    enabled = roomCodeInput.trim().length >= 4,
                    onClick = { onJoinRoomByCode(roomCodeInput.trim()) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Create Private / Event Lobby
            GoldSurfaceCard {
                Text(strings.createRoom, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "MULTI_CLASSIC" to "Classique",
                        "MULTI_PREMIUM" to "Premium",
                        "EVENT" to "Événement"
                    ).forEach { (mode, label) ->
                        val active = selectedMode == mode
                        Surface(
                            shape = CircleShape,
                            color = if (active) MetallicGold else MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier
                                .weight(1f)
                                .clickable {
                                    selectedMode = mode
                                    if (mode == "MULTI_CLASSIC" && maxPlayersSlider > 10f) maxPlayersSlider = 10f
                                    if (mode != "MULTI_CLASSIC" && maxPlayersSlider < 12f) maxPlayersSlider = 16f
                                }
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (active) ObsidianBlack else IvoryWhite,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                val capLimit = if (selectedMode == "MULTI_CLASSIC") 10f else 20f
                Text(
                    text = "Capacité maximale : ${maxPlayersSlider.toInt()} participants",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmParchment
                )
                Slider(
                    value = maxPlayersSlider.coerceIn(4f, capLimit),
                    onValueChange = { maxPlayersSlider = it },
                    valueRange = 4f..capLimit,
                    steps = (capLimit.toInt() - 5).coerceAtLeast(0),
                    colors = SliderDefaults.colors(
                        thumbColor = MetallicGold,
                        activeTrackColor = MetallicGold
                    )
                )

                if (selectedMode == "EVENT") {
                    OutlinedTextField(
                        value = eventOrgName,
                        onValueChange = { eventOrgName = it },
                        label = { Text("Nom de l'événement / Entreprise / Mariage") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MetallicGold,
                            unfocusedBorderColor = HairlineGold,
                            focusedTextColor = IvoryWhite,
                            unfocusedTextColor = IvoryWhite
                        )
                    )
                }

                BurgundyAccentButton(
                    text = "${strings.createRoom} • $defaultAdventureTitle",
                    icon = if (selectedMode == "EVENT") Icons.Default.Celebration else Icons.Default.AddCircle,
                    testTag = "create_room_button",
                    onClick = {
                        onCreateRoom(
                            defaultAdventureId,
                            defaultAdventureTitle,
                            selectedMode,
                            maxPlayersSlider.toInt(),
                            eventOrgName.takeIf { selectedMode == "EVENT" && it.isNotBlank() }
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // My Active / Past Rooms
            if (rooms.isNotEmpty()) {
                GoldSurfaceCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = MetallicGold)
                        Spacer(Modifier.width(8.dp))
                        Text("Mes salons synchronisés", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                    }
                    Spacer(Modifier.height(10.dp))
                    rooms.forEach { room ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { onOpenRoom(room.id) }
                                .testTag("room_card_${room.roomCode}")
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${room.adventureTitle} • ${room.roomCode}", style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                    Text(
                                        "${room.memberUids.size}/${room.maxPlayers} joueurs • Acte ${room.currentChapter}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = WarmParchment
                                    )
                                }
                                LuxuryPillTag(text = room.status)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
