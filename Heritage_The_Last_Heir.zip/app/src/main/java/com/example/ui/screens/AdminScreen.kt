package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.model.PromoCode
import com.example.model.PurchaseOrder
import com.example.model.SupportReport
import com.example.model.UserProfile
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.VelvetSurface
import com.example.ui.theme.WarmParchment

@Composable
fun AdminScreen(
    users: List<UserProfile>,
    purchases: List<PurchaseOrder>,
    reports: List<SupportReport>,
    promoCodes: List<PromoCode>,
    onPublishAdventure: (title: String, subtitle: String, synopsis: String, tier: String, priceUsd: Double, chaptersText: String) -> Unit,
    onCreatePromo: (code: String, discount: Int, maxUses: Int) -> Unit,
    onVerifyOrder: (PurchaseOrder, Boolean) -> Unit,
    onResolveReport: (String, String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var adminTab by remember { mutableIntStateOf(0) }
    var advTitle by remember { mutableStateOf("") }
    var advSubtitle by remember { mutableStateOf("") }
    var advSynopsis by remember { mutableStateOf("") }
    var advPrice by remember { mutableStateOf("4.99") }
    var advChapters by remember { mutableStateOf("Chapitre 1 : L'arrivée\nChapitre 2 : Le coffre\nChapitre 3 : Le verdict") }

    var promoCodeInput by remember { mutableStateOf("") }
    var promoDiscount by remember { mutableStateOf("20") }

    val verifiedRevenue = purchases.filter { it.status == "VERIFIED" }.sumOf { it.amountUsd }
    val pendingCount = purchases.count { it.status == "PENDING_VERIFICATION" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 620.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ChampagneGold)
                }
                Text("Espace Administrateur", style = MaterialTheme.typography.headlineMedium, color = ChampagneGold)
            }

            // Revenue & Traffic KPIs
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text("REVENUS VÉRIFIÉS", style = MaterialTheme.typography.labelSmall, color = MetallicGold)
                    Text("$verifiedRevenue $", style = MaterialTheme.typography.titleLarge, color = IvoryWhite)
                }
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text("COMMANDES ATTENTE", style = MaterialTheme.typography.labelSmall, color = MetallicGold)
                    Text("$pendingCount", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                GoldSurfaceCard(modifier = Modifier.weight(1f), contentPadding = 12.dp) {
                    Text("JOUEURS", style = MaterialTheme.typography.labelSmall, color = MetallicGold)
                    Text("${users.size}", style = MaterialTheme.typography.titleLarge, color = IvoryWhite)
                }
            }

            // Tabs
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Éditeur Scénarios", "Ventes & Vérif", "Codes Promo", "Signalements").forEachIndexed { idx, label ->
                    val active = adminTab == idx
                    Surface(
                        shape = CircleShape,
                        color = if (active) MetallicGold else VelvetSurface,
                        border = BorderStroke(1.dp, HairlineGold),
                        modifier = Modifier.clickable { adminTab = idx }
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (active) ObsidianBlack else IvoryWhite,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }

            when (adminTab) {
                0 -> {
                    GoldSurfaceCard {
                        Text("Éditeur de scénarios sans code", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = advTitle,
                            onValueChange = { advTitle = it },
                            label = { Text("Titre de l'aventure") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = advSubtitle,
                            onValueChange = { advSubtitle = it },
                            label = { Text("Sous-titre") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = advSynopsis,
                            onValueChange = { advSynopsis = it },
                            label = { Text("Synopsis") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = advPrice,
                            onValueChange = { advPrice = it },
                            label = { Text("Prix USD") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = advChapters,
                            onValueChange = { advChapters = it },
                            label = { Text("Chapitres (1 par ligne)") },
                            minLines = 3,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(12.dp))
                        GoldPrimaryButton(
                            text = "Publier dans le catalogue",
                            icon = Icons.Default.Publish,
                            enabled = advTitle.trim().length >= 3 && advSynopsis.trim().length >= 10,
                            onClick = {
                                onPublishAdventure(
                                    advTitle,
                                    advSubtitle.ifBlank { "Nouvelle aventure officielle" },
                                    advSynopsis,
                                    "SOLO_PREMIUM",
                                    advPrice.toDoubleOrNull() ?: 4.99,
                                    advChapters
                                )
                                advTitle = ""
                                advSubtitle = ""
                                advSynopsis = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                1 -> {
                    GoldSurfaceCard {
                        Text("Commandes & Vérification (${purchases.size})", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Spacer(Modifier.height(8.dp))
                        purchases.forEach { order ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MidnightCharcoal,
                                border = BorderStroke(1.dp, HairlineGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("${order.title} • ${order.amountUsd}$", style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                        LuxuryPillTag(
                                            text = order.status,
                                            containerColor = if (order.status == "VERIFIED") EmeraldTrust.copy(alpha = 0.35f) else DeepBurgundy
                                        )
                                    }
                                    Text("${order.paymentMethod} • Ref: ${order.referenceNote ?: "-"}", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                    if (order.status == "PENDING_VERIFICATION") {
                                        Spacer(Modifier.height(8.dp))
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            GoldPrimaryButton(
                                                text = "Valider",
                                                icon = Icons.Default.Check,
                                                onClick = { onVerifyOrder(order, true) },
                                                modifier = Modifier.weight(1f)
                                            )
                                            LuxuryOutlineButton(
                                                text = "Refuser",
                                                icon = Icons.Default.Close,
                                                onClick = { onVerifyOrder(order, false) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    GoldSurfaceCard {
                        Text("Créer un code promotionnel", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = promoCodeInput,
                            onValueChange = { promoCodeInput = it.uppercase() },
                            label = { Text("Code (ex: HERITAGE20)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = promoDiscount,
                            onValueChange = { promoDiscount = it },
                            label = { Text("Réduction (%)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MetallicGold, unfocusedBorderColor = HairlineGold, focusedTextColor = IvoryWhite, unfocusedTextColor = IvoryWhite)
                        )
                        Spacer(Modifier.height(10.dp))
                        GoldPrimaryButton(
                            text = "Créer le code promo",
                            enabled = promoCodeInput.trim().length >= 3,
                            onClick = {
                                onCreatePromo(promoCodeInput, promoDiscount.toIntOrNull() ?: 20, 200)
                                promoCodeInput = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        promoCodes.forEach { p ->
                            Text("• ${p.code} : -${p.discountPercent}% (${p.usageCount}/${p.maxUses})", color = ChampagneGold)
                        }
                    }
                }
                else -> {
                    GoldSurfaceCard {
                        Text("Signalements & Assistance (${reports.size})", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                        Spacer(Modifier.height(8.dp))
                        reports.forEach { rep ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MidnightCharcoal,
                                border = BorderStroke(1.dp, HairlineGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("${rep.category} : ${rep.subject}", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                                    Text(rep.message, style = MaterialTheme.typography.bodyMedium, color = IvoryWhite)
                                    if (rep.status == "OPEN") {
                                        Spacer(Modifier.height(8.dp))
                                        GoldPrimaryButton(
                                            text = "Marquer Résolu",
                                            onClick = { onResolveReport(rep.id, "Pris en charge par l'administration Héritage.") },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
