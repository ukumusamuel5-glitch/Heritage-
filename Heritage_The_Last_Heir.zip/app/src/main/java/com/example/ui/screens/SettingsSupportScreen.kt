package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.SupportReport
import com.example.ui.components.BurgundyAccentButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LegalInfoDialog
import com.example.ui.components.LuxuryOutlineButton
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.EmeraldTrust
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.UiState

@Composable
fun SettingsSupportScreen(
    language: AppLanguage,
    audioEnabled: Boolean,
    voiceEnabled: Boolean,
    isAdmin: Boolean,
    supportState: UiState<List<SupportReport>>,
    onSetLanguage: (AppLanguage) -> Unit,
    onSetAudio: (Boolean) -> Unit,
    onSetVoice: (Boolean) -> Unit,
    onSubmitSupport: (category: String, subject: String, message: String) -> Unit,
    onOpenAdmin: () -> Unit,
    onSignOut: () -> Unit
) {
    val strings = AppStrings.get(language)
    val reports = (supportState as? UiState.Success)?.data.orEmpty()

    var category by remember { mutableStateOf("ASSISTANCE") }
    var subject by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var legalTitle by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language & Audio Settings
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Language, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.settingsTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val active = lang == language
                        Surface(
                            shape = CircleShape,
                            color = if (active) MetallicGold else MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier.clickable { onSetLanguage(lang) }
                        ) {
                            Text(
                                text = lang.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (active) ObsidianBlack else IvoryWhite,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null, tint = MetallicGold)
                        Spacer(Modifier.width(8.dp))
                        Text("Effets sonores de révélation", color = IvoryWhite)
                    }
                    Switch(
                        checked = audioEnabled,
                        onCheckedChange = onSetAudio,
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBlack, checkedTrackColor = MetallicGold)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Synthèse vocale des archives audio", color = IvoryWhite)
                    Switch(
                        checked = voiceEnabled,
                        onCheckedChange = onSetVoice,
                        colors = SwitchDefaults.colors(checkedThumbColor = ObsidianBlack, checkedTrackColor = MetallicGold)
                    )
                }
            }

            // Admin Shortcut (Role-Gated)
            if (isAdmin) {
                GoldSurfaceCard(containerColor = DeepBurgundy.copy(alpha = 0.7f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = ChampagneGold)
                        Spacer(Modifier.width(8.dp))
                        Text(strings.adminTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                    }
                    Spacer(Modifier.height(8.dp))
                    GoldPrimaryButton(
                        text = "Ouvrir l'Espace Administrateur",
                        testTag = "open_admin_console_button",
                        onClick = onOpenAdmin,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Support & Incident Report
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.SupportAgent, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.supportTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ASSISTANCE", "SIGNALEMENT", "PAIEMENT").forEach { cat ->
                        val active = category == cat
                        Surface(
                            shape = CircleShape,
                            color = if (active) MetallicGold else MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier.clickable { category = cat }
                        ) {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) ObsidianBlack else IvoryWhite,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Sujet") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Détail de votre demande") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite
                    )
                )
                Spacer(Modifier.height(10.dp))
                BurgundyAccentButton(
                    text = "Envoyer le ticket",
                    enabled = subject.trim().length >= 3 && message.trim().length >= 5,
                    onClick = {
                        onSubmitSupport(category, subject, message)
                        subject = ""
                        message = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                if (reports.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text("Mes tickets (${reports.size})", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                    reports.forEach { rep ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MidnightCharcoal,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(rep.subject, style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                    LuxuryPillTag(
                                        text = rep.status,
                                        containerColor = if (rep.status == "RESOLVED") EmeraldTrust.copy(alpha = 0.35f) else DeepBurgundy
                                    )
                                }
                                if (!rep.adminReply.isNullOrBlank()) {
                                    Text("Réponse : ${rep.adminReply}", style = MaterialTheme.typography.bodyMedium, color = ChampagneGold)
                                }
                            }
                        }
                    }
                }
            }

            // Legal & Sign Out
            GoldSurfaceCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(onClick = { legalTitle = strings.termsTitle }) {
                        Text(strings.termsTitle, color = ChampagneGold)
                    }
                    TextButton(onClick = { legalTitle = strings.privacyTitle }) {
                        Text(strings.privacyTitle, color = ChampagneGold)
                    }
                }
                Spacer(Modifier.height(8.dp))
                LuxuryOutlineButton(
                    text = strings.signOut,
                    icon = Icons.AutoMirrored.Filled.Logout,
                    testTag = "sign_out_button",
                    onClick = onSignOut,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(16.dp))
        }
    }

    legalTitle?.let { title ->
        LegalInfoDialog(
            title = title,
            isFrench = language != AppLanguage.EN,
            onDismiss = { legalTitle = null }
        )
    }
}
