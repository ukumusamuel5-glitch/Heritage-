package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppLanguage
import com.example.data.AiHeirService
import com.example.data.HeritageRepository
import com.example.model.AdventureCatalog
import com.example.model.CharacterArchetype
import com.example.model.SoloSave
import com.example.model.StoryChapter
import com.example.model.StoryChoice
import com.example.model.StoryEnding
import com.example.model.StoryEngineData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AiChatMessage(
    val sender: String,
    val text: String,
    val isPlayer: Boolean,
    val badge: String? = null
)

data class ActiveGameState(
    val saveId: String = "",
    val roomId: String? = null,
    val adventureId: String = "discovery_free",
    val adventureTitle: String = "Découverte",
    val character: CharacterArchetype = AdventureCatalog.heirs.first(),
    val chapters: List<StoryChapter> = emptyList(),
    val currentChapterIndex: Int = 0,
    val countdownSeconds: Int = 180,
    val score: Int = 0,
    val virtualWealthM: Int = 20,
    val reputation: Int = 50,
    val discoveredClues: List<String> = emptyList(),
    val completedMissions: List<String> = emptyList(),
    val unlockedVaults: List<String> = emptyList(),
    val allies: List<String> = emptyList(),
    val decisionsLog: List<String> = emptyList(),
    val lastConsequence: String? = null,
    val ending: StoryEnding? = null,
    val aiChats: Map<String, List<AiChatMessage>> = emptyMap(),
    val isAiThinking: Boolean = false,
    val aiError: String? = null,
    val vaultFeedback: String? = null,
    val soloVoteWinner: String? = null
)

class GameViewModel(
    private val repository: HeritageRepository,
    private val aiService: AiHeirService,
    private val currentUserId: String
) : ViewModel() {

    private val _state = MutableStateFlow<ActiveGameState?>(null)
    val state: StateFlow<ActiveGameState?> = _state.asStateFlow()

    private var timerJob: Job? = null

    fun startNewGame(
        adventureId: String,
        adventureTitle: String,
        character: CharacterArchetype,
        roomId: String? = null
    ) {
        val seed = (System.currentTimeMillis() % 2).toInt()
        val chapters = StoryEngineData.chaptersFor(adventureId, seed)
        val initialState = ActiveGameState(
            roomId = roomId,
            adventureId = adventureId,
            adventureTitle = adventureTitle,
            character = character,
            chapters = chapters,
            currentChapterIndex = 0,
            countdownSeconds = chapters.firstOrNull()?.countdownSeconds ?: 180,
            score = 50,
            virtualWealthM = character.startingWealthM,
            reputation = 55
        )
        _state.value = initialState
        startChapterTimer()
        if (roomId == null) {
            persistSoloSave(initialState, "IN_PROGRESS", null)
        }
    }

    fun resumeSave(save: SoloSave) {
        val character = AdventureCatalog.heirs.firstOrNull { it.id == save.characterId }
            ?: AdventureCatalog.heirs.first()
        val chapters = StoryEngineData.chaptersFor(save.adventureId, 0)
        val idx = (save.currentChapter.toInt() - 1).coerceIn(0, (chapters.size - 1).coerceAtLeast(0))
        val resumed = ActiveGameState(
            saveId = save.id,
            adventureId = save.adventureId,
            adventureTitle = save.adventureTitle,
            character = character,
            chapters = chapters,
            currentChapterIndex = idx,
            countdownSeconds = chapters.getOrNull(idx)?.countdownSeconds ?: 180,
            score = save.score.toInt(),
            virtualWealthM = save.virtualWealthM.toInt(),
            reputation = save.reputation.toInt(),
            discoveredClues = save.discoveredClues,
            completedMissions = save.completedMissions,
            unlockedVaults = save.unlockedVaults,
            allies = save.allies,
            decisionsLog = save.decisionsLog
        )
        _state.value = resumed
        startChapterTimer()
    }

    private fun startChapterTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val current = _state.value ?: break
                if (current.ending != null) break
                if (current.countdownSeconds > 0) {
                    _state.update { it?.copy(countdownSeconds = (it.countdownSeconds - 1).coerceAtLeast(0)) }
                }
            }
        }
    }

    fun makeChoice(choice: StoryChoice, language: AppLanguage) {
        val current = _state.value ?: return
        val newScore = (current.score + choice.scoreDelta).coerceAtLeast(0)
        val newWealth = (current.virtualWealthM + choice.wealthDeltaM).coerceIn(0, 1000)
        val newRep = (current.reputation + choice.reputationDelta).coerceIn(0, 100)
        val newClues = (current.discoveredClues + listOfNotNull(choice.unlockedClueId)).distinct()
        val newMissions = (current.completedMissions + listOfNotNull(choice.completedMissionId)).distinct()
        val newAllies = (current.allies + listOfNotNull(choice.allyName)).distinct()
        val consequence = if (language == AppLanguage.EN) choice.consequenceEn else choice.consequenceFr
        val newLog = current.decisionsLog + choice.id

        val isLast = current.currentChapterIndex >= current.chapters.lastIndex
        if (isLast) {
            val ending = StoryEngineData.resolveEnding(newScore, newWealth, newRep, newClues.size)
            val finishedState = current.copy(
                score = newScore,
                virtualWealthM = newWealth,
                reputation = newRep,
                discoveredClues = newClues,
                completedMissions = newMissions,
                allies = newAllies,
                decisionsLog = newLog,
                lastConsequence = consequence,
                ending = ending
            )
            _state.value = finishedState
            timerJob?.cancel()
            if (current.roomId == null) {
                persistSoloSave(finishedState, "COMPLETED", ending.id)
            } else {
                syncMultiplayerScore(current.roomId, newScore, newWealth, newRep)
            }
        } else {
            val nextIdx = current.currentChapterIndex + 1
            val nextChapter = current.chapters[nextIdx]
            val nextState = current.copy(
                currentChapterIndex = nextIdx,
                countdownSeconds = nextChapter.countdownSeconds,
                score = newScore,
                virtualWealthM = newWealth,
                reputation = newRep,
                discoveredClues = newClues,
                completedMissions = newMissions,
                allies = newAllies,
                decisionsLog = newLog,
                lastConsequence = consequence,
                vaultFeedback = null
            )
            _state.value = nextState
            if (current.roomId == null) {
                persistSoloSave(nextState, "IN_PROGRESS", null)
            } else {
                syncMultiplayerScore(current.roomId, newScore, newWealth, newRep)
            }
        }
    }

    fun attemptVaultUnlock(code: String) {
        val current = _state.value ?: return
        val chapter = current.chapters.getOrNull(current.currentChapterIndex) ?: return
        val puzzle = chapter.puzzle ?: return
        if (current.unlockedVaults.contains(puzzle.id)) return

        if (puzzle.validCodes.contains(code.trim())) {
            val newWealth = (current.virtualWealthM + puzzle.wealthBonusM).coerceIn(0, 1000)
            val newScore = current.score + puzzle.scoreBonus
            val updated = current.copy(
                score = newScore,
                virtualWealthM = newWealth,
                discoveredClues = (current.discoveredClues + puzzle.rewardClueId).distinct(),
                unlockedVaults = (current.unlockedVaults + puzzle.id).distinct(),
                completedMissions = (current.completedMissions + "m_vault").distinct(),
                vaultFeedback = "Coffre déverrouillé ! +${puzzle.wealthBonusM}M$ & +${puzzle.scoreBonus} pts."
            )
            _state.value = updated
            if (current.roomId == null) persistSoloSave(updated, "IN_PROGRESS", null)
            else syncMultiplayerScore(current.roomId, newScore, newWealth, updated.reputation)
        } else {
            _state.update { it?.copy(vaultFeedback = "Code refusé par la serrure biométrique.") }
        }
    }

    fun sendAiNegotiation(rival: CharacterArchetype, message: String, language: AppLanguage) {
        val current = _state.value ?: return
        val clean = message.trim()
        if (clean.isBlank()) return

        val existingChat = current.aiChats[rival.id].orEmpty()
        val withUserMsg = existingChat + AiChatMessage(
            sender = current.character.name,
            text = clean,
            isPlayer = true
        )
        _state.update {
            it?.copy(
                aiChats = it.aiChats + (rival.id to withUserMsg),
                isAiThinking = true,
                aiError = null
            )
        }

        viewModelScope.launch {
            val res = aiService.negotiateWithHeir(
                rival = rival,
                playerCharacterName = current.character.name,
                chapterNumber = current.currentChapterIndex + 1,
                playerMessage = clean,
                playerReputation = current.reputation,
                playerWealthM = current.virtualWealthM,
                language = language
            )
            res.onSuccess { outcome ->
                val badge = buildString {
                    if (outcome.allianceAccepted) append("Alliance scellée • ")
                    if (outcome.trustDelta != 0) append("Rép ${if (outcome.trustDelta > 0) "+" else ""}${outcome.trustDelta} • ")
                    if (outcome.wealthOfferM != 0) append("${if (outcome.wealthOfferM > 0) "+" else ""}${outcome.wealthOfferM}M$")
                }.trimEnd(' ', '•')

                val replyMsg = AiChatMessage(
                    sender = rival.name,
                    text = outcome.replyText + (outcome.clueHint?.let { "\n[Indice] $it" } ?: ""),
                    isPlayer = false,
                    badge = badge.takeIf { it.isNotBlank() }
                )

                _state.update { latest ->
                    if (latest == null) return@update null
                    val updatedChat = latest.aiChats[rival.id].orEmpty() + replyMsg
                    val updatedAllies = if (outcome.allianceAccepted) {
                        (latest.allies + rival.name).distinct()
                    } else latest.allies
                    val updatedMissions = if (outcome.allianceAccepted) {
                        (latest.completedMissions + "m_alliance").distinct()
                    } else latest.completedMissions
                    latest.copy(
                        aiChats = latest.aiChats + (rival.id to updatedChat),
                        reputation = (latest.reputation + outcome.trustDelta).coerceIn(0, 100),
                        virtualWealthM = (latest.virtualWealthM + outcome.wealthOfferM).coerceIn(0, 1000),
                        score = latest.score + if (outcome.allianceAccepted) 120 else 40,
                        allies = updatedAllies,
                        completedMissions = updatedMissions,
                        isAiThinking = false
                    )
                }
            }.onFailure { err ->
                _state.update {
                    it?.copy(
                        isAiThinking = false,
                        aiError = err.localizedMessage ?: "Échec de la négociation IA."
                    )
                }
            }
        }
    }

    fun castSoloCouncilVote(targetName: String) {
        _state.update { current ->
            current?.copy(
                soloVoteWinner = targetName,
                score = current.score + 100
            )
        }
    }

    fun syncRoomProgress(roomChapter: Int, isFinished: Boolean) {
        val current = _state.value ?: return
        if (current.roomId == null || current.ending != null) return
        if (isFinished) {
            val ending = StoryEngineData.resolveEnding(
                score = current.score,
                wealthM = current.virtualWealthM,
                reputation = current.reputation,
                cluesCount = current.discoveredClues.size
            )
            timerJob?.cancel()
            _state.value = current.copy(ending = ending)
            return
        }
        val targetIdx = (roomChapter - 1).coerceIn(0, current.chapters.lastIndex)
        if (targetIdx > current.currentChapterIndex) {
            val nextChapter = current.chapters[targetIdx]
            _state.value = current.copy(
                currentChapterIndex = targetIdx,
                countdownSeconds = nextChapter.countdownSeconds,
                vaultFeedback = null
            )
        }
    }

    fun clearGame() {
        timerJob?.cancel()
        _state.value = null
    }

    private fun persistSoloSave(state: ActiveGameState, status: String, endingId: String?) {
        viewModelScope.launch {
            val res = repository.upsertSoloSave(
                SoloSave(
                    id = state.saveId,
                    userId = currentUserId,
                    adventureId = state.adventureId,
                    adventureTitle = state.adventureTitle,
                    characterId = state.character.id,
                    characterName = state.character.name,
                    currentChapter = (state.currentChapterIndex + 1).toLong(),
                    score = state.score.toLong(),
                    virtualWealthM = state.virtualWealthM.toLong(),
                    reputation = state.reputation.toLong(),
                    discoveredClues = state.discoveredClues,
                    completedMissions = state.completedMissions,
                    unlockedVaults = state.unlockedVaults,
                    allies = state.allies,
                    decisionsLog = state.decisionsLog,
                    endingId = endingId,
                    status = status
                )
            )
            res.onSuccess { assignedId ->
                _state.update { it?.copy(saveId = assignedId) }
            }
        }
    }

    private fun syncMultiplayerScore(roomId: String, score: Int, wealthM: Int, reputation: Int) {
        viewModelScope.launch {
            repository.updateMyRoomSeat(
                roomId = roomId,
                score = score.toLong(),
                wealthM = wealthM.toLong(),
                reputation = reputation.toLong()
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
