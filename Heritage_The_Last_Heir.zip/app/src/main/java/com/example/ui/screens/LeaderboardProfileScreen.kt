package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.model.LeaderboardEntry
import com.example.model.UserProfile
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.GoldSurfaceCard
import com.example.ui.components.LuxuryPillTag
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.HairlineGold
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.UiState

@Composable
fun LeaderboardProfileScreen(
    language: AppLanguage,
    profileState: UiState<UserProfile?>,
    leaderboardState: UiState<List<LeaderboardEntry>>,
    onSaveProfile: (alias: String, referredBy: String?) -> Unit
) {
    val strings = AppStrings.get(language)
    val profile = (profileState as? UiState.Success)?.data
    val entries = (leaderboardState as? UiState.Success)?.data.orEmpty()

    var aliasInput by remember { mutableStateOf("") }
    var referredByInput by remember { mutableStateOf("") }

    LaunchedEffect(profile?.alias) {
        if (profile != null && aliasInput.isBlank()) {
            aliasInput = profile.alias
            referredByInput = profile.referredBy.orEmpty()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Editor
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.profileTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = aliasInput,
                    onValueChange = { aliasInput = it },
                    label = { Text("Nom d'héritier (Alias)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite
                    )
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = referredByInput,
                    onValueChange = { referredByInput = it.uppercase() },
                    label = { Text("Code parrain (optionnel)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MetallicGold,
                        unfocusedBorderColor = HairlineGold,
                        focusedTextColor = IvoryWhite,
                        unfocusedTextColor = IvoryWhite
                    )
                )
                Spacer(Modifier.height(12.dp))
                GoldPrimaryButton(
                    text = "Enregistrer le profil",
                    icon = Icons.Default.Save,
                    enabled = aliasInput.trim().length >= 2,
                    onClick = { onSaveProfile(aliasInput, referredByInput.takeIf { it.isNotBlank() }) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Trophies
            GoldSurfaceCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = MetallicGold)
                    Spacer(Modifier.width(8.dp))
                    Text("Trophées & Distinctions", style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                }
                Spacer(Modifier.height(8.dp))
                val trophies = profile?.trophies.orEmpty()
                if (trophies.isEmpty()) {
                    Text("Terminez une aventure pour débloquer votre premier trophée de succession.", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        trophies.forEach { trophy ->
                            LuxuryPillTag(text = trophy)
                        }
                    }
                }
            }

            // Global Leaderboard
            GoldSurfaceCard {
                Text(strings.leaderboardTitle, style = MaterialTheme.typography.titleLarge, color = ChampagneGold)
                Spacer(Modifier.height(10.dp))
                if (entries.isEmpty()) {
                    Text("Chargement du classement...", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                } else {
                    entries.forEachIndexed { idx, entry ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MidnightCharcoal,
                            border = BorderStroke(1.dp, HairlineGold),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    LuxuryPillTag(text = "#${idx + 1}")
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(entry.alias, style = MaterialTheme.typography.titleMedium, color = IvoryWhite)
                                        Text("Rép ${entry.reputation} • ${entry.gamesWon} victoires", style = MaterialTheme.typography.bodyMedium, color = WarmParchment)
                                    }
                                }
                                Text("${entry.totalWealthM} M$", style = MaterialTheme.typography.titleMedium, color = ChampagneGold)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
