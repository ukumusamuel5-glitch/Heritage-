package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val alias: String = "",
    val email: String = "",
    val language: String = "FR",
    val reputation: Long = 50L,
    val totalWealthM: Long = 100L,
    val gamesPlayed: Long = 0L,
    val gamesWon: Long = 0L,
    val trophies: List<String> = emptyList(),
    val activePlan: String = "FREE",
    val referralCode: String = "",
    val referredBy: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class LeaderboardEntry(
    @DocumentId val id: String = "",
    val userId: String = "",
    val alias: String = "",
    val reputation: Long = 50L,
    val totalWealthM: Long = 0L,
    val gamesWon: Long = 0L,
    val trophiesCount: Long = 0L,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SoloSave(
    @DocumentId val id: String = "",
    val userId: String = "",
    val adventureId: String = "",
    val adventureTitle: String = "",
    val characterId: String = "",
    val characterName: String = "",
    val currentChapter: Long = 1L,
    val score: Long = 0L,
    val virtualWealthM: Long = 20L,
    val reputation: Long = 50L,
    val discoveredClues: List<String> = emptyList(),
    val completedMissions: List<String> = emptyList(),
    val unlockedVaults: List<String> = emptyList(),
    val allies: List<String> = emptyList(),
    val decisionsLog: List<String> = emptyList(),
    val endingId: String? = null,
    val status: String = "IN_PROGRESS",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class Adventure(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val synopsis: String = "",
    val tier: String = "FREE",
    val priceUsd: Double = 0.0,
    val durationMinutes: Long = 60L,
    val minPlayers: Long = 1L,
    val maxPlayers: Long = 20L,
    val published: Boolean = true,
    val playable: Boolean = false,
    val chaptersCount: Long = 10L,
    val coverKey: String = "mansion",
    val customChapters: List<String> = emptyList(),
    val createdByUid: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class GameRoom(
    @DocumentId val id: String = "",
    val roomCode: String = "",
    val hostUid: String = "",
    val hostName: String = "",
    val adventureId: String = "",
    val adventureTitle: String = "",
    val mode: String = "MULTI_CLASSIC",
    val status: String = "LOBBY",
    val currentChapter: Long = 1L,
    val maxPlayers: Long = 10L,
    val memberUids: List<String> = emptyList(),
    val eventOrgName: String? = null,
    val activeVotePrompt: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RoomPlayer(
    @DocumentId val id: String = "",
    val uid: String = "",
    val displayName: String = "",
    val characterId: String = "",
    val characterName: String = "",
    val roleTitle: String = "",
    val score: Long = 0L,
    val virtualWealthM: Long = 20L,
    val reputation: Long = 50L,
    val ready: Boolean = false,
    val connected: Boolean = true,
    @ServerTimestamp val joinedAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RoomSecret(
    @DocumentId val id: String = "",
    val uid: String = "",
    val secretObjective: String = "",
    val secretClue: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RoomMessage(
    @DocumentId val id: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val recipientUid: String? = null,
    val body: String = "",
    val visibleToUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class RoomVote(
    @DocumentId val id: String = "",
    val voterUid: String = "",
    val chapter: Long = 1L,
    val targetId: String = "",
    val targetName: String = "",
    val memberUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PromoCode(
    @DocumentId val id: String = "",
    val code: String = "",
    val discountPercent: Long = 10L,
    val active: Boolean = true,
    val usageCount: Long = 0L,
    val maxUses: Long = 100L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class PurchaseOrder(
    @DocumentId val id: String = "",
    val userId: String = "",
    val offerId: String = "",
    val title: String = "",
    val amountUsd: Double = 0.0,
    val paymentMethod: String = "",
    val promoCode: String? = null,
    val referenceNote: String? = null,
    val status: String = "PENDING_VERIFICATION",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SupportReport(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userEmail: String? = null,
    val category: String = "BUG",
    val subject: String = "",
    val message: String = "",
    val status: String = "OPEN",
    val adminReply: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class CommercialOffer(
    val id: String,
    val titleFr: String,
    val titleEn: String,
    val priceUsd: Double,
    val periodLabelFr: String,
    val periodLabelEn: String,
    val featuresFr: List<String>,
    val featuresEn: List<String>,
    val highlight: Boolean = false
)

data class CharacterArchetype(
    val id: String,
    val name: String,
    val titleFr: String,
    val titleEn: String,
    val backgroundFr: String,
    val backgroundEn: String,
    val startingWealthM: Int,
    val secretObjectiveFr: String,
    val secretObjectiveEn: String,
    val secretClueFr: String,
    val secretClueEn: String,
    val aiPersonaPrompt: String
)
