package com.example.model

import com.example.core.AppLanguage

object AdventureCatalog {

    val defaultAdventures: List<Adventure> = listOf(
        Adventure(
            id = "discovery_free",
            title = "Découverte : L'Antichambre",
            subtitle = "Mini-aventure gratuite (15 min) • Introduction au Manoir Vance",
            synopsis = "La tempête frappe le domaine de Saint-Valéry. En quinze minutes, déchiffrez la première enveloppe scellée du testament et démasquez l'intrus avant l'arrivée du notaire.",
            tier = "FREE",
            priceUsd = 0.0,
            durationMinutes = 15,
            minPlayers = 1,
            maxPlayers = 1,
            published = true,
            playable = true,
            chaptersCount = 3,
            coverKey = "testament"
        ),
        Adventure(
            id = "last_testament",
            title = "Le dernier testament",
            subtitle = "Saison 1 • L'Empire de 100 Millions $ • 10 Chapitres",
            synopsis = "Alexandre Vance, magnat de la finance, s'est effondré dans son bureau blindé. Avant de mourir, il a verrouillé son empire de 100M$ derrière une épreuve impitoyable entre six héritiers aux secrets inavouables.",
            tier = "SOLO_PREMIUM",
            priceUsd = 4.99,
            durationMinutes = 75,
            minPlayers = 1,
            maxPlayers = 20,
            published = true,
            playable = true,
            chaptersCount = 10,
            coverKey = "mansion"
        ),
        Adventure(
            id = "missing_president",
            title = "Le président disparu",
            subtitle = "Crise diplomatique au sommet • Bientôt disponible",
            synopsis = "À 48 heures d'un traité historique, le chef d'État s'évapore d'un hôtel bunkerisé. Cabinet noir, services secrets et fuites médiatiques.",
            tier = "MULTI_CLASSIC",
            priceUsd = 9.99,
            durationMinutes = 80,
            minPlayers = 4,
            maxPlayers = 12,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "boardroom"
        ),
        Adventure(
            id = "wedding_secrets",
            title = "Le mariage des secrets",
            subtitle = "Huis clos sur la Côte d'Azur • Prochainement",
            synopsis = "Deux dynasties industrielles s'unissent dans une villa privée, mais la mariée détient un dossier capable de ruiner chaque invité.",
            tier = "MULTI_CLASSIC",
            priceUsd = 9.99,
            durationMinutes = 70,
            minPlayers = 4,
            maxPlayers = 16,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "mansion"
        ),
        Adventure(
            id = "heist_century",
            title = "Le vol du siècle",
            subtitle = "Coffre-fort de Zurich • Prochainement",
            synopsis = "Six spécialistes d'élite ont braqué la chambre forte souterraine. L'un d'entre eux a déjà trahi l'équipe pour empocher les diamants.",
            tier = "MULTI_PREMIUM",
            priceUsd = 15.0,
            durationMinutes = 85,
            minPlayers = 4,
            maxPlayers = 20,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "vault"
        ),
        Adventure(
            id = "billionaires_island",
            title = "L'île des milliardaires",
            subtitle = "Archipel privé sans réseau • Prochainement",
            synopsis = "Un sommet exclusif tourne au jeu de pouvoir lorsque le yacht principal disparaît en pleine nuit avec les serveurs financiers.",
            tier = "MULTI_PREMIUM",
            priceUsd = 15.0,
            durationMinutes = 90,
            minPlayers = 6,
            maxPlayers = 20,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "mansion"
        ),
        Adventure(
            id = "empire_kinshasa",
            title = "L'empire de Kinshasa",
            subtitle = "Concessions minières & haute finance • Prochainement",
            synopsis = "Au cœur d'un consortium stratégique de la capitale, héritiers et conseillers s'affrontent pour les titres de propriété disparus.",
            tier = "MULTI_PREMIUM",
            priceUsd = 15.0,
            durationMinutes = 85,
            minPlayers = 4,
            maxPlayers = 20,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "boardroom"
        ),
        Adventure(
            id = "secret_dubai",
            title = "Le secret de Dubaï",
            subtitle = "Penthouse au 112e étage • Prochainement",
            synopsis = "Un protocole crypté valant des dizaines de millions s'est volatilisé lors d'une vente aux enchères privée dans le golfe.",
            tier = "SOLO_PREMIUM",
            priceUsd = 4.99,
            durationMinutes = 75,
            minPlayers = 1,
            maxPlayers = 16,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "vault"
        ),
        Adventure(
            id = "vanished_prince",
            title = "La disparition du prince",
            subtitle = "Palais d'hiver & succession • Prochainement",
            synopsis = "L'héritier légitime n'a pas paru au bal d'investiture. Déjouez les intrigues de cour et retrouvez la chevalière royale.",
            tier = "SOLO_PREMIUM",
            priceUsd = 4.99,
            durationMinutes = 70,
            minPlayers = 1,
            maxPlayers = 12,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "testament"
        ),
        Adventure(
            id = "secret_society",
            title = "La société secrète",
            subtitle = "Loge du Cercle d'Or • Prochainement",
            synopsis = "Sept membres masqués se réunissent tous les dix ans pour désigner le Grand Gardien. Cette année, l'un d'eux est un agent double.",
            tier = "ENTERPRISE",
            priceUsd = 80.0,
            durationMinutes = 90,
            minPlayers = 6,
            maxPlayers = 20,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "boardroom"
        ),
        Adventure(
            id = "last_voyage",
            title = "Le dernier voyage",
            subtitle = "Express transcontinental de nuit • Prochainement",
            synopsis = "À bord d'un train de luxe isolé par la neige, un courrier diplomatique scellé change de mains avant le terminus.",
            tier = "MULTI_CLASSIC",
            priceUsd = 9.99,
            durationMinutes = 75,
            minPlayers = 4,
            maxPlayers = 16,
            published = true,
            playable = false,
            chaptersCount = 10,
            coverKey = "testament"
        )
    )

    val heirs: List<CharacterArchetype> = listOf(
        CharacterArchetype(
            id = "victoria",
            name = "Victoria Vance",
            titleFr = "Fille aînée & Directrice Stratégie",
            titleEn = "Eldest Daughter & Chief Strategist",
            backgroundFr = "Élevée pour diriger Vance Holdings, Victoria maîtrise les rouages juridiques de l'empire, mais dissimule un audit offshore explosif.",
            backgroundEn = "Groomed to run Vance Holdings, Victoria commands the legal machinery of the empire while hiding an explosive offshore audit.",
            startingWealthM = 28,
            secretObjectiveFr = "Empêcher Julian de révéler votre transfert de 12M$ vers Genève avant le Chapitre 8.",
            secretObjectiveEn = "Prevent Julian from exposing your $12M Geneva transfer before Chapter 8.",
            secretClueFr = "Le code d'accès de la bibliothèque commence par l'année de fondation : 19.",
            secretClueEn = "The library vault access code begins with the founding year prefix: 19.",
            aiPersonaPrompt = "Tu incarnes Victoria Vance, héritière hautaine, calculatrice et élégante. Tu cherches à dominer le conseil tout en cachant ton transfert offshore de 12M$. Tu parles avec assurance et méfiance."
        ),
        CharacterArchetype(
            id = "julian",
            name = "Julian Mercer",
            titleFr = "Directeur Financier & Fils adoptif",
            titleEn = "Chief Financial Officer & Adopted Son",
            backgroundFr = "Brillant architecte financier, Julian connaît chaque flux de trésorerie du groupe, mais garde une dette personnelle colossale.",
            backgroundEn = "A brilliant financial architect who knows every cashflow of the group, yet conceals a massive personal debt.",
            startingWealthM = 24,
            secretObjectiveFr = "Sécuriser les obligations au porteur du coffre B sans perdre votre siège au conseil.",
            secretObjectiveEn = "Secure the bearer bonds inside Vault B without losing your board seat.",
            secretClueFr = "Le bilan comptable falsifié porte le timbre du 14 novembre.",
            secretClueEn = "The falsified ledger carries the November 14th stamp.",
            aiPersonaPrompt = "Tu incarnes Julian Mercer, CFO pragmatique, charmeur mais acculé par une dette secrète. Tu proposes des pactes financiers subtils et surveilles les chiffres de chacun."
        ),
        CharacterArchetype(
            id = "elena",
            name = "Dr. Éléna Rostova",
            titleFr = "Médecin personnel & Confidente",
            titleEn = "Personal Physician & Confidante",
            backgroundFr = "Seule présente lors des dernières heures du milliardaire, Éléna possède des dossiers médicaux qui bouleversent la chronologie officielle.",
            backgroundEn = "The only person beside the billionaire in his final hours, Elena holds medical records that shatter the official timeline.",
            startingWealthM = 18,
            secretObjectiveFr = "Protéger le codicille manuscrit que vous avez caché dans l'étui médical.",
            secretObjectiveEn = "Protect the handwritten codicil hidden inside your medical case.",
            secretClueFr = "Le testament a été modifié après 22h15, malgré les déclarations du notaire.",
            secretClueEn = "The will was altered after 10:15 PM, contradicting the notary's statement.",
            aiPersonaPrompt = "Tu incarnes Dr. Éléna Rostova, médecin calme, observatrice et énigmatique. Tu distilles des indices médicaux uniquement contre des garanties de protection."
        ),
        CharacterArchetype(
            id = "kevin",
            name = "Maître Kévin Thorne",
            titleFr = "Notaire & Exécuteur testamentaire",
            titleEn = "Notary & Estate Executor",
            backgroundFr = "Gardien officiel du testament, Kévin arbitre les règles de la succession mais négocie secrètement avec le plus offrant.",
            backgroundEn = "Official guardian of the will, Kevin enforces the succession rules while quietly bargaining with the highest bidder.",
            startingWealthM = 20,
            secretObjectiveFr = "Obtenir au moins deux alliés pour valider l'ouverture anticipée de la clause 7.",
            secretObjectiveEn = "Secure at least two allies to validate the early unlocking of Clause 7.",
            secretClueFr = "La combinaison finale du coffre principal comporte quatre chiffres pairs croissants : 2468 ou 4826.",
            secretClueEn = "The main vault's combination uses four digits derived from the patriarch's birth year and clause index: 4826.",
            aiPersonaPrompt = "Tu incarnes Maître Kévin Thorne, avocat-notaire raffiné, maître du double jeu juridique. Tu monnaies tes informations procédurales."
        ),
        CharacterArchetype(
            id = "amara",
            name = "Amara Diallo",
            titleFr = "Directrice des Opérations Internationales",
            titleEn = "VP of International Operations",
            backgroundFr = "Stratège redoutée qui a bâti les filiales africaines et européennes de l'empire, Amara détient les preuves d'un sabotage industriel.",
            backgroundEn = "Feared strategist behind the empire's African and European divisions, Amara holds proof of corporate sabotage.",
            startingWealthM = 22,
            secretObjectiveFr = "Révéler l'auteur du sabotage logistique lors de la confrontation du Chapitre 9.",
            secretObjectiveEn = "Expose the mastermind behind the logistics sabotage during Chapter 9's confrontation.",
            secretClueFr = "Un vol privé a décollé vers Zurich à minuit dix avec trois caisses scellées.",
            secretClueEn = "A private jet departed for Zurich at 12:10 AM carrying three sealed crates.",
            aiPersonaPrompt = "Tu incarnes Amara Diallo, dirigeante vive, loyale envers la justice interne mais impitoyable en négociation."
        ),
        CharacterArchetype(
            id = "lucas",
            name = "Lucas Vance",
            titleFr = "Neveu rebelle & Architecte cybersécurité",
            titleEn = "Rebellious Nephew & Cybersecurity Architect",
            backgroundFr = "Longtemps écarté par la famille, Lucas a conçu la sécurité numérique du coffre-fort du manoir.",
            backgroundEn = "Long estranged from the family, Lucas engineered the digital security guarding the estate vault.",
            startingWealthM = 16,
            secretObjectiveFr = "Décrypter le serveur fantôme du manoir avant la désignation finale.",
            secretObjectiveEn = "Decrypt the manor's ghost server before the final heir designation.",
            secretClueFr = "Les caméras du couloir Est ont été coupées manuellement depuis le terminal du sous-sol.",
            secretClueEn = "The East Wing cameras were manually disabled from the basement security terminal.",
            aiPersonaPrompt = "Tu incarnes Lucas Vance, génie sarcastique de la cybersécurité qui méprise l'hypocrisie familiale mais respecte les esprits brillants."
        )
    )

    val commercialOffers: List<CommercialOffer> = listOf(
        CommercialOffer(
            id = "discovery",
            titleFr = "Découverte",
            titleEn = "Discovery",
            priceUsd = 0.0,
            periodLabelFr = "Gratuit • 15 min",
            periodLabelEn = "Free • 15 min",
            featuresFr = listOf(
                "Mini-aventure complète de 15 minutes",
                "Initiation au Manoir Vance & premier coffre",
                "Sauvegarde automatique dans le cloud"
            ),
            featuresEn = listOf(
                "Complete 15-minute mini-adventure",
                "Vance Manor intro & first vault puzzle",
                "Cloud auto-save progression"
            )
        ),
        CommercialOffer(
            id = "solo_premium",
            titleFr = "Solo Premium",
            titleEn = "Solo Premium",
            priceUsd = 4.99,
            periodLabelFr = "4,99 $ • Aventure complète",
            periodLabelEn = "$4.99 • Full adventure",
            featuresFr = listOf(
                "Accès complet aux 10 chapitres de Le dernier testament",
                "Négociations IA dynamiques avec les 5 rivaux",
                "Fins multiples & distribution variable des secrets"
            ),
            featuresEn = listOf(
                "Full access to all 10 chapters of The Last Will",
                "Live AI negotiations with 5 rival heirs",
                "Multiple endings & randomized secret distribution"
            )
        ),
        CommercialOffer(
            id = "multi_classic",
            titleFr = "Multijoueur Classique",
            titleEn = "Classic Multiplayer",
            priceUsd = 9.99,
            periodLabelFr = "9,99 $ • Jusqu'à 10 joueurs",
            periodLabelEn = "$9.99 • Up to 10 players",
            featuresFr = listOf(
                "L'organisateur paie, les invités rejoignent gratuitement",
                "Salon privé avec QR code & lien d'invitation",
                "Messagerie publique/privée & votes secrets"
            ),
            featuresEn = listOf(
                "Host pays once; all guests join free",
                "Private lobby with QR code & invite link",
                "Public/private chat & confidential voting"
            )
        ),
        CommercialOffer(
            id = "multi_premium",
            titleFr = "Multijoueur Premium",
            titleEn = "Premium Multiplayer",
            priceUsd = 15.0,
            periodLabelFr = "15,00 $ • Jusqu'à 20 joueurs",
            periodLabelEn = "$15.00 • Up to 20 players",
            featuresFr = listOf(
                "Salons haute capacité (4 à 20 participants)",
                "Personnalisation des prénoms (Mode Événementiel)",
                "Reconnexion instantanée & rôles secrets cryptés"
            ),
            featuresEn = listOf(
                "High-capacity rooms (4 to 20 participants)",
                "Custom participant names (Event Mode)",
                "Instant rejoin & encrypted secret roles"
            )
        ),
        CommercialOffer(
            id = "enterprise",
            titleFr = "Entreprise & Team Building",
            titleEn = "Enterprise Team Building",
            priceUsd = 80.0,
            periodLabelFr = "80,00 $ • Session dédiée",
            periodLabelEn = "$80.00 • Dedicated session",
            featuresFr = listOf(
                "Session événementielle sur mesure (mariage, séminaire)",
                "Rapport collectif des résultats & leadership",
                "Support prioritaire & personnalisation avancée"
            ),
            featuresEn = listOf(
                "Tailored corporate or private event session",
                "Collective results & leadership debrief report",
                "Priority concierge support & advanced customization"
            )
        ),
        CommercialOffer(
            id = "vip_monthly",
            titleFr = "Abonnement VIP",
            titleEn = "VIP Membership",
            priceUsd = 9.99,
            periodLabelFr = "9,99 $ / mois",
            periodLabelEn = "$9.99 / month",
            featuresFr = listOf(
                "Accès illimité au catalogue Solo Premium",
                "Nouvelles aventures dès leur publication",
                "Blason VIP exclusif & trophées de prestige"
            ),
            featuresEn = listOf(
                "Unlimited access to Solo Premium catalogue",
                "Early access to every newly published scenario",
                "Exclusive VIP crest & prestige trophies"
            ),
            highlight = true
        )
    )

    fun isAdminEmail(email: String?): Boolean =
        email.equals("ryanukumu2@gmail.com", ignoreCase = true)

    fun localizedTitle(adventure: Adventure, lang: AppLanguage): String =
        if (lang == AppLanguage.EN && adventure.id == "last_testament") "The Last Will"
        else if (lang == AppLanguage.EN && adventure.id == "discovery_free") "Discovery: The Antechamber"
        else adventure.title
}
