package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val HeritageDarkColorScheme = darkColorScheme(
    primary = MetallicGold,
    onPrimary = ObsidianBlack,
    primaryContainer = BurnishedBronze,
    onPrimaryContainer = IvoryWhite,
    secondary = CrimsonVelvet,
    onSecondary = IvoryWhite,
    secondaryContainer = DeepBurgundy,
    onSecondaryContainer = ChampagneGold,
    tertiary = ChampagneGold,
    onTertiary = ObsidianBlack,
    background = ObsidianBlack,
    onBackground = IvoryWhite,
    surface = MidnightCharcoal,
    onSurface = IvoryWhite,
    surfaceVariant = VelvetSurface,
    onSurfaceVariant = WarmParchment,
    surfaceContainerLow = MidnightCharcoal,
    surfaceContainer = VelvetSurface,
    surfaceContainerHigh = ElevatedSlate,
    outline = HairlineGold,
    outlineVariant = ColorTokens.OutlineMuted,
    error = AlertCrimson,
    onError = IvoryWhite
)

private object ColorTokens {
    val OutlineMuted = androidx.compose.ui.graphics.Color(0xFF332F3D)
}

val HeritageShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun HeritageTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HeritageDarkColorScheme,
        typography = HeritageTypography,
        shapes = HeritageShapes,
        content = content
    )
}
