package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Castle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.core.AppLanguage
import com.example.core.AppStrings
import com.example.core.PreferencesManager
import com.example.core.SoundEffects
import com.example.core.configureAppCheck
import com.example.data.AiHeirService
import com.example.data.HeritageRepository
import com.example.model.AdventureCatalog
import com.example.ui.components.LuxuryBackdrop
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CatalogueScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GamePlayScreen
import com.example.ui.screens.LandingAuthScreen
import com.example.ui.screens.LeaderboardProfileScreen
import com.example.ui.screens.LobbyHubScreen
import com.example.ui.screens.MultiplayerRoomScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SettingsSupportScreen
import com.example.ui.screens.StoreScreen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DeepBurgundy
import com.example.ui.theme.HeritageTheme
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MidnightCharcoal
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.WarmParchment
import com.example.viewmodel.GameViewModel
import com.example.viewmodel.HeritageViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val ROUTE_DASHBOARD = "dashboard"
const val ROUTE_CATALOG = "catalog"
const val ROUTE_LOBBIES = "lobbies"
const val ROUTE_STORE = "store"
const val ROUTE_LEADERBOARD = "leaderboard"
const val ROUTE_SETTINGS = "settings"
const val ROUTE_ROOM = "room"
const val ROUTE_ADMIN = "admin"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mandatory: configure Firebase App Check with launch intent before UI or ViewModels
        configureAppCheck(this, intent)
        enableEdgeToEdge()

        setContent {
            HeritageTheme {
                Surface(color = ObsidianBlack, modifier = Modifier.fillMaxSize()) {
                    AppRoot()
                }
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember(context) { PreferencesManager(context.applicationContext) }
    val preAuthLang by prefs.languageFlow.collectAsStateWithLifecycle(initialValue = AppLanguage.FR)
    val scope = rememberCoroutineScope()

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose { Firebase.auth.removeAuthStateListener(listener) }
    }

    val user = currentUser
    if (user == null) {
        LandingAuthScreen(
            language = preAuthLang,
            onLanguageSelected = { lang ->
                scope.launch { prefs.setLanguage(lang) }
            },
            onAuthSuccess = {
                currentUser = Firebase.auth.currentUser
            }
        )
    } else {
        key(user.uid) {
            AuthenticatedHeritageShell(user = user)
        }
    }
}

private data class NavTab(
    val route: String,
    val label: String,
    val icon: ImageVector
)

@Composable
private fun AuthenticatedHeritageShell(user: FirebaseUser) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val soundEffects = remember(context) { SoundEffects(context) }
    DisposableEffect(Unit) {
        onDispose { soundEffects.release() }
    }

    val heritageVm: HeritageViewModel = viewModel(
        key = "heritage_${user.uid}",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                val repo = HeritageRepository(db)
                HeritageViewModel(
                    repository = repo,
                    prefs = PreferencesManager(app),
                    currentUserId = user.uid,
                    userEmail = user.email,
                    isEmailVerified = user.isEmailVerified
                )
            }
        }
    )

    val gameVm: GameViewModel = viewModel(
        key = "game_${user.uid}",
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val dbId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(dbId)
                GameViewModel(
                    repository = HeritageRepository(db),
                    aiService = AiHeirService(),
                    currentUserId = user.uid
                )
            }
        }
    )

    LaunchedEffect(user.uid) {
        heritageVm.bootstrapUser(user)
    }

    val language by heritageVm.language.collectAsStateWithLifecycle()
    val audioEnabled by heritageVm.audioEnabled.collectAsStateWithLifecycle()
    val voiceEnabled by heritageVm.voiceEnabled.collectAsStateWithLifecycle()
    val profileState by heritageVm.userProfile.collectAsStateWithLifecycle()
    val savesState by heritageVm.soloSaves.collectAsStateWithLifecycle()
    val adventures by heritageVm.adventures.collectAsStateWithLifecycle()
    val leaderboardState by heritageVm.leaderboard.collectAsStateWithLifecycle()
    val myRoomsState by heritageVm.myRooms.collectAsStateWithLifecycle()
    val myPurchasesState by heritageVm.myPurchases.collectAsStateWithLifecycle()
    val mySupportState by heritageVm.mySupportReports.collectAsStateWithLifecycle()
    val validatedPromo by heritageVm.validatedPromo.collectAsStateWithLifecycle()
    val feedback by heritageVm.feedbackMessage.collectAsStateWithLifecycle()

    val activeRoom by heritageVm.activeRoom.collectAsStateWithLifecycle()
    val activePlayers by heritageVm.activeRoomPlayers.collectAsStateWithLifecycle()
    val activeSecret by heritageVm.activeRoomSecret.collectAsStateWithLifecycle()
    val activeMessages by heritageVm.activeRoomMessages.collectAsStateWithLifecycle()
    val activeVotes by heritageVm.activeRoomVotes.collectAsStateWithLifecycle()

    val adminUsers by heritageVm.adminUsers.collectAsStateWithLifecycle()
    val adminPurchases by heritageVm.adminPurchases.collectAsStateWithLifecycle()
    val adminReports by heritageVm.adminReports.collectAsStateWithLifecycle()
    val adminPromos by heritageVm.adminPromoCodes.collectAsStateWithLifecycle()

    val gameState by gameVm.state.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(feedback) {
        val msg = feedback
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            heritageVm.clearFeedback()
        }
    }

    val strings = AppStrings.get(language)
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val navTabs = listOf(
        NavTab(ROUTE_DASHBOARD, strings.navHome, Icons.Default.Castle),
        NavTab(ROUTE_CATALOG, strings.navCatalog, Icons.Default.AutoStories),
        NavTab(ROUTE_LOBBIES, strings.navRooms, Icons.Default.Groups),
        NavTab(ROUTE_STORE, strings.navStore, Icons.Default.Storefront),
        NavTab(ROUTE_LEADERBOARD, strings.navMore, Icons.Default.EmojiEvents),
        NavTab(ROUTE_SETTINGS, "Plus", Icons.Default.Settings)
    )

    // Full-screen Gameplay or Results overlay when an active game session is running
    val activeGame = gameState
    if (activeGame != null) {
        LaunchedEffect(activeGame.roomId, activeRoom?.currentChapter, activeRoom?.status) {
            val room = activeRoom
            if (activeGame.roomId != null && room != null && room.id == activeGame.roomId) {
                gameVm.syncRoomProgress(
                    roomChapter = room.currentChapter.toInt(),
                    isFinished = room.status == "FINISHED"
                )
            }
        }
        LuxuryBackdrop {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                if (activeGame.ending != null) {
                    ResultsScreen(
                        language = language,
                        gameState = activeGame,
                        onReturnHome = { gameVm.clearGame() }
                    )
                } else {
                    GamePlayScreen(
                        language = language,
                        gameState = activeGame,
                        currentUserId = user.uid,
                        soundEffects = soundEffects,
                        audioEnabled = audioEnabled,
                        voiceEnabled = voiceEnabled,
                        activeRoom = activeRoom.takeIf { activeGame.roomId != null },
                        roomPlayers = activePlayers,
                        roomSecret = activeSecret,
                        roomMessages = activeMessages,
                        roomVotes = activeVotes,
                        onMakeChoice = { choice -> gameVm.makeChoice(choice, language) },
                        onUnlockVault = { code -> gameVm.attemptVaultUnlock(code) },
                        onSendAiNegotiation = { rival, text -> gameVm.sendAiNegotiation(rival, text, language) },
                        onSendRoomMessage = { body, targetUid ->
                            activeGame.roomId?.let { rid -> heritageVm.sendRoomMessage(rid, body, targetUid) }
                        },
                        onCastSoloVote = { targetName -> gameVm.castSoloCouncilVote(targetName) },
                        onCastRoomVote = { ch, targetUid, targetName ->
                            activeGame.roomId?.let { rid -> heritageVm.castRoomVote(rid, ch, targetUid, targetName) }
                        },
                        onHostAdvanceChapter = { nextCh, finished ->
                            activeGame.roomId?.let { rid -> heritageVm.advanceMultiplayerChapter(rid, nextCh, finished) }
                        },
                        onExitGame = {
                            soundEffects.stopSpeech()
                            gameVm.clearGame()
                        }
                    )
                }
            }
        }
        return
    }

    val showBottomChrome = currentRoute in navTabs.map { it.route }

    LuxuryBackdrop {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    if (!useRail && showBottomChrome) {
                        NavigationBar(
                            containerColor = MidnightCharcoal,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            navTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(ROUTE_DASHBOARD) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = ObsidianBlack,
                                        selectedTextColor = ChampagneGold,
                                        indicatorColor = MetallicGold,
                                        unselectedIconColor = WarmParchment,
                                        unselectedTextColor = WarmParchment
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail && showBottomChrome) {
                        NavigationRail(
                            containerColor = MidnightCharcoal,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            navTabs.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = {
                                        navController.navigate(tab.route) {
                                            popUpTo(ROUTE_DASHBOARD) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    },
                                    icon = { Icon(tab.icon, contentDescription = tab.label) },
                                    label = { Text(tab.label, maxLines = 1) },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = ObsidianBlack,
                                        selectedTextColor = ChampagneGold,
                                        indicatorColor = MetallicGold,
                                        unselectedIconColor = WarmParchment,
                                        unselectedTextColor = WarmParchment
                                    )
                                )
                            }
                        }
                    }

                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_DASHBOARD,
                        modifier = Modifier.weight(1f)
                    ) {
                        composable(ROUTE_DASHBOARD) {
                            DashboardScreen(
                                language = language,
                                profileState = profileState,
                                savesState = savesState,
                                roomsState = myRoomsState,
                                isAdmin = heritageVm.isAdmin,
                                onLaunchSolo = { advId, advTitle, character ->
                                    gameVm.startNewGame(advId, advTitle, character)
                                },
                                onResumeSave = { save -> gameVm.resumeSave(save) },
                                onOpenRooms = { navController.navigate(ROUTE_LOBBIES) },
                                onOpenRoom = { roomId ->
                                    heritageVm.selectRoom(roomId)
                                    navController.navigate(ROUTE_ROOM)
                                },
                                onOpenStore = { navController.navigate(ROUTE_STORE) },
                                onOpenAdmin = { navController.navigate(ROUTE_ADMIN) }
                            )
                        }

                        composable(ROUTE_CATALOG) {
                            CatalogueScreen(
                                language = language,
                                adventures = adventures,
                                onLaunchSolo = { advId, advTitle, character ->
                                    gameVm.startNewGame(advId, advTitle, character)
                                },
                                onCreateMultiplayerFor = { adv ->
                                    heritageVm.createRoom(
                                        adventureId = adv.id,
                                        adventureTitle = adv.title,
                                        mode = "MULTI_CLASSIC",
                                        maxPlayers = adv.maxPlayers.toInt().coerceIn(4, 20),
                                        eventOrgName = null
                                    ) {
                                        navController.navigate(ROUTE_ROOM)
                                    }
                                }
                            )
                        }

                        composable(ROUTE_LOBBIES) {
                            LobbyHubScreen(
                                language = language,
                                roomsState = myRoomsState,
                                onCreateRoom = { advId, advTitle, mode, maxP, org ->
                                    heritageVm.createRoom(advId, advTitle, mode, maxP, org) {
                                        navController.navigate(ROUTE_ROOM)
                                    }
                                },
                                onJoinRoomByCode = { code ->
                                    heritageVm.joinRoomByCode(code) {
                                        navController.navigate(ROUTE_ROOM)
                                    }
                                },
                                onOpenRoom = { rid ->
                                    heritageVm.selectRoom(rid)
                                    navController.navigate(ROUTE_ROOM)
                                }
                            )
                        }

                        composable(ROUTE_ROOM) {
                            MultiplayerRoomScreen(
                                language = language,
                                currentUserId = user.uid,
                                room = activeRoom,
                                players = activePlayers,
                                mySecret = activeSecret,
                                onBack = { navController.popBackStack() },
                                onSelectCharacter = { cid, cname, rtitle ->
                                    activeRoom?.id?.let { rid ->
                                        heritageVm.selectCharacterInRoom(rid, cid, cname, rtitle)
                                    }
                                },
                                onToggleReady = { ready ->
                                    activeRoom?.id?.let { rid -> heritageVm.toggleReadyInRoom(rid, ready) }
                                },
                                onAssignRandomRoles = {
                                    activeRoom?.id?.let { rid -> heritageVm.assignRandomRoles(rid) }
                                },
                                onStartMatch = {
                                    activeRoom?.id?.let { rid -> heritageVm.startMultiplayerMatch(rid) }
                                },
                                onEnterSyncedGame = { room, myPlayer ->
                                    val archetype = AdventureCatalog.heirs.firstOrNull { it.id == myPlayer?.characterId }
                                        ?: AdventureCatalog.heirs.first()
                                    gameVm.startNewGame(
                                        adventureId = room.adventureId,
                                        adventureTitle = room.adventureTitle,
                                        character = archetype,
                                        roomId = room.id
                                    )
                                }
                            )
                        }

                        composable(ROUTE_STORE) {
                            StoreScreen(
                                language = language,
                                profileState = profileState,
                                purchasesState = myPurchasesState,
                                validatedPromo = validatedPromo,
                                onValidatePromo = { code -> heritageVm.validatePromo(code) },
                                onSubmitOrder = { offerId, title, usd, method, note ->
                                    heritageVm.submitOrder(offerId, title, usd, method, note)
                                }
                            )
                        }

                        composable(ROUTE_LEADERBOARD) {
                            LeaderboardProfileScreen(
                                language = language,
                                profileState = profileState,
                                leaderboardState = leaderboardState,
                                onSaveProfile = { alias, ref -> heritageVm.updateProfile(alias, ref) }
                            )
                        }

                        composable(ROUTE_SETTINGS) {
                            SettingsSupportScreen(
                                language = language,
                                audioEnabled = audioEnabled,
                                voiceEnabled = voiceEnabled,
                                isAdmin = heritageVm.isAdmin,
                                supportState = mySupportState,
                                onSetLanguage = { lang -> heritageVm.setLanguage(lang) },
                                onSetAudio = { heritageVm.setAudioEnabled(it) },
                                onSetVoice = { heritageVm.setVoiceEnabled(it) },
                                onSubmitSupport = { cat, subj, msg -> heritageVm.submitSupport(cat, subj, msg) },
                                onOpenAdmin = { navController.navigate(ROUTE_ADMIN) },
                                onSignOut = {
                                    scope.launch {
                                        withContext(NonCancellable) {
                                            try {
                                                credentialManager.clearCredentialState(ClearCredentialStateRequest())
                                            } catch (e: Exception) {
                                                Log.w("Auth", "Clear credential state failed: ${e.message}")
                                            } finally {
                                                Firebase.auth.signOut()
                                            }
                                        }
                                    }
                                }
                            )
                        }

                        composable(ROUTE_ADMIN) {
                            if (heritageVm.isAdmin) {
                                AdminScreen(
                                    users = adminUsers,
                                    purchases = adminPurchases,
                                    reports = adminReports,
                                    promoCodes = adminPromos,
                                    onPublishAdventure = { t, st, syn, tier, price, ch ->
                                        heritageVm.adminPublishAdventure(t, st, syn, tier, price, ch)
                                    },
                                    onCreatePromo = { code, disc, maxU ->
                                        heritageVm.adminCreatePromo(code, disc, maxU)
                                    },
                                    onVerifyOrder = { order, approve ->
                                        heritageVm.adminVerifyOrder(order, approve)
                                    },
                                    onResolveReport = { id, reply ->
                                        heritageVm.adminResolveReport(id, reply)
                                    },
                                    onBack = { navController.popBackStack() }
                                )
                            } else {
                                Surface(color = DeepBurgundy) {
                                    Text("Accès réservé aux administrateurs.", color = IvoryWhite, modifier = Modifier.padding(24.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
