package com.example.core

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.IvoryWhite
import com.example.ui.theme.ObsidianBlack

/**
 * Renders a deterministic scannable-style visual invite matrix encoding the room code
 * with luxury ivory/gold-on-obsidian contrast.
 */
@Composable
fun RoomInviteMatrix(
    roomCode: String,
    size: Dp = 148.dp,
    modifier: Modifier = Modifier
) {
    val gridSize = 15
    val matrix = remember(roomCode) {
        val cells = Array(gridSize) { BooleanArray(gridSize) }
        fun markFinder(ox: Int, oy: Int) {
            for (y in 0..4) for (x in 0..4) {
                val border = x == 0 || x == 4 || y == 0 || y == 4
                val center = x == 2 && y == 2
                cells[oy + y][ox + x] = border || center
            }
        }
        markFinder(0, 0)
        markFinder(gridSize - 5, 0)
        markFinder(0, gridSize - 5)

        var seed = roomCode.hashCode().toLong() and 0xFFFFFFFFL
        for (y in 0 until gridSize) {
            for (x in 0 until gridSize) {
                val inFinder = (x < 6 && y < 6) || (x >= gridSize - 6 && y < 6) || (x < 6 && y >= gridSize - 6)
                if (!inFinder) {
                    seed = (seed * 1664525L + 1013904223L) and 0xFFFFFFFFL
                    cells[y][x] = ((seed shr 16) and 1L) == 1L
                }
            }
        }
        cells
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(IvoryWhite)
            .padding(10.dp)
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val cellSize = this.size.width / gridSize
            for (y in 0 until gridSize) {
                for (x in 0 until gridSize) {
                    if (matrix[y][x]) {
                        drawRect(
                            color = ObsidianBlack,
                            topLeft = Offset(x * cellSize, y * cellSize),
                            size = Size(cellSize * 0.94f, cellSize * 0.94f)
                        )
                    }
                }
            }
        }
    }
}
