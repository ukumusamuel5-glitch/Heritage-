package com.example.data

import android.util.Log
import com.example.core.AppLanguage
import com.example.model.CharacterArchetype
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class AiNegotiationOutcome(
    val heirName: String,
    val replyText: String,
    val trustDelta: Int,
    val allianceAccepted: Boolean,
    val clueHint: String?,
    val wealthOfferM: Int
)

class AiHeirService {

    private val negotiationSchema = Schema.obj(
        properties = mapOf(
            "reply" to Schema.string(description = "Dramatic in-character response from the rival heir (2-4 sentences)."),
            "trustDelta" to Schema.integer(description = "Change in reputation/trust from -10 to +15."),
            "allianceAccepted" to Schema.boolean(description = "Whether the rival agrees to a secret alliance or truce."),
            "clueHint" to Schema.string(description = "Optional subtle clue or counter-rumor revealed by the heir.", nullable = true),
            "wealthOfferM" to Schema.integer(description = "Virtual wealth in millions (USD million) offered or demanded (-10 to +15).")
        ),
        optionalProperties = listOf("clueHint")
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = negotiationSchema
            }
        )
    }

    suspend fun negotiateWithHeir(
        rival: CharacterArchetype,
        playerCharacterName: String,
        chapterNumber: Int,
        playerMessage: String,
        playerReputation: Int,
        playerWealthM: Int,
        language: AppLanguage
    ): Result<AiNegotiationOutcome> {
        val langInstruction = when (language) {
            AppLanguage.FR -> "Réponds en français littéraire, élégant et cinématographique."
            AppLanguage.EN -> "Respond in cinematic, sharp, aristocratic English."
            AppLanguage.ES -> "Responde en español elegante y cinematográfico."
            AppLanguage.PT -> "Responde em português elegante e cinematográfico."
            AppLanguage.LN -> "Responds in clear French with subtle Lingala flavor."
        }

        val prompt = """
            Jeu: HÉRITAGE — THE LAST HEIR (Thriller milliardaire, succession de 100M$).
            $langInstruction
            Personnage IA: ${rival.name} (${rival.titleFr}).
            Persona: ${rival.aiPersonaPrompt}
            Secret du personnage IA: ${rival.secretObjectiveFr}
            Indice connu par le personnage IA: ${rival.secretClueFr}
            
            Contexte actuel:
            - Chapitre: $chapterNumber / 10
            - Interlocuteur (Joueur): $playerCharacterName (Réputation: $playerReputation/100, Fortune virtuelle: ${playerWealthM}M$)
            - Message du joueur: "$playerMessage"
            
            Réponds strictement en respectant le schéma JSON demandé. Garde tes propres secrets protégés sauf si le joueur propose un pacte solide ou a une haute réputation.
        """.trimIndent()

        return try {
            val response = withTimeout(45_000L) {
                model.generateContent(prompt)
            }
            val jsonText = response.text ?: error("Empty response from Gemini")
            val json = JSONObject(jsonText)
            Result.success(
                AiNegotiationOutcome(
                    heirName = rival.name,
                    replyText = json.getString("reply"),
                    trustDelta = json.optInt("trustDelta", 2).coerceIn(-10, 15),
                    allianceAccepted = json.optBoolean("allianceAccepted", false),
                    clueHint = json.optString("clueHint", "").takeIf { it.isNotBlank() && it != "null" },
                    wealthOfferM = json.optInt("wealthOfferM", 0).coerceIn(-10, 15)
                )
            )
        } catch (e: TimeoutCancellationException) {
            Log.e("AiHeirService", "Gemini negotiation timed out", e)
            Result.failure(Exception("Délai dépassé lors de la négociation avec ${rival.name}."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("AiHeirService", "Gemini negotiation failed", e)
            Result.failure(e)
        }
    }
}
